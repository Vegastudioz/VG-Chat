Locales = Locales or {}
Locales.en = {
    input_placeholder = 'Type a message or command...',
    plain_disabled = 'Plain chat is disabled. Use /me, /do or a command.',
}
