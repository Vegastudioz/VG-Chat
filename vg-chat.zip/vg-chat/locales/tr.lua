Locales = Locales or {}
Locales.tr = {
    input_placeholder = 'Mesaj veya komut yaz...',
    plain_disabled = 'Normal chat kapalı. /me, /do veya bir komut kullan.',
}
