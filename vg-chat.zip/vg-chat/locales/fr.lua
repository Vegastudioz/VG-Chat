Locales = Locales or {}
Locales.fr = {
    input_placeholder = 'Saisir un message ou une commande...',
    plain_disabled = 'Le chat normal est désactivé. Utilise /me, /do ou une commande.',
}
