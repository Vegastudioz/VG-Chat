Locales = Locales or {}
Locales.es = {
    input_placeholder = 'Escribe un mensaje o comando...',
    plain_disabled = 'El chat normal está desactivado. Usa /me, /do o un comando.',
}
