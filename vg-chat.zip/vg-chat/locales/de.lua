Locales = Locales or {}
Locales.de = {
    input_placeholder = 'Nachricht oder Befehl eingeben...',
    plain_disabled = 'Normaler Chat ist deaktiviert. Nutze /me, /do oder einen Befehl.',
}
