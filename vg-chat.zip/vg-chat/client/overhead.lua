-- VG Chat 2.1: panel-free, centered, stacked RP text (reference-style).
-- All RP content and expiry remain server-controlled; display preferences are local only.
local active = {}
local typing = {}
local visible = true
local orderedKinds = { 'me', 'do', 'ame', 'dice' }
local diceUiShown = false
local lastDiceUiUpdate = 0
local typingUiShown = false
local lastTypingUiUpdate = 0
local prefs = {
    style = 'signature',
    animate = true,
    labels = false,
    fontPercent = 100,
    headHeight = tonumber(Config.Overhead.stackBaseOffset) or 0.48,
    radius = tonumber(Config.Overhead.radius) or 18.0
}

RegisterNetEvent('vg-chat:client:set3D', function(enabled)
    visible = enabled ~= false
end)

RegisterNetEvent('vg-chat:client:setOverheadStyle', function(data)
    if type(data) ~= 'table' then return end
    local allowed = { signature = true, cinematic = true, classic = true }
    if allowed[data.style] then prefs.style = data.style end
    prefs.animate = data.animate == true
    prefs.labels = data.labels ~= false
    prefs.radius = math.max(6.0, math.min(24.0, tonumber(data.radius) or prefs.radius))
    prefs.fontPercent = math.max(80, math.min(150, tonumber(data.fontPercent) or prefs.fontPercent))
    prefs.headHeight = math.max(0.30, math.min(0.80, tonumber(data.headHeight) or prefs.headHeight))
end)

local function getPed(src)
    local player = GetPlayerFromServerId(src)
    if player == -1 then return 0 end
    local ped = GetPlayerPed(player)
    return ped ~= 0 and DoesEntityExist(ped) and ped or 0
end

local function hasLosToPed(ped)
    return not Config.Overhead.lineOfSight or HasEntityClearLosToEntity(PlayerPedId(), ped, 17)
end

local function glyphCount(s)
    local ok, n = pcall(utf8.len, s)
    return ok and n or #s
end

local function trimToChars(s, limit)
    local ok, offset = pcall(utf8.offset, s, limit + 1)
    if ok and offset then return s:sub(1, offset - 1) end
    return s
end

local function splitLines(text)
    local limit = math.max(22, math.min(64, tonumber((Config.Signature or {}).charactersPerLine) or 43))
    local maxLines = math.max(1, math.min(6, tonumber((Config.Signature or {}).maxLinesPerMessage) or 4))
    local lines, current = {}, ''
    local function push()
        if current ~= '' then lines[#lines + 1] = current; current = '' end
    end
    for word in tostring(text or ''):gmatch('%S+') do
        if glyphCount(word) > limit then
            push()
            while glyphCount(word) > limit and #lines < maxLines do
                local fragment = trimToChars(word, limit)
                lines[#lines + 1] = fragment
                word = word:sub(#fragment + 1)
            end
        end
        if glyphCount(current) + glyphCount(word) + (current ~= '' and 1 or 0) > limit then push() end
        current = current == '' and word or (current .. ' ' .. word)
        if #lines >= maxLines then break end
    end
    push()
    if #lines == 0 then lines[1] = '' end
    while #lines > maxLines do table.remove(lines) end
    return lines
end

local function colors(kind)
    if kind == 'me' or kind == 'do' then
        return (VGChatLocalColors and VGChatLocalColors[kind]) or (Config.DefaultClientColors or {})[kind] or { 255, 255, 255 }
    elseif kind == 'ame' then
        return { 255, 215, 156 }
    elseif kind == 'dice' then
        -- The red die is the Unicode emoji; numeric result stays crisp white.
        return { 248, 247, 252 }
    end
    return { 255, 255, 255 }
end

-- Match the earlier text-only RP look. No bar, label strip, tinted rectangle or orange rule.
-- GTA native drawing is intentionally kept instead of creating an expensive world-space DUI.
local function getScale(coords)
    local cam = GetGameplayCamCoords()
    local dist = #(cam - coords)
    local fovScale = (1.0 / math.max(dist, 1.0)) * (100.0 / math.max(GetGameplayCamFov(), 10.0))
    local base = tonumber(Config.Overhead.textScale) or 0.385
    local userMultiplier = (prefs.fontPercent or 112) / 100.0
    return math.max(0.255, math.min(0.46, base * fovScale * 5.2 * userMultiplier))
end

local function drawString(x, y, text, color, alpha, scale, font)
    SetTextScale(0.0, scale)
    SetTextFont(font or 0)
    SetTextProportional(1)
    SetTextCentre(true)
    SetTextJustification(0)
    SetTextDropshadow(1, 0, 0, 0, 190)
    SetTextOutline()
    SetTextColour(color[1], color[2], color[3], alpha)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

local function drawLine(coords, line, kind, alpha, rowAbove, age, baseScreenY)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if not onScreen then return end
    local scale = getScale(coords)
    if baseScreenY then y = baseScreenY end
    -- Space lines in screen units, so characters farther away still have legible separation.
    local lineGap = tonumber(Config.Overhead.screenLineSpacing) or 0.034
    y = y - (rowAbove or 0) * lineGap * (scale / 0.43)
    if prefs.animate and kind == 'dice' and age and age < 300 then
        scale = scale * (1.0 + 0.06 * (1.0 - age / 300))
    end

    local style = prefs.style
    local color = colors(kind)
    local displayText = line
    if prefs.labels and kind ~= 'dice' and style == 'signature' then
        displayText = kind:upper() .. '  ' .. line
    end

    if kind == 'dice' then
        -- A centered die + white result, without the old ROLL label or black HUD banner.
        drawString(x, y, line, { 249, 247, 255 }, alpha, scale * 0.82, 4)
    elseif style == 'cinematic' then
        drawString(x, y, displayText, { 245, 241, 250 }, alpha, scale * 0.92, 0)
    elseif style == 'classic' then
        drawString(x, y, line, color, alpha, scale * 0.95, 4)
    else
        -- Default Signature uses the old-chat colors with a slightly larger, rounded font.
        drawString(x, y, displayText, color, alpha, scale, 0)
    end
end

-- Typing is a world-anchored NUI micro-bubble, not GTA text glyphs.  CEF
-- animates the three CSS dots smoothly between the 25 Hz position updates.
-- Keeping it in a separate layer also prevents periods sitting in a hat/hair.

RegisterNetEvent('vg-chat:client:rp', function(payload)
    if type(payload) ~= 'table' then return end
    local src = tonumber(payload.source)
    local kind = tostring(payload.kind or 'me')
    if not src or (kind ~= 'me' and kind ~= 'do' and kind ~= 'ame' and kind ~= 'dice') then return end
    active[src] = active[src] or {}
    local prior = active[src][kind]
    local rollId = tonumber(payload.rollId)
    if kind == 'dice' and prior and tonumber(prior.rollId) and rollId then
        if rollId < prior.rollId then return end -- stale reveal cannot override a newer roll
        if rollId == prior.rollId and prior.rolling == false and payload.rolling == true then
            return -- never turn a completed roll back into a spinning die
        end
    end
    -- Independent kind slots: a roll changes only the dice row, never /me or /do.
    active[src][kind] = {
        text = tostring(payload.text or ''):sub(1, 280),
        kind = kind,
        rollId = rollId,
        rolling = kind == 'dice' and payload.rolling == true,
        rollDurationMs = math.max(700, tonumber(payload.rollDurationMs) or 2400),
        result = tonumber(payload.result),
        max = tonumber(payload.max),
        createdAt = GetGameTimer(),
        expiresAt = GetGameTimer() + math.max(100, tonumber(payload.expires) or Config.Overhead.duration),
    }
    active[src][kind].lines = kind == 'dice' and { '' } or splitLines(active[src][kind].text)
end)

RegisterNetEvent('vg-chat:client:typing', function(src, state)
    src = tonumber(src)
    if src then typing[src] = state == true or nil end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        active = {}; typing = {}
        SendNUIMessage({ action = 'diceOverhead', data = {} })
        SendNUIMessage({ action = 'typingOverhead', data = {} })
    end
end)

CreateThread(function()
    while true do
        -- Wake within 100 ms when T is pressed, instead of sleeping 650 ms.
        -- No expensive player/entity work is done while no indicators exist.
        local waitMs = 100
        local now = GetGameTimer()
        for src, slots in pairs(active) do
            for kind, msg in pairs(slots) do
                if msg.expiresAt <= now then slots[kind] = nil end
            end
            if not next(slots) then active[src] = nil end
        end

        local diceUiRows = {}
        local typingUiRows = {}
        if visible and (next(active) or next(typing)) then
            local myCoords = GetEntityCoords(PlayerPedId())
            local radius = prefs.radius
            local maxRadius = math.max(radius, Config.Overhead.typingRadius)
            local processed = {}
            local cfg = Config.Overhead
            local minHeadZ = prefs.headHeight
            local maxStack = tonumber(cfg.maxStack) or 4

            local function renderPlayer(src)
                if processed[src] then return end
                processed[src] = true
                local ped = getPed(src)
                if ped == 0 then return end
                local worldPos = GetEntityCoords(ped)
                local distance = #(myCoords - worldPos)
                if distance > maxRadius or not hasLosToPed(ped) then return end

                local head = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
                -- Anchor every RP kind to the real HEAD bone and guarantee an
                -- additional screen-space clearance above the top of the skull.
                -- This prevents a saved scale, camera zoom or different ped
                -- proportions from making /me and /do sit inside the hair.
                local textAnchor = vector3(head.x, head.y, head.z + minHeadZ)
                local baseVisible, _, rpBaseY = World3dToScreen2d(textAnchor.x, textAnchor.y, textAnchor.z)
                local scalpOffset = tonumber(cfg.headScalpOffset) or 0.145
                local scalpVisible, _, scalpY = World3dToScreen2d(head.x, head.y, head.z + scalpOffset)
                if baseVisible and scalpVisible then
                    local scale = getScale(textAnchor)
                    local clearance = tonumber(cfg.minTextScreenClearance) or 0.034
                    -- Native DrawText uses the anchor as the TOP of the line.
                    -- Move its top high enough to keep the whole line above hair.
                    local clearanceScaled = math.max(0.024, math.min(0.060, clearance * scale / 0.34))
                    rpBaseY = math.min(rpBaseY, scalpY - clearanceScaled)
                end
                local queue = {}
                local slots = active[src]
                if slots and distance <= radius then
                    local added = 0
                    for _, kind in ipairs(orderedKinds) do
                        local msg = slots[kind]
                        if msg and added < maxStack then
                            added = added + 1
                            local lines = msg.lines or { msg.text }
                            for i = 1, #lines do
                                queue[#queue + 1] = { text = lines[i], kind = kind, msg = msg }
                            end
                        end
                    end
                end

                -- Bottom RP line floats above the scalp; additional lines grow UP.
                for index, item in ipairs(queue) do
                    local left = item.msg.expiresAt - now
                    local alpha = left > 650 and 255 or math.floor(math.max(0, left) / 650 * 255)
                    if prefs.animate then
                        local age = now - item.msg.createdAt
                        if age < 210 then
                            local fraction = math.max(0, age / 210)
                            alpha = math.floor(alpha * fraction)
                        end
                    end
                    local rowAbove = #queue - index
                    if item.kind == 'dice' then
                        -- A lightweight NUI/CSS 3D cube spins in the *same* world-anchored
                        -- line as the ordinary RP text. GTA native text cannot rotate icons.
                        -- The die's bottom edge is above this world anchor (NUI translateY(-100%)).
                        -- Keep extra clearance so the cube never covers the character's hair/face.
                        local clearance = tonumber((Config.Dice or {}).uiHeadClearance) or 0.35
                        -- Preserve the compact die's previous screen height. A change
                        -- to RP text position must not push the dice far into the sky.
                        local position = vector3(head.x, head.y, head.z + 0.185 + clearance)
                        local projected, sx, sy = World3dToScreen2d(position.x, position.y, position.z)
                        if projected then
                            local scale = getScale(position) * 0.76
                            if baseVisible then sy = math.min(sy, rpBaseY + 0.008) end
                            sy = sy - rowAbove * (tonumber(cfg.screenLineSpacing) or 0.034) * (scale / 0.43)
                            diceUiRows[#diceUiRows + 1] = {
                                id = tostring(src), x = sx, y = sy, scale = scale,
                                rolling = item.msg.rolling,
                                duration = item.msg.rollDurationMs,
                                rollId = item.msg.rollId,
                                result = item.msg.result, max = item.msg.max,
                                alpha = alpha
                            }
                        end
                    else
                        if baseVisible then
                            drawLine(textAnchor, item.text, item.kind, alpha, rowAbove, now - item.msg.createdAt, rpBaseY)
                        end
                    end
                    waitMs = 0
                end
                if typing[src] and distance <= cfg.typingRadius then
                    -- Project from the actual head bone, not the ped origin.
                    -- The anchor sits well ABOVE hair and the bubble's *bottom*
                    -- touches that point; it cannot overlap the head texture.
                    local height = math.max(0.20, math.min(0.70, tonumber(cfg.typingHeightOffset) or 0.40))
                    local position = vector3(head.x, head.y, head.z + height)
                    local onScreen, sx, sy = World3dToScreen2d(position.x, position.y, position.z)
                    if onScreen then
                        local scale = getScale(position)
                        -- RP lines grow upwards, so typing stays on top of the stack.
                        if #queue > 0 then
                            local gap = tonumber(cfg.screenLineSpacing) or 0.034
                            sy = sy - (#queue * gap * (scale / 0.43))
                            if baseVisible then
                                -- The typing bubble stays ABOVE even a multi-line /me or /do.
                                sy = math.min(sy, rpBaseY - #queue * gap * (scale / 0.43) - 0.014)
                            end
                        end
                        typingUiRows[#typingUiRows + 1] = {
                            id = tostring(src), x = sx, y = sy,
                            scale = scale, alpha = (cfg.typingColor or {255,255,255,255})[4] or 255
                        }
                    end
                    -- Only 25 Hz position updates; the CSS dot loop runs independently.
                    waitMs = math.min(waitMs, 40)
                end
            end
            for src in pairs(active) do renderPlayer(src) end
            for src in pairs(typing) do renderPlayer(src) end
        end

        -- Typing is replicated immediately from T down/up, and one NUI bubble
        -- is maintained per visible player. Clear immediately when nobody types.
        if (#typingUiRows > 0 or typingUiShown)
            and (now - lastTypingUiUpdate >= 40 or (#typingUiRows == 0 and typingUiShown)) then
            SendNUIMessage({ action = 'typingOverhead', data = typingUiRows })
            typingUiShown = #typingUiRows > 0
            lastTypingUiUpdate = now
        end

        -- Only while dice exists: one small batched NUI message, at most 25/s.
        -- When the last die expires or becomes occluded, clear the overlay once.
        if (#diceUiRows > 0 or diceUiShown) and (now - lastDiceUiUpdate >= 40 or (#diceUiRows == 0 and diceUiShown)) then
            SendNUIMessage({ action = 'diceOverhead', data = diceUiRows })
            diceUiShown = #diceUiRows > 0
            lastDiceUiUpdate = now
        end
        Wait(waitMs)
    end
end)
