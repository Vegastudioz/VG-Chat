local isOpen = false
local suggestions = {}
local serverCommands = {}
local hidden = {}
local registered = {}
local lastTypingState = false
local playerLocale = Config.Locale or 'en'
local screenshotBusy = false


-- GTA/FiveM'in native text chat katmanını da kapalı tut. Stock `chat` resource'u
-- server tarafında durdurulsa bile başka bir resource tekrar açmaya çalışırsa bu,
-- native chat'in ekrana düşmesini engeller.
local function disableNativeTextChat()
    local cfg = Config.StockChat or {}
    if cfg.disableNativeTextChat == false then return end

    pcall(function()
        SetTextChatEnabled(false)
    end)
end

CreateThread(function()
    Wait(250)
    disableNativeTextChat()

    -- Bazı resource'lar native chat durumunu sonradan değiştirebildiği için çok hafif
    -- bir koruma döngüsü kullanıyoruz. Frame başına çalışmaz; performansa yük bindirmez.
    while true do
        Wait(5000)
        disableNativeTextChat()
    end
end)

-- Kişisel RP renkleri sadece bu client'ta tutulur. Server'a veya diğer oyunculara
-- gönderilmez. Böylece her oyuncu aynı /me ve /do mesajını kendi seçtiği renkte görür.
VGChatLocalColors = VGChatLocalColors or {
    me = {
        (Config.DefaultClientColors.me and Config.DefaultClientColors.me[1]) or 224,
        (Config.DefaultClientColors.me and Config.DefaultClientColors.me[2]) or 167,
        (Config.DefaultClientColors.me and Config.DefaultClientColors.me[3]) or 244,
    },
    ['do'] = {
        (Config.DefaultClientColors['do'] and Config.DefaultClientColors['do'][1]) or 41,
        (Config.DefaultClientColors['do'] and Config.DefaultClientColors['do'][2]) or 224,
        (Config.DefaultClientColors['do'] and Config.DefaultClientColors['do'][3]) or 207,
    }
}

local function cleanRgb(input, fallback)
    input = type(input) == 'table' and input or {}
    local function channel(value, default)
        value = tonumber(value) or default
        if value < 0 then return 0 end
        if value > 255 then return 255 end
        return math.floor(value + 0.5)
    end
    return {
        channel(input.r or input[1], fallback[1]),
        channel(input.g or input[2], fallback[2]),
        channel(input.b or input[3], fallback[3]),
    }
end

local function locale(key)
    local lang = Locales[playerLocale] or Locales.en or {}
    return lang[key] or key
end

local function normalizeName(name)
    name = tostring(name or ''):lower()
    name = name:gsub('^/', '')
    return name
end

local function hasHiddenPrefix(name)
    for _, prefix in ipairs(Config.HiddenPrefixes or {}) do
        if name:sub(1, #prefix) == prefix then return true end
    end
    return false
end

local function isHiddenCommand(name, restricted)
    name = normalizeName(name)
    if name == '' then return true end
    if Config.HidePlusMinusCommands and (name:sub(1, 1) == '+' or name:sub(1, 1) == '-') then
        return true
    end
    if hasHiddenPrefix(name) then return true end
    if Config.HideRestrictedCommands and restricted then return true end
    return Config.HiddenSuggestions[name] == true
end

-- 'Registered commands' include developer helpers, diagnostics and framework internals.
-- Keep those executable while avoiding hundreds of irrelevant UI suggestions.
local function isAutoSuggestable(name)
    local cfg = Config.CommandSuggestions or {}
    name = normalizeName(name)
    if isHiddenCommand(name, false) or name == '' then return false end
    if cfg.forceShow and cfg.forceShow[name] == true then return true end
    if #name > (cfg.maxLength or 18) or #name < 2 then return false end
    if not name:match('^[a-z][a-z0-9]*$') then return false end
    for _, prefix in ipairs(cfg.blockedPrefixes or {}) do
        if name:sub(1, #prefix) == prefix then return false end
    end
    for _, term in ipairs(cfg.blockedContains or {}) do
        if name:find(term, 1, true) then return false end
    end
    return true
end

local function pushSuggestions()
    local list = {}
    local merged = {}
    -- Descriptions supplied through chat:addSuggestion take priority over auto discovery.
    for name, item in pairs(suggestions) do
        if not hidden[name] and not isHiddenCommand(name, false) then merged[name] = item end
    end
    for name in pairs(registered) do
        if not merged[name] and not hidden[name] and isAutoSuggestable(name) then
            merged[name] = { name = name, description = '', usage = name }
        end
    end
    for name in pairs(serverCommands) do
        if not merged[name] and not hidden[name] and isAutoSuggestable(name) then
            merged[name] = { name = name, description = '', usage = name }
        end
    end
    for _, item in pairs(merged) do list[#list + 1] = item end
    table.sort(list, function(a, b) return a.name < b.name end)
    SendNUIMessage({ action = 'suggestions', data = list })
end

local function addSuggestion(name, description, usage, restricted)
    name = normalizeName(name)
    if name == '' then return end
    if isHiddenCommand(name, restricted) then
        hidden[name] = true
        suggestions[name] = nil
        return
    end
    suggestions[name] = {
        name = name,
        description = description or '',
        usage = usage or name
    }
end

local function refreshRegisteredCommands()
    registered = {}
    if type(GetRegisteredCommands) ~= 'function' then return end
    local ok, cmds = pcall(GetRegisteredCommands)
    if not ok or type(cmds) ~= 'table' then return end

    for _, cmd in ipairs(cmds) do
        local name = normalizeName(cmd.name)
        if name ~= '' then
            registered[name] = true
            if isHiddenCommand(name, cmd.restricted) then hidden[name] = true end
        end
    end
end

CreateThread(function()
    Wait(500)
    refreshRegisteredCommands()
    for _, entry in ipairs(Config.PublicSuggestions) do
        addSuggestion(entry.name, entry.description, entry.usage, false)
    end
    pushSuggestions()
    SendNUIMessage({
        action = 'config',
        data = {
            placeholder = locale('input_placeholder'),
            locale = playerLocale,
            maxHistory = Config.MaxHistory,
            typingIdleMs = Config.Overhead.typingIdleMs or 1250,
            diceUi = {
                base = tonumber((Config.Dice or {}).uiScalePx) or 48,
                min = tonumber((Config.Dice or {}).uiMinPx) or 11,
                max = tonumber((Config.Dice or {}).uiMaxPx) or 24
            }
        }
    })
end)

RegisterNetEvent('vg-chat:client:serverCommands', function(names)
    serverCommands = {}
    if type(names) == 'table' then
        for _, name in ipairs(names) do
            name = normalizeName(name)
            if name ~= '' then serverCommands[name] = true end
        end
    end
    pushSuggestions()
end)

local function setTyping(state)
    if lastTypingState == state then return end
    lastTypingState = state
    -- Local feedback is immediate; the server replicates to every other client.
    TriggerEvent('vg-chat:client:typing', GetPlayerServerId(PlayerId()), state)
    TriggerServerEvent('vg-chat:server:typing', state)
end

local function setOpen(state, settingsOnly)
    isOpen = state
    SetNuiFocus(state, state)
    SetNuiFocusKeepInput(false)

    if state then
        refreshRegisteredCommands()
        TriggerServerEvent('vg-chat:server:requestCommandList')
        pushSuggestions()
        SendNUIMessage({ action = settingsOnly and 'settings' or 'open' })
        -- Chat opened with T: broadcast immediately, even while the input is still empty.
        -- The settings-only panel is not a typing action.
        setTyping(not settingsOnly)
    else
        SendNUIMessage({ action = 'close' })
        setTyping(false)
    end
end

RegisterCommand(Config.OpenCommand, function()
    if not isOpen then setOpen(true, false) end
end, false)
RegisterKeyMapping(Config.OpenCommand, 'Open VG Chat', 'keyboard', Config.OpenKey)

RegisterCommand(Config.SettingsCommand, function()
    setOpen(true, true)
end, false)

RegisterCommand('clear', function()
    SendNUIMessage({ action = 'clear' })
end, false)

RegisterNetEvent('chat:clear', function()
    SendNUIMessage({ action = 'clear' })
end)

-- Character session end must not retain chat / command history in an existing NUI.
for _, eventName in ipairs({ 'QBCore:Client:OnPlayerUnload', 'qbx_core:client:playerLoggedOut', 'esx:onPlayerLogout' }) do
    RegisterNetEvent(eventName, function()
        if isOpen then setOpen(false, false) end
        SendNUIMessage({ action = 'clear' })
    end)
end


RegisterNUICallback('close', function(_, cb)
    setOpen(false, false)
    cb({ ok = true })
end)



RegisterNUICallback('setLocale', function(data, cb)
    local nextLocale = tostring(data and data.locale or ''):lower()
    if not Locales[nextLocale] then nextLocale = Config.Locale or 'en' end
    playerLocale = nextLocale
    SendNUIMessage({ action = 'locale', data = { locale = nextLocale } })
    cb({ ok = true })
end)

RegisterNUICallback('set3D', function(data, cb)
    TriggerEvent('vg-chat:client:set3D', data and data.enabled == true)
    cb({ ok = true })
end)

RegisterNUICallback('setOverheadStyle', function(data, cb)
    TriggerEvent('vg-chat:client:setOverheadStyle', data)
    cb({ ok = true })
end)

-- Optional screenshot-basic support. The user chooses whether to save the preview.
RegisterNUICallback('screenshot', function(_, cb)
    if screenshotBusy then cb({ ok = false, reason = 'screenshot_busy' }); return end
    if GetResourceState('screenshot-basic') ~= 'started' then
        cb({ ok = false, reason = 'screenshot_missing' })
        return
    end
    screenshotBusy = true
    cb({ ok = true })
    SendNUIMessage({ action = 'screenshotStart' })
    CreateThread(function()
      Wait(220) -- Hide our own chat UI so the captured scene stays clean.
      local ok = pcall(function()
        exports['screenshot-basic']:requestScreenshot({ encoding = 'jpg', quality = 0.85 }, function(data)
            screenshotBusy = false
            if type(data) == 'string' and data:sub(1, 11) == 'data:image/' then
                SendNUIMessage({ action = 'screenshotReady', data = data })
            else
                SendNUIMessage({ action = 'screenshotError', reason = 'screenshot_failed' })
            end
        end)
    end)
      if not ok then
          screenshotBusy = false
          SendNUIMessage({ action = 'screenshotError', reason = 'screenshot_failed' })
      end
    end)
    SetTimeout(12000, function()
      if screenshotBusy then
          screenshotBusy = false
          SendNUIMessage({ action = 'screenshotError', reason = 'screenshot_failed' })
      end
    end)
end)

RegisterNUICallback('setClientColors', function(data, cb)
    local meFallback = Config.DefaultClientColors.me or { 224, 167, 244 }
    local doFallback = Config.DefaultClientColors['do'] or { 41, 224, 207 }

    VGChatLocalColors.me = cleanRgb(data and data.me, meFallback)
    VGChatLocalColors['do'] = cleanRgb(data and data['do'], doFallback)

    cb({ ok = true })
end)

RegisterNUICallback('typing', function(_, cb)
    -- The typing indicator follows chat focus, NOT keystrokes or an idle timer.
    -- This intentionally ignores old NUI typing(false) events while T is open.
    cb({ ok = true })
end)

RegisterNUICallback('submit', function(data, cb)
    local raw = tostring(data and data.text or '')
    raw = raw:gsub('[\r\n]', ' ')
    local maxBytes = math.max(16, tonumber(Config.MaxInputLength) or 280)
    if #raw > maxBytes then
        local ok, offset = pcall(utf8.offset, raw, 0, maxBytes + 1)
        if ok and offset then raw = raw:sub(1, offset - 1)
        else
            while maxBytes > 0 and raw:byte(maxBytes + 1) and raw:byte(maxBytes + 1) >= 128
                and raw:byte(maxBytes + 1) <= 191 do maxBytes = maxBytes - 1 end
            raw = raw:sub(1, maxBytes)
        end
    end
    local line = raw:gsub('^%s+', ''):gsub('%s+$', '')
    if line == '' then
        cb({ ok = true })
        return
    end

    local hadSlash = line:sub(1, 1) == '/'
    if hadSlash then line = line:sub(2) end

    local command = normalizeName(line:match('^(%S+)') or '')
    local compat = Config.CommandCompatibility or {}

    -- FiveM'in stock chat'i / ile girilen komutları doğrudan ExecuteCommand ile yollar.
    -- Burada da aynı davranışı koruyoruz. Böylece qbx_adminmenu, qb-adminmenu,
    -- EasyAdmin ve RegisterCommand kullanan diğer admin resource'larının komutları
    -- autocomplete listesinde görünmese bile çalışmaya devam eder.
    local executeAsCommand = false

    if command ~= '' then
        if hadSlash and compat.executeUnknownSlashCommands ~= false then
            executeAsCommand = true
        elseif registered[command] or serverCommands[command] or suggestions[command] or hidden[command] then
            executeAsCommand = true
        elseif Config.AllowSlashlessCommands
            and not Config.AllowPlainText
            and compat.executeUnknownSlashlessWhenPlainTextDisabled ~= false then
            -- Bu resource'ta normal global yazı kapalı olduğu için slash'siz bilinmeyen
            -- girdileri de komut olarak FiveM'e bırakabiliriz. Yetki kontrolünü ilgili
            -- server-side RegisterCommand/ACE sistemi yapar.
            executeAsCommand = true
        end
    end

    if executeAsCommand then
        ExecuteCommand(line)
        cb({ ok = true, executed = true })
        return
    end

    if Config.AllowPlainText then
        TriggerServerEvent('vg-chat:server:plainMessage', raw)
        cb({ ok = true, executed = false })
        return
    end

    SendNUIMessage({ action = 'hint', data = { text = locale('plain_disabled') } })
    cb({ ok = false, reason = 'plain_disabled' })
end)

RegisterNetEvent('vg-chat:client:proximityMessage', function(sourceServerId, radius, message)
    local sourceId = tonumber(sourceServerId)
    if not sourceId or type(message) ~= 'table' then return end

    local myServerId = GetPlayerServerId(PlayerId())
    if sourceId == myServerId then
        SendNUIMessage({ action = 'message', data = message })
        return
    end

    local sourcePlayer = GetPlayerFromServerId(sourceId)
    if sourcePlayer == -1 then return end

    local sourcePed = GetPlayerPed(sourcePlayer)
    if sourcePed == 0 or not DoesEntityExist(sourcePed) then return end

    local myPed = PlayerPedId()
    local dist = #(GetEntityCoords(myPed) - GetEntityCoords(sourcePed))
    if dist <= tonumber(radius or Config.ProximityRadius) then
        SendNUIMessage({ action = 'message', data = message })
    end
end)


local function loadAnimDict(dict)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)

    local timeout = GetGameTimer() + 4000
    while not HasAnimDictLoaded(dict) do
        Wait(0)
        if GetGameTimer() >= timeout then
            return false
        end
    end

    return true
end

local diceAnimBusy = false
RegisterNetEvent('vg-chat:client:playDiceAnim', function()
    if diceAnimBusy then return end
    local ped = PlayerPedId()
    if ped == 0 or not DoesEntityExist(ped) or IsEntityDead(ped) or IsPedRagdoll(ped)
        or IsPedInAnyVehicle(ped, false) then return end

    diceAnimBusy = true
    CreateThread(function()
        local cfg = Config.Dice or {}
        local shake = cfg.shake or {}
        local throw = cfg.throw or {}
        local dict = IsPedMale(ped) and (shake.maleDict or 'gestures@m@standing@casual')
            or (shake.femaleDict or 'gestures@f@standing@casual')
        local shakeClip = shake.clip or 'gesture_hand_down'
        local loaded = loadAnimDict(dict)
        if loaded then
            TaskPlayAnim(ped, dict, shakeClip, 4.5, -3.0, shake.duration or 650, 48, 0, false, false, false)
            Wait(shake.duration or 650)
            StopAnimTask(ped, dict, shakeClip, 2.5)
            RemoveAnimDict(dict)
        end
        local throwDict = throw.dict or 'mp_common'
        local throwClip = throw.clip or 'givetake1_a'
        if loadAnimDict(throwDict) then
            TaskPlayAnim(ped, throwDict, throwClip, 6.0, -3.0,
                throw.duration or 700, throw.flag or 48, 0, false, false, false)
            Wait(throw.duration or 700)
            StopAnimTask(ped, throwDict, throwClip, 2.0)
            RemoveAnimDict(throwDict)
        end
        diceAnimBusy = false
    end)
end)

-- A local-only prop per nearby viewer: no network entities, DB entries or permanently
-- loaded models. The ped animation itself replicates from its owning player.
RegisterNetEvent('vg-chat:client:showDiceProp', function(serverId)
    local player = GetPlayerFromServerId(tonumber(serverId) or -1)
    if player == -1 then return end
    local ped = GetPlayerPed(player)
    if ped == 0 or not DoesEntityExist(ped) then return end
    local distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(ped))
    if distance > (Config.Overhead.radius or 18.0) then return end
    if IsPedInAnyVehicle(ped, false) then return end

    CreateThread(function()
        local cfg = Config.Dice or {}
        local hash = joaat(cfg.model or 'prop_dice_01')
        if not IsModelInCdimage(hash) then return end
        RequestModel(hash)
        local timeout = GetGameTimer() + (cfg.modelTimeoutMs or 800)
        while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(20) end
        if not HasModelLoaded(hash) then return end
        if not DoesEntityExist(ped) then SetModelAsNoLongerNeeded(hash); return end
        local pos = GetEntityCoords(ped)
        local obj = CreateObjectNoOffset(hash, pos.x, pos.y, pos.z, false, false, false)
        SetModelAsNoLongerNeeded(hash)
        if obj == 0 or not DoesEntityExist(obj) then return end
        SetEntityCollision(obj, false, false)
        AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422),
            0.055, 0.015, -0.018, 0, 0, 0, false, true, false, false, 2, true)
        Wait((cfg.shake and cfg.shake.duration) or 650)
        if DoesEntityExist(obj) then
            DetachEntity(obj, true, true)
            SetEntityCollision(obj, true, true)
            ActivatePhysics(obj)
            local fwd = GetEntityForwardVector(ped)
            SetEntityVelocity(obj, fwd.x * 2.5, fwd.y * 2.5, 1.9)
            SetEntityRotation(obj, math.random(0, 180), math.random(0, 180), math.random(0, 180), 2, true)
        end
        Wait(tonumber(cfg.propFlightMs) or 900)
        if DoesEntityExist(obj) then DeleteObject(obj) end
    end)
end)

-- Admin/menu resource'ları runtime'da komut ekleyebildiği için listeyi resource
-- start/stop sonrasında yenile. Bu yalnızca autocomplete/tespit içindir; gerçek
-- komut yürütme ExecuteCommand üzerinden FiveM'e bırakılır.
AddEventHandler('onClientResourceStart', function(resourceName)
    disableNativeTextChat()
    if resourceName == GetCurrentResourceName() then return end
    if Config.CommandCompatibility and Config.CommandCompatibility.refreshOnResourceChange == false then return end
    CreateThread(function()
        Wait(350)
        refreshRegisteredCommands()
        TriggerServerEvent('vg-chat:server:requestCommandList')
        pushSuggestions()
    end)
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        -- Best effort: clear remote typing if only this client's VG Chat reloads.
        if lastTypingState then TriggerServerEvent('vg-chat:server:typing', false) end
        return
    end
    if Config.CommandCompatibility and Config.CommandCompatibility.refreshOnResourceChange == false then return end
    CreateThread(function()
        Wait(150)
        refreshRegisteredCommands()
        TriggerServerEvent('vg-chat:server:requestCommandList')
        pushSuggestions()
    end)
end)

-- Stock/legacy chat event uyumluluğu. Bazı admin resource'ları sonuçlarını
-- chatMessage veya serverPrint event'i ile basar. Bunları VG Chat'e yönlendiriyoruz.
RegisterNetEvent('chatMessage', function(author, color, text)
    SendNUIMessage({
        action = 'message',
        data = {
            type = 'system',
            author = tostring(author or ''),
            text = tostring(text or '')
        }
    })
end)

RegisterNetEvent('__cfx_internal:serverPrint', function(message)
    SendNUIMessage({
        action = 'message',
        data = { type = 'system', author = '', text = tostring(message or '') }
    })
end)

RegisterNetEvent('chat:resetSuggestions', function()
    suggestions = {}
    hidden = {}
    refreshRegisteredCommands()
    for _, entry in ipairs(Config.PublicSuggestions) do
        addSuggestion(entry.name, entry.description, entry.usage, false)
    end
    pushSuggestions()
end)

RegisterNetEvent('chat:client:ClearChat', function()
    SendNUIMessage({ action = 'clear' })
end)

-- Stock FiveM chat uyumluluğu.
RegisterNetEvent('chat:addSuggestion', function(name, help, params)
    local usage = normalizeName(name)
    if type(params) == 'table' and #params > 0 then
        local parts = { usage }
        for _, p in ipairs(params) do
            parts[#parts + 1] = ('[%s]'):format(p.name or 'arg')
        end
        usage = table.concat(parts, ' ')
    end
    addSuggestion(name, help, usage, false)
    pushSuggestions()
end)

RegisterNetEvent('chat:addSuggestions', function(items)
    for _, item in ipairs(items or {}) do
        local usage = normalizeName(item.name)
        if type(item.params) == 'table' and #item.params > 0 then
            local parts = { usage }
            for _, p in ipairs(item.params) do
                parts[#parts + 1] = ('[%s]'):format(p.name or 'arg')
            end
            usage = table.concat(parts, ' ')
        end
        addSuggestion(item.name, item.help, usage, false)
    end
    pushSuggestions()
end)

RegisterNetEvent('chat:removeSuggestion', function(name)
    name = normalizeName(name)
    suggestions[name] = nil
    pushSuggestions()
end)

RegisterNetEvent('chat:addMessage', function(message)
    if type(message) ~= 'table' then return end
    local args = message.args or {}
    local text = table.concat(args, ' ')
    SendNUIMessage({ action = 'message', data = { type = 'system', author = '', text = text } })
end)

RegisterNetEvent('vg-chat:client:addMessage', function(message)
    SendNUIMessage({ action = 'message', data = message })
end)

exports('AddSuggestion', function(name, description, usage, options)
    options = options or {}
    if options.hidden == true then
        hidden[normalizeName(name)] = true
        suggestions[normalizeName(name)] = nil
    else
        addSuggestion(name, description, usage, options.restricted == true)
    end
    pushSuggestions()
end)

exports('RemoveSuggestion', function(name)
    suggestions[normalizeName(name)] = nil
    pushSuggestions()
end)

exports('SetCommandHidden', function(name, state)
    name = normalizeName(name)
    hidden[name] = state == true
    if hidden[name] then suggestions[name] = nil end
    pushSuggestions()
end)
