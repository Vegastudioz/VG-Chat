VGBridge = VGBridge or {}

local framework = 'standalone'

CreateThread(function()
    if GetResourceState('qbx_core') == 'started' then
        framework = 'qbx'
    elseif GetResourceState('qb-core') == 'started' then
        framework = 'qb'
    elseif GetResourceState('es_extended') == 'started' then
        framework = 'esx'
    end
end)

function VGBridge.GetFramework()
    return framework
end
