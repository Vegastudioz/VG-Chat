VGBridge = VGBridge or {}

local framework = 'standalone'
local QB, ESX

local function trim(value)
    return tostring(value or ''):gsub('^%s*(.-)%s*$', '%1')
end

local function normalizeGrade(grade)
    if type(grade) == 'table' then
        return tonumber(grade.level or grade.grade or grade.value or 0) or 0
    end
    return tonumber(grade or 0) or 0
end

CreateThread(function()
    if GetResourceState('qbx_core') == 'started' then
        framework = 'qbx'
    elseif GetResourceState('qb-core') == 'started' then
        framework = 'qb'
        QB = exports['qb-core']:GetCoreObject()
    elseif GetResourceState('es_extended') == 'started' then
        framework = 'esx'
        ESX = exports['es_extended']:getSharedObject()
    end
end)

function VGBridge.GetFramework()
    return framework
end

function VGBridge.GetName(src)
    if framework == 'qbx' then
        local player = exports.qbx_core:GetPlayer(src)
        if player and player.PlayerData and player.PlayerData.charinfo then
            local c = player.PlayerData.charinfo
            local full = trim(('%s %s'):format(c.firstname or '', c.lastname or ''))
            if full ~= '' then return full end
        end
    elseif framework == 'qb' and QB then
        local player = QB.Functions.GetPlayer(src)
        if player and player.PlayerData and player.PlayerData.charinfo then
            local c = player.PlayerData.charinfo
            local full = trim(('%s %s'):format(c.firstname or '', c.lastname or ''))
            if full ~= '' then return full end
        end
    elseif framework == 'esx' and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local full = trim(xPlayer.getName())
            if full ~= '' then return full end
        end
    end
    return GetPlayerName(src) or ('ID %s'):format(src)
end

function VGBridge.GetJobData(src)
    if framework == 'qbx' then
        local player = exports.qbx_core:GetPlayer(src)
        local job = player and player.PlayerData and player.PlayerData.job
        if job then
            return {
                name = tostring(job.name or ''),
                grade = normalizeGrade(job.grade),
                onDuty = job.onduty ~= false,
            }
        end
    elseif framework == 'qb' and QB then
        local player = QB.Functions.GetPlayer(src)
        local job = player and player.PlayerData and player.PlayerData.job
        if job then
            return {
                name = tostring(job.name or ''),
                grade = normalizeGrade(job.grade),
                onDuty = job.onduty ~= false,
            }
        end
    elseif framework == 'esx' and ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        local job = xPlayer and xPlayer.job
        if job then
            return {
                name = tostring(job.name or ''),
                grade = normalizeGrade(job.grade),
                onDuty = job.onDuty ~= false,
            }
        end
    end

    return { name = '', grade = 0, onDuty = true }
end

function VGBridge.GetJob(src)
    return VGBridge.GetJobData(src).name
end
