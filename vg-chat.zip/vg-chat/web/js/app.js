const DEFAULT_LAYOUT = {
  messages: { x: 0.55, y: 3.7, w: 29.2, h: 22.7 },
  composer: { x: 0.55, y: 27.0, w: 27.1, h: 6.7 }
};

const DICTS = window.VG_CHAT_I18N || {};
const localeStore = localStorage.getItem('vgchat.locale');
const initialLocale = DICTS[localeStore] ? localeStore : 'en';

// One-time V2 -> V2.1 visual migration: earlier releases stored the boxed Signature
// style and enabled the ME/DO chips by default. Reset *only* these visual defaults.
// New per-player choices are preserved on subsequent restarts.
if (localStorage.getItem('vgchat.overheadVisualVersion') !== '2.1.0') {
  localStorage.setItem('vgchat.overheadStyle', 'signature');
  localStorage.setItem('vgchat.overheadLabels', 'off');
  localStorage.setItem('vgchat.overheadVisualVersion', '2.1.0');
}

// VG Chat 2.5.2: older saved 10-38 cm positions placed RP writing in hair.
// Migrate only once; leave all other preferences and subsequent user choices intact.
if (localStorage.getItem('vgchat.overheadPlacementVersion') !== '2.5.2') {
  const savedHeight = Number(localStorage.getItem('vgchat.overheadHeight'));
  if (!Number.isFinite(savedHeight) || savedHeight < 39) {
    localStorage.setItem('vgchat.overheadHeight', '48');
  }
  localStorage.setItem('vgchat.overheadPlacementVersion', '2.5.2');
}

const safeJSON = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
  catch { return fallback; }
};

function clampNumber(raw, min, max, fallback) { const n = Number(raw); return Number.isFinite(n) && raw !== null ? Math.max(min, Math.min(max, n)) : fallback; }

// Purge the old persisted history once; this release keeps command history only in RAM.
localStorage.removeItem('vgchat.commandHistory');
const state = {
  open: false,
  locale: initialLocale,
  overheadEnabled: localStorage.getItem('vgchat.overhead') !== 'off',
  panelDrag: null,
  layoutMode: false,
  suggestions: [],
  selected: 0,
  commandHistory: [], // session-only: emotes never survive reconnects
  historyRevision: 0,
  historyTab: 'chat',
  historyIndex: -1,
  fadeTime: Number(localStorage.getItem('vgchat.fadeTime') || 10),
  maxHistory: 120,
  messages: [],
  expireTimers: new Map(),
  layout: safeJSON('vgchat.layout', DEFAULT_LAYOUT),
  drag: null,
  typingIdleTimer: null,
  typingIdleMs: 1250,
  toolMenuOpen: false,
  currentTab: 'appearance',
  overheadStyle: ['signature','cinematic','classic'].includes(localStorage.getItem('vgchat.overheadStyle')) ? localStorage.getItem('vgchat.overheadStyle') : 'signature',
  overheadAnimate: localStorage.getItem('vgchat.overheadAnimate') !== 'off',
  overheadLabels: localStorage.getItem('vgchat.overheadLabels') === 'on',
  overheadSize: clampNumber(localStorage.getItem('vgchat.overheadSize'), 80, 150, 100),
  overheadHeight: clampNumber(localStorage.getItem('vgchat.overheadHeight'), 30, 80, 48),
  overheadDistance: clampNumber(localStorage.getItem('vgchat.overheadDistance'), 6, 24, 18),
  reduceMotion: localStorage.getItem('vgchat.reduceMotion') === 'on',
  compactMessages: localStorage.getItem('vgchat.compactMessages') === 'on',
};

const el = {
  chat: document.getElementById('chat'),
  messageStage: document.getElementById('messageStage'),
  messages: document.getElementById('messages'),
  composer: document.getElementById('composer'),
  menuButton: document.getElementById('menuButton'),
  toolbar: document.getElementById('toolbar'),
  emojiButton: document.getElementById('emojiButton'),
  emojiPanel: document.getElementById('emojiPanel'),
  emojiClose: document.getElementById('emojiClose'),
  emojiHeading: document.getElementById('emojiHeading'),
  emojiSearch: document.getElementById('emojiSearch'),
  emojiCategories: document.getElementById('emojiCategories'),
  emojiGrid: document.getElementById('emojiGrid'),
  emojiFooter: document.getElementById('emojiFooter'),
  settingsTabs: document.getElementById('settingsTabs'),
  previewStack: document.getElementById('previewStack'),
  overheadAnimate: document.getElementById('overheadAnimate'),
  overheadLabels: document.getElementById('overheadLabels'),
  overheadSizeRange: document.getElementById('overheadSizeRange'),
  overheadSizeValue: document.getElementById('overheadSizeValue'),
  overheadHeightRange: document.getElementById('overheadHeightRange'),
  overheadHeightValue: document.getElementById('overheadHeightValue'),
  distanceRange: document.getElementById('distanceRange'),
  distanceValue: document.getElementById('distanceValue'),
  reduceMotion: document.getElementById('reduceMotion'),
  compactMessages: document.getElementById('compactMessages'),
  commandReference: document.getElementById('commandReference'),
  input: document.getElementById('input'),
  suggestions: document.getElementById('suggestions'),
  hint: document.getElementById('hint'),
  settings: document.getElementById('settings'),
  settingsButton: document.getElementById('settingsButton'),
  screenshotButton: document.getElementById('screenshotButton'),
  overheadButton: document.getElementById('overheadButton'),
  screenshotPanel: document.getElementById('screenshotPanel'),
  screenshotPreview: document.getElementById('screenshotPreview'),
  saveScreenshot: document.getElementById('saveScreenshot'),
  closeScreenshot: document.getElementById('closeScreenshot'),
  languageSelect: document.getElementById('languageSelect'),
  closeSettings: document.getElementById('closeSettings'),
  historyPanel: document.getElementById('historyPanel'),
  historyButton: document.getElementById('historyButton'),
  closeHistory: document.getElementById('closeHistory'),
  historyList: document.getElementById('historyList'),
  chatHistoryTab: document.getElementById('chatHistoryTab'),
  commandHistoryTab: document.getElementById('commandHistoryTab'),
  fontScale: document.getElementById('fontScale'),
  bgOpacity: document.getElementById('bgOpacity'),
  fadeTime: document.getElementById('fadeTime'),
  fontScaleValue: document.getElementById('fontScaleValue'),
  bgOpacityValue: document.getElementById('bgOpacityValue'),
  fadeTimeValue: document.getElementById('fadeTimeValue'),
  meColor: document.getElementById('meColor'),
  doColor: document.getElementById('doColor'),
  meColorHex: document.getElementById('meColorHex'),
  doColorHex: document.getElementById('doColorHex'),
  colorSwatches: Array.from(document.querySelectorAll('.colorSwatch')),
  layoutButton: document.getElementById('layoutButton'),
  resetLayoutButton: document.getElementById('resetLayoutButton'),
};

const post = (name, body = {}) => fetch(`https://${GetParentResourceName()}/${name}`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body)
}).then(r => r.json()).catch(() => ({ ok: false, reason: 'screenshot_failed' }));

const esc = (s) => String(s ?? '').replace(/[&<>'"]/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
}[c]));

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

function t(key, values = {}) {
  const dict = DICTS[state.locale] || DICTS.en || {};
  const pattern = String(dict[key] || DICTS.en?.[key] || key);
  return pattern.replace(/\{(\w+)\}/g, (all, name) => String(values[name] ?? all));
}

function applyLocale(locale, save = false, notify = false) {
  state.locale = DICTS[locale] ? locale : 'en';
  document.documentElement.lang = state.locale;
  if (save) localStorage.setItem('vgchat.locale', state.locale);
  if (el.languageSelect) el.languageSelect.value = state.locale;
  document.querySelectorAll('[data-i18n]').forEach(node => {
    if (node.id === 'layoutButton' && state.layoutMode) node.textContent = t('save_layout');
    else node.textContent = t(node.dataset.i18n);
  });
  el.input.placeholder = t('placeholder');
  localizeEmoji();
  el.historyButton.title = t('history');
  el.settingsButton.title = t('settings');
  el.overheadButton.title = state.overheadEnabled ? t('three_d_enabled') : t('three_d_disabled');
  el.fadeTimeValue.textContent = `${state.fadeTime} ${t('seconds')}`;
  renderHistory();
  renderCommandReference();
  for (const row of state.messages) {
    if (row._messageData) row.innerHTML = messageHTML(row._messageData);
  }
  renderSuggestions();
  if (notify) post('setLocale', { locale: state.locale });
}

function hint(text) {
  el.hint.textContent = String(text || '');
  clearTimeout(hint.timer);
  hint.timer = setTimeout(() => { el.hint.textContent = ''; }, 4500);
}

function syncOverhead() {
  el.overheadButton.classList.toggle('disabled3d', !state.overheadEnabled);
  el.overheadButton.setAttribute('aria-pressed', String(state.overheadEnabled));
  el.overheadButton.title = t(state.overheadEnabled ? 'three_d_enabled' : 'three_d_disabled');
  post('set3D', { enabled: state.overheadEnabled });
}


function syncOverheadStyle() {
  el.previewStack.className = `previewStack ${state.overheadStyle}${state.overheadLabels ? '' : ' labels-off'}`;
  document.querySelectorAll('[data-style]').forEach(button => button.classList.toggle('active', button.dataset.style === state.overheadStyle));
  el.overheadAnimate.checked = state.overheadAnimate;
  el.overheadLabels.checked = state.overheadLabels;
  el.overheadSizeRange.value = state.overheadSize;
  el.overheadSizeValue.textContent = `${state.overheadSize}%`;
  el.overheadHeightRange.value = state.overheadHeight;
  el.overheadHeightValue.textContent = `${state.overheadHeight} cm`;
  el.previewStack.style.setProperty('--overhead-preview-scale', String(state.overheadSize / 112));
  el.distanceRange.value = state.overheadDistance;
  el.distanceValue.textContent = `${state.overheadDistance} m`;
  post('setOverheadStyle', {
    style: state.overheadStyle,
    animate: state.overheadAnimate && !state.reduceMotion,
    labels: state.overheadLabels,
    radius: state.overheadDistance,
    fontPercent: state.overheadSize,
    headHeight: state.overheadHeight / 100
  });
}
function syncAccessibility() {
  el.reduceMotion.checked = state.reduceMotion;
  el.compactMessages.checked = state.compactMessages;
  el.chat.classList.toggle('reduce-motion', state.reduceMotion);
  el.chat.classList.toggle('compact-messages', state.compactMessages);
  syncOverheadStyle();
}
function activateSettingsTab(tab) {
  state.currentTab = tab;
  document.querySelectorAll('.panelTab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('[data-tab-content]').forEach(panel => panel.classList.toggle('active', panel.dataset.tabContent === tab));
}
function renderCommandReference() {
  if (!el.commandReference) return;
  const commands = ['me','do','ame','roll','try','pm','jobp','jobc','clear','chatsettings'];
  el.commandReference.innerHTML = commands.map(name => {
    const display = name === 'roll' && state.locale === 'tr' ? 'zar' : name;
    return `<div class="commandRef"><code>/${display}</code><span>${esc(t('command_' + name))}</span></div>`;
  }).join('');
}

function normalizeHex(value, fallback = '#29e0cf') {
  const raw = String(value || '').trim();
  const short = /^#([0-9a-f]{3})$/i.exec(raw);
  if (short) return '#' + short[1].split('').map(c => c + c).join('').toLowerCase();
  const full = /^#([0-9a-f]{6})$/i.exec(raw);
  return full ? '#' + full[1].toLowerCase() : fallback;
}

function hexToRgb(hex) {
  const h = normalizeHex(hex).slice(1);
  return {
    r: parseInt(h.slice(0, 2), 16),
    g: parseInt(h.slice(2, 4), 16),
    b: parseInt(h.slice(4, 6), 16),
  };
}

function getRPColor(kind) {
  const fallback = kind === 'me' ? '#e0a7f4' : '#29e0cf';
  return normalizeHex(localStorage.getItem(`vgchat.${kind}Color`) || fallback, fallback);
}

function syncClientColors() {
  post('setClientColors', {
    me: hexToRgb(getRPColor('me')),
    do: hexToRgb(getRPColor('do'))
  });
}

function applyRPColor(kind, value, persist = false, notify = false) {
  const fallback = kind === 'me' ? '#e0a7f4' : '#29e0cf';
  const hex = normalizeHex(value, fallback);
  document.documentElement.style.setProperty(`--${kind}-color`, hex);

  const input = kind === 'me' ? el.meColor : el.doColor;
  const hexLabel = kind === 'me' ? el.meColorHex : el.doColorHex;
  if (input) input.value = hex;
  if (hexLabel) hexLabel.textContent = hex.toUpperCase();

  el.colorSwatches.forEach(btn => {
    if (btn.dataset.kind === kind) {
      btn.classList.toggle('active', normalizeHex(btn.dataset.color, fallback) === hex);
    }
  });

  if (persist) localStorage.setItem(`vgchat.${kind}Color`, hex);
  if (notify) syncClientColors();
}

function applySettings() {
  const fs = Number(localStorage.getItem('vgchat.fontScale') || 108);
  const bg = Number(localStorage.getItem('vgchat.bgOpacity') || 32);
  const ft = Number(localStorage.getItem('vgchat.fadeTime') || 10);
  el.fontScale.value = fs;
  el.bgOpacity.value = bg;
  el.fadeTime.value = ft;
  el.fontScaleValue.textContent = `${fs}%`;
  el.bgOpacityValue.textContent = `${bg}%`;
  el.fadeTimeValue.textContent = `${ft} ${t('seconds')}`;
  state.fadeTime = ft;
  document.documentElement.style.setProperty('--font', `${15 * (fs / 100)}px`);
  document.documentElement.style.setProperty('--input-bg', String(bg / 100));
  applyRPColor('me', getRPColor('me'), false, false);
  applyRPColor('do', getRPColor('do'), false, false);
}

function normalizeLayoutEntry(value, fallback) {
  const v = value || fallback;
  return {
    x: Number.isFinite(Number(v.x)) ? Number(v.x) : fallback.x,
    y: Number.isFinite(Number(v.y)) ? Number(v.y) : fallback.y,
    w: Number.isFinite(Number(v.w)) ? Number(v.w) : fallback.w,
    h: Number.isFinite(Number(v.h)) ? Number(v.h) : fallback.h,
  };
}

function applyLayout() {
  state.layout.messages = normalizeLayoutEntry(state.layout.messages, DEFAULT_LAYOUT.messages);
  state.layout.composer = normalizeLayoutEntry(state.layout.composer, DEFAULT_LAYOUT.composer);

  const apply = (node, data, isComposer) => {
    node.style.left = `${clamp(data.x, 0, 92)}vw`;
    node.style.top = `${clamp(data.y, 0, 94)}vh`;
    node.style.width = `${clamp(data.w, 18, 60)}vw`;
    if (!isComposer) node.style.height = `${clamp(data.h, 11, 60)}vh`;
  };

  apply(el.messageStage, state.layout.messages, false);
  apply(el.composer, state.layout.composer, true);
}

function saveLayout() {
  localStorage.setItem('vgchat.layout', JSON.stringify(state.layout));
}

// Offline Unicode emoji picker. No external CDN, no proprietary WhatsApp imagery.
// Bundled in the main NUI script so the picker never depends on a separate cached file.
const EMOJI_CATALOG = {"smileys":[["😂","face with tears of joy"],["🤣","rolling on the floor laughing"],["😭","loudly crying face"],["😍","smiling face with heart-shaped eyes"],["🥰","smiling face with smiling eyes and three hearts"],["😘","face throwing a kiss"],["❤️","heavy black heart"],["😎","smiling face with sunglasses"],["😅","smiling face with open mouth and cold sweat"],["😊","smiling face with smiling eyes"],["💜","purple heart"],["😈","smiling face with horns"],["🤝","handshake"],["🤔","thinking face"],["😡","pouting face"],["😱","face screaming in fear"],["🤩","grinning face with star eyes"],["😴","sleeping face"],["💙","blue heart"],["💚","green heart"],["💛","yellow heart"],["🖤","black heart"],["😀","grinning face"],["😁","grinning face with smiling eyes"],["😃","smiling face with open mouth"],["😄","smiling face with open mouth and smiling eyes"],["😆","smiling face with open mouth and tightly-closed eyes"],["😇","smiling face with halo"],["😉","winking face"],["😋","face savouring delicious food"],["😌","relieved face"],["😏","smirking face"],["😐","neutral face"],["😑","expressionless face"],["😒","unamused face"],["😓","face with cold sweat"],["😔","pensive face"],["😕","confused face"],["😖","confounded face"],["😗","kissing face"],["😙","kissing face with smiling eyes"],["😚","kissing face with closed eyes"],["😛","face with stuck-out tongue"],["😜","face with stuck-out tongue and winking eye"],["😝","face with stuck-out tongue and tightly-closed eyes"],["😞","disappointed face"],["😟","worried face"],["😠","angry face"],["😢","crying face"],["😣","persevering face"],["😤","face with look of triumph"],["😥","disappointed but relieved face"],["😦","frowning face with open mouth"],["😧","anguished face"],["😨","fearful face"],["😩","weary face"],["😪","sleepy face"],["😫","tired face"],["😬","grimacing face"],["😮","face with open mouth"],["😯","hushed face"],["😰","face with open mouth and cold sweat"],["😲","astonished face"],["😳","flushed face"],["😵","dizzy face"],["😶","face without mouth"],["😷","face with medical mask"],["😸","grinning cat face with smiling eyes"],["😹","cat face with tears of joy"],["😺","smiling cat face with open mouth"],["😻","smiling cat face with heart-shaped eyes"],["😼","cat face with wry smile"],["😽","kissing cat face with closed eyes"],["😾","pouting cat face"],["😿","crying cat face"],["🙀","weary cat face"],["🙁","slightly frowning face"],["🙂","slightly smiling face"],["🙃","upside-down face"],["🙄","face with rolling eyes"],["🙅","face with no good gesture"],["🙅🏻","face with no good gesture light skin tone"],["🙅🏼","face with no good gesture medium light skin tone"],["🙅🏽","face with no good gesture medium skin tone"],["🙅🏾","face with no good gesture medium dark skin tone"],["🙅🏿","face with no good gesture dark skin tone"],["🙆","face with ok gesture"],["🙆🏻","face with ok gesture light skin tone"],["🙆🏼","face with ok gesture medium light skin tone"],["🙆🏽","face with ok gesture medium skin tone"],["🙆🏾","face with ok gesture medium dark skin tone"],["🙆🏿","face with ok gesture dark skin tone"],["🙇","person bowing deeply"],["🙇🏻","person bowing deeply light skin tone"],["🙇🏼","person bowing deeply medium light skin tone"],["🙇🏽","person bowing deeply medium skin tone"],["🙇🏾","person bowing deeply medium dark skin tone"],["🙇🏿","person bowing deeply dark skin tone"],["🙈","see-no-evil monkey"],["🙉","hear-no-evil monkey"],["🙊","speak-no-evil monkey"],["🙋","happy person raising one hand"],["🙋🏻","happy person raising one hand light skin tone"],["🙋🏼","happy person raising one hand medium light skin tone"],["🙋🏽","happy person raising one hand medium skin tone"],["🙋🏾","happy person raising one hand medium dark skin tone"],["🙋🏿","happy person raising one hand dark skin tone"],["🙌","person raising both hands in celebration"],["🙌🏻","person raising both hands in celebration light skin tone"],["🙌🏼","person raising both hands in celebration medium light skin tone"],["🙌🏽","person raising both hands in celebration medium skin tone"],["🙌🏾","person raising both hands in celebration medium dark skin tone"],["🙌🏿","person raising both hands in celebration dark skin tone"],["🙍","person frowning"],["🙍🏻","person frowning light skin tone"],["🙍🏼","person frowning medium light skin tone"],["🙍🏽","person frowning medium skin tone"],["🙍🏾","person frowning medium dark skin tone"],["🙍🏿","person frowning dark skin tone"],["🙎","person with pouting face"],["🙎🏻","person with pouting face light skin tone"],["🙎🏼","person with pouting face medium light skin tone"],["🙎🏽","person with pouting face medium skin tone"],["🙎🏾","person with pouting face medium dark skin tone"],["🙎🏿","person with pouting face dark skin tone"],["🙏","person with folded hands"],["🙏🏻","person with folded hands light skin tone"],["🙏🏼","person with folded hands medium light skin tone"],["🙏🏽","person with folded hands medium skin tone"],["🙏🏾","person with folded hands medium dark skin tone"],["🙏🏿","person with folded hands dark skin tone"],["🤍","white heart"],["🤎","brown heart"],["🤐","zipper-mouth face"],["🤑","money-mouth face"],["🤒","face with thermometer"],["🤓","nerd face"],["🤕","face with head-bandage"],["🤖","robot face"],["🤗","hugging face"],["🤘","sign of the horns"],["🤘🏻","sign of the horns light skin tone"],["🤘🏼","sign of the horns medium light skin tone"],["🤘🏽","sign of the horns medium skin tone"],["🤘🏾","sign of the horns medium dark skin tone"],["🤘🏿","sign of the horns dark skin tone"],["🤙","call me hand"],["🤙🏻","call me hand light skin tone"],["🤙🏼","call me hand medium light skin tone"],["🤙🏽","call me hand medium skin tone"],["🤙🏾","call me hand medium dark skin tone"],["🤙🏿","call me hand dark skin tone"],["🤚","raised back of hand"],["🤚🏻","raised back of hand light skin tone"],["🤚🏼","raised back of hand medium light skin tone"],["🤚🏽","raised back of hand medium skin tone"],["🤚🏾","raised back of hand medium dark skin tone"],["🤚🏿","raised back of hand dark skin tone"],["🤛","left-facing fist"],["🤛🏻","left-facing fist light skin tone"],["🤛🏼","left-facing fist medium light skin tone"],["🤛🏽","left-facing fist medium skin tone"],["🤛🏾","left-facing fist medium dark skin tone"],["🤛🏿","left-facing fist dark skin tone"],["🤜","right-facing fist"],["🤜🏻","right-facing fist light skin tone"],["🤜🏼","right-facing fist medium light skin tone"],["🤜🏽","right-facing fist medium skin tone"],["🤜🏾","right-facing fist medium dark skin tone"],["🤜🏿","right-facing fist dark skin tone"],["🤝🏻","handshake light skin tone"],["🤝🏼","handshake medium light skin tone"],["🤝🏽","handshake medium skin tone"],["🤝🏾","handshake medium dark skin tone"],["🤝🏿","handshake dark skin tone"],["🤞","hand with index and middle fingers crossed"],["🤞🏻","hand with index and middle fingers crossed light skin tone"],["🤞🏼","hand with index and middle fingers crossed medium light skin tone"],["🤞🏽","hand with index and middle fingers crossed medium skin tone"],["🤞🏾","hand with index and middle fingers crossed medium dark skin tone"],["🤞🏿","hand with index and middle fingers crossed dark skin tone"],["🤟","i love you hand sign"],["🤟🏻","i love you hand sign light skin tone"],["🤟🏼","i love you hand sign medium light skin tone"],["🤟🏽","i love you hand sign medium skin tone"],["🤟🏾","i love you hand sign medium dark skin tone"],["🤟🏿","i love you hand sign dark skin tone"],["🤠","face with cowboy hat"],["🤡","clown face"],["🤢","nauseated face"],["🤤","drooling face"],["🤥","lying face"],["🤦","face palm"],["🤦🏻","face palm light skin tone"],["🤦🏼","face palm medium light skin tone"],["🤦🏽","face palm medium skin tone"],["🤦🏾","face palm medium dark skin tone"],["🤦🏿","face palm dark skin tone"],["🤧","sneezing face"],["🤨","face with one eyebrow raised"],["🤪","grinning face with one large and one small eye"],["🤫","face with finger covering closed lips"],["🤬","serious face with symbols covering mouth"],["🤭","smiling face with smiling eyes and hand covering mouth"],["🤮","face with open mouth vomiting"],["🤯","shocked face with exploding head"],["🥲","smiling face with tear"],["🥸","disguised face"],["🥹","face holding back tears"],["🧡","orange heart"],["🩵","light blue heart"],["🩶","grey heart"],["🩷","pink heart"],["🩹","adhesive bandage"],["❤️‍🔥","heart on fire"],["❤️‍🩹","mending heart"],["😮‍💨","face exhaling"],["😵‍💫","face with spiral eyes"],["🙂‍↔️","head shaking horizontally"],["🙂‍↕️","head shaking vertically"]],"people":[["💀","skull"],["👍","thumbs up sign"],["🫶","heart hands"],["👋","waving hand sign"],["👋🏻","waving hand sign light skin tone"],["👋🏼","waving hand sign medium light skin tone"],["👋🏽","waving hand sign medium skin tone"],["👋🏾","waving hand sign medium dark skin tone"],["👋🏿","waving hand sign dark skin tone"],["👍🏻","thumbs up sign light skin tone"],["👍🏼","thumbs up sign medium light skin tone"],["👍🏽","thumbs up sign medium skin tone"],["👍🏾","thumbs up sign medium dark skin tone"],["👍🏿","thumbs up sign dark skin tone"],["👎","thumbs down sign"],["👎🏻","thumbs down sign light skin tone"],["👎🏼","thumbs down sign medium light skin tone"],["👎🏽","thumbs down sign medium skin tone"],["👎🏾","thumbs down sign medium dark skin tone"],["👎🏿","thumbs down sign dark skin tone"],["👐","open hands sign"],["👐🏻","open hands sign light skin tone"],["👐🏼","open hands sign medium light skin tone"],["👐🏽","open hands sign medium skin tone"],["👐🏾","open hands sign medium dark skin tone"],["👐🏿","open hands sign dark skin tone"],["👦","boy"],["👦🏻","boy light skin tone"],["👦🏼","boy medium light skin tone"],["👦🏽","boy medium skin tone"],["👦🏾","boy medium dark skin tone"],["👦🏿","boy dark skin tone"],["👧","girl"],["👧🏻","girl light skin tone"],["👧🏼","girl medium light skin tone"],["👧🏽","girl medium skin tone"],["👧🏾","girl medium dark skin tone"],["👧🏿","girl dark skin tone"],["👨","man"],["👨🏻","man light skin tone"],["👨🏼","man medium light skin tone"],["👨🏽","man medium skin tone"],["👨🏾","man medium dark skin tone"],["👨🏿","man dark skin tone"],["👩","woman"],["👩🏻","woman light skin tone"],["👩🏼","woman medium light skin tone"],["👩🏽","woman medium skin tone"],["👩🏾","woman medium dark skin tone"],["👩🏿","woman dark skin tone"],["👪","family"],["👪🏻","family light skin tone"],["👪🏼","family medium light skin tone"],["👪🏽","family medium skin tone"],["👪🏾","family medium dark skin tone"],["👪🏿","family dark skin tone"],["👫","man and woman holding hands"],["👫🏻","man and woman holding hands light skin tone"],["👫🏼","man and woman holding hands medium light skin tone"],["👫🏽","man and woman holding hands medium skin tone"],["👫🏾","man and woman holding hands medium dark skin tone"],["👫🏿","man and woman holding hands dark skin tone"],["👬","two men holding hands"],["👬🏻","two men holding hands light skin tone"],["👬🏼","two men holding hands medium light skin tone"],["👬🏽","two men holding hands medium skin tone"],["👬🏾","two men holding hands medium dark skin tone"],["👬🏿","two men holding hands dark skin tone"],["👭","two women holding hands"],["👭🏻","two women holding hands light skin tone"],["👭🏼","two women holding hands medium light skin tone"],["👭🏽","two women holding hands medium skin tone"],["👭🏾","two women holding hands medium dark skin tone"],["👭🏿","two women holding hands dark skin tone"],["👮","police officer"],["👮🏻","police officer light skin tone"],["👮🏼","police officer medium light skin tone"],["👮🏽","police officer medium skin tone"],["👮🏾","police officer medium dark skin tone"],["👮🏿","police officer dark skin tone"],["👯","woman with bunny ears"],["👯🏻","woman with bunny ears light skin tone"],["👯🏼","woman with bunny ears medium light skin tone"],["👯🏽","woman with bunny ears medium skin tone"],["👯🏾","woman with bunny ears medium dark skin tone"],["👯🏿","woman with bunny ears dark skin tone"],["👰","bride with veil"],["👰🏻","bride with veil light skin tone"],["👰🏼","bride with veil medium light skin tone"],["👰🏽","bride with veil medium skin tone"],["👰🏾","bride with veil medium dark skin tone"],["👰🏿","bride with veil dark skin tone"],["👱","person with blond hair"],["👱🏻","person with blond hair light skin tone"],["👱🏼","person with blond hair medium light skin tone"],["👱🏽","person with blond hair medium skin tone"],["👱🏾","person with blond hair medium dark skin tone"],["👱🏿","person with blond hair dark skin tone"],["👲","man with gua pi mao"],["👲🏻","man with gua pi mao light skin tone"],["👲🏼","man with gua pi mao medium light skin tone"],["👲🏽","man with gua pi mao medium skin tone"],["👲🏾","man with gua pi mao medium dark skin tone"],["👲🏿","man with gua pi mao dark skin tone"],["👳","man with turban"],["👳🏻","man with turban light skin tone"],["👳🏼","man with turban medium light skin tone"],["👳🏽","man with turban medium skin tone"],["👳🏾","man with turban medium dark skin tone"],["👳🏿","man with turban dark skin tone"],["👴","older man"],["👴🏻","older man light skin tone"],["👴🏼","older man medium light skin tone"],["👴🏽","older man medium skin tone"],["👴🏾","older man medium dark skin tone"],["👴🏿","older man dark skin tone"],["👵","older woman"],["👵🏻","older woman light skin tone"],["👵🏼","older woman medium light skin tone"],["👵🏽","older woman medium skin tone"],["👵🏾","older woman medium dark skin tone"],["👵🏿","older woman dark skin tone"],["👶","baby"],["👶🏻","baby light skin tone"],["👶🏼","baby medium light skin tone"],["👶🏽","baby medium skin tone"],["👶🏾","baby medium dark skin tone"],["👶🏿","baby dark skin tone"],["👷","construction worker"],["👷🏻","construction worker light skin tone"],["👷🏼","construction worker medium light skin tone"],["👷🏽","construction worker medium skin tone"],["👷🏾","construction worker medium dark skin tone"],["👷🏿","construction worker dark skin tone"],["👸","princess"],["👸🏻","princess light skin tone"],["👸🏼","princess medium light skin tone"],["👸🏽","princess medium skin tone"],["👸🏾","princess medium dark skin tone"],["👸🏿","princess dark skin tone"],["👹","japanese ogre"],["👺","japanese goblin"],["👻","ghost"],["👼","baby angel"],["👼🏻","baby angel light skin tone"],["👼🏼","baby angel medium light skin tone"],["👼🏽","baby angel medium skin tone"],["👼🏾","baby angel medium dark skin tone"],["👼🏿","baby angel dark skin tone"],["👽","extraterrestrial alien"],["👾","alien monster"],["👿","imp"],["💁","information desk person"],["💁🏻","information desk person light skin tone"],["💁🏼","information desk person medium light skin tone"],["💁🏽","information desk person medium skin tone"],["💁🏾","information desk person medium dark skin tone"],["💁🏿","information desk person dark skin tone"],["💂","guardsman"],["💂🏻","guardsman light skin tone"],["💂🏼","guardsman medium light skin tone"],["💂🏽","guardsman medium skin tone"],["💂🏾","guardsman medium dark skin tone"],["💂🏿","guardsman dark skin tone"],["💃","dancer"],["💃🏻","dancer light skin tone"],["💃🏼","dancer medium light skin tone"],["💃🏽","dancer medium skin tone"],["💃🏾","dancer medium dark skin tone"],["💃🏿","dancer dark skin tone"],["💄","lipstick"],["💅","nail polish"],["💅🏻","nail polish light skin tone"],["💅🏼","nail polish medium light skin tone"],["💅🏽","nail polish medium skin tone"],["💅🏾","nail polish medium dark skin tone"],["💅🏿","nail polish dark skin tone"],["💆","face massage"],["💆🏻","face massage light skin tone"],["💆🏼","face massage medium light skin tone"],["💆🏽","face massage medium skin tone"],["💆🏾","face massage medium dark skin tone"],["💆🏿","face massage dark skin tone"],["💇","haircut"],["💇🏻","haircut light skin tone"],["💇🏼","haircut medium light skin tone"],["💇🏽","haircut medium skin tone"],["💇🏾","haircut medium dark skin tone"],["💇🏿","haircut dark skin tone"],["🤌","pinched fingers"],["🤌🏻","pinched fingers light skin tone"],["🤌🏼","pinched fingers medium light skin tone"],["🤌🏽","pinched fingers medium skin tone"],["🤌🏾","pinched fingers medium dark skin tone"],["🤌🏿","pinched fingers dark skin tone"],["🤏","pinching hand"],["🤏🏻","pinching hand light skin tone"],["🤏🏼","pinching hand medium light skin tone"],["🤏🏽","pinching hand medium skin tone"],["🤏🏾","pinching hand medium dark skin tone"],["🤏🏿","pinching hand dark skin tone"],["🤰","pregnant woman"],["🤰🏻","pregnant woman light skin tone"],["🤰🏼","pregnant woman medium light skin tone"],["🤰🏽","pregnant woman medium skin tone"],["🤰🏾","pregnant woman medium dark skin tone"],["🤰🏿","pregnant woman dark skin tone"],["🤱","breast-feeding"],["🤱🏻","breast-feeding light skin tone"],["🤱🏼","breast-feeding medium light skin tone"],["🤱🏽","breast-feeding medium skin tone"],["🤱🏾","breast-feeding medium dark skin tone"],["🤱🏿","breast-feeding dark skin tone"],["🤲","palms up together"],["🤲🏻","palms up together light skin tone"],["🤲🏼","palms up together medium light skin tone"],["🤲🏽","palms up together medium skin tone"],["🤲🏾","palms up together medium dark skin tone"],["🤲🏿","palms up together dark skin tone"],["🤳","selfie"],["🤳🏻","selfie light skin tone"],["🤳🏼","selfie medium light skin tone"],["🤳🏽","selfie medium skin tone"],["🤳🏾","selfie medium dark skin tone"],["🤳🏿","selfie dark skin tone"],["🤴","prince"],["🤴🏻","prince light skin tone"],["🤴🏼","prince medium light skin tone"],["🤴🏽","prince medium skin tone"],["🤴🏾","prince medium dark skin tone"],["🤴🏿","prince dark skin tone"],["🤵","man in tuxedo"],["🤵🏻","man in tuxedo light skin tone"],["🤵🏼","man in tuxedo medium light skin tone"],["🤵🏽","man in tuxedo medium skin tone"],["🤵🏾","man in tuxedo medium dark skin tone"],["🤵🏿","man in tuxedo dark skin tone"],["🤶","mother christmas"],["🤶🏻","mother christmas light skin tone"],["🤶🏼","mother christmas medium light skin tone"],["🤶🏽","mother christmas medium skin tone"],["🤶🏾","mother christmas medium dark skin tone"],["🤶🏿","mother christmas dark skin tone"],["🤷","shrug"],["🤷🏻","shrug light skin tone"],["🤷🏼","shrug medium light skin tone"],["🤷🏽","shrug medium skin tone"],["🤷🏾","shrug medium dark skin tone"],["🤷🏿","shrug dark skin tone"],["🤸","person doing cartwheel"],["🤸🏻","person doing cartwheel light skin tone"],["🤸🏼","person doing cartwheel medium light skin tone"],["🤸🏽","person doing cartwheel medium skin tone"],["🤸🏾","person doing cartwheel medium dark skin tone"],["🤸🏿","person doing cartwheel dark skin tone"],["🤹","juggling"],["🤹🏻","juggling light skin tone"],["🤹🏼","juggling medium light skin tone"],["🤹🏽","juggling medium skin tone"],["🤹🏾","juggling medium dark skin tone"],["🤹🏿","juggling dark skin tone"],["🤺","fencer"],["🦰","emoji component red hair"],["🦱","emoji component curly hair"],["🦲","emoji component bald"],["🦳","emoji component white hair"],["🦴","bone"],["🦵","leg"],["🦵🏻","leg light skin tone"],["🦵🏼","leg medium light skin tone"],["🦵🏽","leg medium skin tone"],["🦵🏾","leg medium dark skin tone"],["🦵🏿","leg dark skin tone"],["🦶","foot"],["🦶🏻","foot light skin tone"],["🦶🏼","foot medium light skin tone"],["🦶🏽","foot medium skin tone"],["🦶🏾","foot medium dark skin tone"],["🦶🏿","foot dark skin tone"],["🦷","tooth"],["🧑","adult"],["🧑🏻","adult light skin tone"],["🧑🏼","adult medium light skin tone"],["🧑🏽","adult medium skin tone"],["🧑🏾","adult medium dark skin tone"],["🧑🏿","adult dark skin tone"],["🧔","bearded person"],["🧔🏻","bearded person light skin tone"],["🧔🏼","bearded person medium light skin tone"],["🧔🏽","bearded person medium skin tone"],["🧔🏾","bearded person medium dark skin tone"],["🧔🏿","bearded person dark skin tone"],["🫶🏻","heart hands light skin tone"],["🫶🏼","heart hands medium light skin tone"],["🫶🏽","heart hands medium skin tone"],["🫶🏾","heart hands medium dark skin tone"],["🫶🏿","heart hands dark skin tone"],["👨‍👩‍👧‍👦","family mother father son daughter"],["👩‍👩‍👦","family two women boy"],["👨‍👨‍👧","family two men girl"],["👩‍❤️‍👨","couple with heart man woman"],["👩‍❤️‍👩","couple with heart two women"],["👨‍❤️‍👨","couple with heart two men"],["👩‍💻","woman technologist"],["👨‍💻","man technologist"],["🧑‍💻","person technologist"],["👩‍⚕️","woman doctor"],["👨‍⚕️","man doctor"],["🧑‍⚕️","doctor"],["👮‍♀️","policewoman"],["👮‍♂️","policeman"],["👩‍🚒","woman firefighter"],["👨‍🚒","man firefighter"],["👩‍🍳","woman cook"],["👨‍🍳","man cook"],["👩‍🎓","woman graduate"],["👨‍🎓","man graduate"],["👩‍🎤","woman singer"],["👨‍🎤","man singer"],["👩‍🚀","woman astronaut"],["👨‍🚀","man astronaut"]],"animals":[["🌰","chestnut"],["🌱","seedling"],["🌲","evergreen tree"],["🌳","deciduous tree"],["🌴","palm tree"],["🌵","cactus"],["🌶️","hot pepper"],["🌷","tulip"],["🌸","cherry blossom"],["🌹","rose"],["🌺","hibiscus"],["🌻","sunflower"],["🌼","blossom"],["🌽","ear of maize"],["🌾","ear of rice"],["🌿","herb"],["🍀","four leaf clover"],["🍁","maple leaf"],["🍂","fallen leaf"],["🍃","leaf fluttering in wind"],["🐀","rat"],["🐁","mouse"],["🐂","ox"],["🐃","water buffalo"],["🐄","cow"],["🐅","tiger"],["🐆","leopard"],["🐇","rabbit"],["🐈","cat"],["🐉","dragon"],["🐊","crocodile"],["🐋","whale"],["🐌","snail"],["🐍","snake"],["🐎","horse"],["🐏","ram"],["🐐","goat"],["🐑","sheep"],["🐒","monkey"],["🐓","rooster"],["🐔","chicken"],["🐕","dog"],["🐖","pig"],["🐗","boar"],["🐘","elephant"],["🐙","octopus"],["🐚","spiral shell"],["🐛","bug"],["🐜","ant"],["🐝","honeybee"],["🐞","lady beetle"],["🐟","fish"],["🐠","tropical fish"],["🐡","blowfish"],["🐢","turtle"],["🐣","hatching chick"],["🐤","baby chick"],["🐥","front-facing baby chick"],["🐦","bird"],["🐧","penguin"],["🐨","koala"],["🐩","poodle"],["🐪","dromedary camel"],["🐫","bactrian camel"],["🐬","dolphin"],["🐭","mouse face"],["🐮","cow face"],["🐯","tiger face"],["🐰","rabbit face"],["🐱","cat face"],["🐲","dragon face"],["🐳","spouting whale"],["🐴","horse face"],["🐵","monkey face"],["🐶","dog face"],["🐷","pig face"],["🐸","frog face"],["🐹","hamster face"],["🐺","wolf face"],["🐻","bear face"],["🐼","panda face"],["🐽","pig nose"],["🐾","paw prints"],["🐿️","chipmunk"],["🦀","crab"],["🦁","lion face"],["🦂","scorpion"],["🦃","turkey"],["🦄","unicorn face"],["🦅","eagle"],["🦆","duck"],["🦇","bat"],["🦈","shark"],["🦉","owl"],["🦊","fox face"],["🦋","butterfly"],["🦌","deer"],["🦍","gorilla"],["🦎","lizard"],["🦏","rhinoceros"],["🦐","shrimp"],["🦑","squid"],["🦒","giraffe face"],["🦓","zebra face"],["🦔","hedgehog"],["🦕","sauropod"],["🦖","t-rex"],["🦗","cricket"],["🦘","kangaroo"],["🦙","llama"],["🦚","peacock"],["🦛","hippopotamus"],["🦜","parrot"],["🦝","raccoon"],["🦞","lobster"],["🦟","mosquito"],["🦠","microbe"],["🦡","badger"],["🦢","swan"],["🪴","potted plant"],["🪶","feather"],["🪹","empty nest"],["🐈‍⬛","black cat"],["🐻‍❄️","polar bear"]],"food":[["🍅","tomato"],["🍆","aubergine"],["🍇","grapes"],["🍈","melon"],["🍉","watermelon"],["🍊","tangerine"],["🍋","lemon"],["🍌","banana"],["🍍","pineapple"],["🍎","red apple"],["🍏","green apple"],["🍐","pear"],["🍑","peach"],["🍒","cherries"],["🍓","strawberry"],["🍔","hamburger"],["🍕","slice of pizza"],["🍖","meat on bone"],["🍗","poultry leg"],["🍘","rice cracker"],["🍙","rice ball"],["🍚","cooked rice"],["🍛","curry and rice"],["🍜","steaming bowl"],["🍝","spaghetti"],["🍞","bread"],["🍟","french fries"],["🍠","roasted sweet potato"],["🍡","dango"],["🍢","oden"],["🍣","sushi"],["🍤","fried shrimp"],["🍥","fish cake with swirl design"],["🍦","soft ice cream"],["🍧","shaved ice"],["🍨","ice cream"],["🍩","doughnut"],["🍪","cookie"],["🍫","chocolate bar"],["🍬","candy"],["🍭","lollipop"],["🍮","custard"],["🍯","honey pot"],["🍰","shortcake"],["🍱","bento box"],["🍲","pot of food"],["🍳","cooking"],["🍴","fork and knife"],["🍵","teacup without handle"],["🍶","sake bottle and cup"],["🍷","wine glass"],["🍸","cocktail glass"],["🍹","tropical drink"],["🍺","beer mug"],["🍻","clinking beer mugs"],["🍼","baby bottle"],["🍽️","fork and knife with plate"],["🍾","bottle with popping cork"],["🍿","popcorn"],["🥐","croissant"],["🥑","avocado"],["🥒","cucumber"],["🥓","bacon"],["🥔","potato"],["🥕","carrot"],["🥖","baguette bread"],["🥗","green salad"],["🥘","shallow pan of food"],["🥙","stuffed flatbread"],["🥚","egg"],["🥛","glass of milk"],["🥜","peanuts"],["🥝","kiwifruit"],["🥞","pancakes"],["🥟","dumpling"],["🥠","fortune cookie"],["🥡","takeout box"],["🥢","chopsticks"],["🥣","bowl with spoon"],["🥤","cup with straw"],["🥥","coconut"],["🥦","broccoli"],["🥧","pie"],["🥨","pretzel"],["🥩","cut of meat"],["🥪","sandwich"],["🥫","canned food"],["🥬","leafy green"],["🥭","mango"],["🥮","moon cake"],["🥯","bagel"],["🧀","cheese wedge"],["🧁","cupcake"],["🧂","salt shaker"],["🧃","beverage box"],["🧄","garlic"],["🧅","onion"],["🧆","falafel"],["🧇","waffle"],["🧈","butter"],["🧉","mate drink"],["🧊","ice cube"],["🧋","bubble tea"],["🧌","troll"],["🧍","standing person"],["🧍🏻","standing person light skin tone"],["🧍🏼","standing person medium light skin tone"],["🧍🏽","standing person medium skin tone"],["🧍🏾","standing person medium dark skin tone"],["🧍🏿","standing person dark skin tone"],["🧎","kneeling person"],["🧎🏻","kneeling person light skin tone"],["🧎🏼","kneeling person medium light skin tone"],["🧎🏽","kneeling person medium skin tone"],["🧎🏾","kneeling person medium dark skin tone"],["🧎🏿","kneeling person dark skin tone"],["🧏","deaf person"],["🧏🏻","deaf person light skin tone"],["🧏🏼","deaf person medium light skin tone"],["🧏🏽","deaf person medium skin tone"],["🧏🏾","deaf person medium dark skin tone"],["🧏🏿","deaf person dark skin tone"],["🫐","blueberries"],["🫑","bell pepper"],["🫒","olive"],["🫓","flatbread"],["🫔","tamale"],["🫕","fondue"],["🫖","teapot"],["🫗","pouring liquid"],["🫘","beans"],["🫙","jar"],["🫚","ginger root"]],"travel":[["🌀","cyclone"],["🌁","foggy"],["🌂","closed umbrella"],["🌃","night with stars"],["🌄","sunrise over mountains"],["🌅","sunrise"],["🌆","cityscape at dusk"],["🌇","sunset over buildings"],["🌈","rainbow"],["🌉","bridge at night"],["🌊","water wave"],["🌋","volcano"],["🌌","milky way"],["🌍","earth globe europe-africa"],["🌎","earth globe americas"],["🌏","earth globe asia-australia"],["🌐","globe with meridians"],["🌑","new moon symbol"],["🌒","waxing crescent moon symbol"],["🌓","first quarter moon symbol"],["🌔","waxing gibbous moon symbol"],["🌕","full moon symbol"],["🌖","waning gibbous moon symbol"],["🌗","last quarter moon symbol"],["🌘","waning crescent moon symbol"],["🌙","crescent moon"],["🌚","new moon with face"],["🌛","first quarter moon with face"],["🌜","last quarter moon with face"],["🌝","full moon with face"],["🌞","sun with face"],["🌟","glowing star"],["🌠","shooting star"],["🌡️","thermometer"],["🏙️","cityscape"],["🏠","house building"],["🏡","house with garden"],["🏢","office building"],["🗺️","world map"],["🗻","mount fuji"],["🗼","tokyo tower"],["🗽","statue of liberty"],["🗾","silhouette of japan"],["🗿","moyai"],["🚀","rocket"],["🚁","helicopter"],["🚂","steam locomotive"],["🚃","railway car"],["🚄","high-speed train"],["🚅","high-speed train with bullet nose"],["🚆","train"],["🚇","metro"],["🚈","light rail"],["🚉","station"],["🚊","tram"],["🚋","tram car"],["🚌","bus"],["🚍","oncoming bus"],["🚎","trolleybus"],["🚏","bus stop"],["🚐","minibus"],["🚑","ambulance"],["🚒","fire engine"],["🚓","police car"],["🚔","oncoming police car"],["🚕","taxi"],["🚖","oncoming taxi"],["🚗","automobile"],["🚘","oncoming automobile"],["🚙","recreational vehicle"],["🚚","delivery truck"],["🚛","articulated lorry"],["🚜","tractor"],["🚝","monorail"],["🚞","mountain railway"],["🚟","suspension railway"],["🚠","mountain cableway"],["🚡","aerial tramway"],["🚢","ship"],["🚣","rowboat"],["🚣🏻","rowboat light skin tone"],["🚣🏼","rowboat medium light skin tone"],["🚣🏽","rowboat medium skin tone"],["🚣🏾","rowboat medium dark skin tone"],["🚣🏿","rowboat dark skin tone"],["🚤","speedboat"],["🚥","horizontal traffic light"],["🚦","vertical traffic light"],["🚧","construction sign"],["🚨","police cars revolving light"],["🚩","triangular flag on post"],["🚪","door"],["🚫","no entry sign"],["🚬","smoking symbol"],["🚭","no smoking symbol"],["🚮","put litter in its place symbol"],["🚯","do not litter symbol"],["🚰","potable water symbol"],["🚱","non-potable water symbol"],["🚲","bicycle"],["🚳","no bicycles"],["🚴","bicyclist"],["🚴🏻","bicyclist light skin tone"],["🚴🏼","bicyclist medium light skin tone"],["🚴🏽","bicyclist medium skin tone"],["🚴🏾","bicyclist medium dark skin tone"],["🚴🏿","bicyclist dark skin tone"],["🚵","mountain bicyclist"],["🚵🏻","mountain bicyclist light skin tone"],["🚵🏼","mountain bicyclist medium light skin tone"],["🚵🏽","mountain bicyclist medium skin tone"],["🚵🏾","mountain bicyclist medium dark skin tone"],["🚵🏿","mountain bicyclist dark skin tone"],["🚶","pedestrian"],["🚶🏻","pedestrian light skin tone"],["🚶🏼","pedestrian medium light skin tone"],["🚶🏽","pedestrian medium skin tone"],["🚶🏾","pedestrian medium dark skin tone"],["🚶🏿","pedestrian dark skin tone"],["🚷","no pedestrians"],["🚸","children crossing"],["🚹","mens symbol"],["🚺","womens symbol"],["🚻","restroom"],["🚼","baby symbol"],["🚽","toilet"],["🚾","water closet"],["🚿","shower"],["🛀","bath"],["🛀🏻","bath light skin tone"],["🛀🏼","bath medium light skin tone"],["🛀🏽","bath medium skin tone"],["🛀🏾","bath medium dark skin tone"],["🛀🏿","bath dark skin tone"],["🛁","bathtub"],["🛂","passport control"],["🛃","customs"],["🛄","baggage claim"],["🛅","left luggage"],["🛋️","couch and lamp"],["🛌","sleeping accommodation"],["🛌🏻","sleeping accommodation light skin tone"],["🛌🏼","sleeping accommodation medium light skin tone"],["🛌🏽","sleeping accommodation medium skin tone"],["🛌🏾","sleeping accommodation medium dark skin tone"],["🛌🏿","sleeping accommodation dark skin tone"],["🛍️","shopping bags"],["🛎️","bellhop bell"],["🛏️","bed"],["🛐","place of worship"],["🛑","octagonal sign"],["🛒","shopping trolley"],["🛕","hindu temple"],["🛖","hut"],["🛗","elevator"],["🛜","wireless"],["🛝","playground slide"],["🛞","wheel"],["🛟","ring buoy"],["🛠️","hammer and wrench"],["🛡️","shield"],["🛢️","oil drum"],["🛣️","motorway"],["🛤️","railway track"],["🛥️","motor boat"],["🛩️","small airplane"],["🛫","airplane departure"],["🛬","airplane arriving"],["🛰️","satellite"],["🛳️","passenger ship"],["🛴","scooter"],["🛵","motor scooter"],["🛶","canoe"],["🛷","sled"],["🛸","flying saucer"],["🛹","skateboard"],["🛺","auto rickshaw"],["🛻","pickup truck"],["🛼","roller skate"]],"activities":[["🎲","game die"],["⚽","soccer ball"],["⚾","baseball"],["🎠","carousel horse"],["🎡","ferris wheel"],["🎢","roller coaster"],["🎣","fishing pole and fish"],["🎤","microphone"],["🎥","movie camera"],["🎦","cinema"],["🎧","headphone"],["🎨","artist palette"],["🎩","top hat"],["🎪","circus tent"],["🎫","ticket"],["🎬","clapper board"],["🎭","performing arts"],["🎮","video game"],["🎯","direct hit"],["🎰","slot machine"],["🎱","billiards"],["🎳","bowling"],["🎴","flower playing cards"],["🎵","musical note"],["🎶","multiple musical notes"],["🎷","saxophone"],["🎸","guitar"],["🎹","musical keyboard"],["🎺","trumpet"],["🎻","violin"],["🎼","musical score"],["🎽","running shirt with sash"],["🎾","tennis racquet and ball"],["🎿","ski and ski boot"],["🏀","basketball and hoop"],["🏁","chequered flag"],["🏂","snowboarder"],["🏂🏻","snowboarder light skin tone"],["🏂🏼","snowboarder medium light skin tone"],["🏂🏽","snowboarder medium skin tone"],["🏂🏾","snowboarder medium dark skin tone"],["🏂🏿","snowboarder dark skin tone"],["🏃","runner"],["🏃🏻","runner light skin tone"],["🏃🏼","runner medium light skin tone"],["🏃🏽","runner medium skin tone"],["🏃🏾","runner medium dark skin tone"],["🏃🏿","runner dark skin tone"],["🏄","surfer"],["🏄🏻","surfer light skin tone"],["🏄🏼","surfer medium light skin tone"],["🏄🏽","surfer medium skin tone"],["🏄🏾","surfer medium dark skin tone"],["🏄🏿","surfer dark skin tone"],["🏅","sports medal"],["🏆","trophy"],["🏇","horse racing"],["🏇🏻","horse racing light skin tone"],["🏇🏼","horse racing medium light skin tone"],["🏇🏽","horse racing medium skin tone"],["🏇🏾","horse racing medium dark skin tone"],["🏇🏿","horse racing dark skin tone"],["🏈","american football"],["🏉","rugby football"],["🏊","swimmer"],["🏊🏻","swimmer light skin tone"],["🏊🏼","swimmer medium light skin tone"],["🏊🏽","swimmer medium skin tone"],["🏊🏾","swimmer medium dark skin tone"],["🏊🏿","swimmer dark skin tone"],["🤼","wrestlers"],["🤼🏻","wrestlers light skin tone"],["🤼🏼","wrestlers medium light skin tone"],["🤼🏽","wrestlers medium skin tone"],["🤼🏾","wrestlers medium dark skin tone"],["🤼🏿","wrestlers dark skin tone"],["🤽","water polo"],["🤽🏻","water polo light skin tone"],["🤽🏼","water polo medium light skin tone"],["🤽🏽","water polo medium skin tone"],["🤽🏾","water polo medium dark skin tone"],["🤽🏿","water polo dark skin tone"],["🤾","handball"],["🤾🏻","handball light skin tone"],["🤾🏼","handball medium light skin tone"],["🤾🏽","handball medium skin tone"],["🤾🏾","handball medium dark skin tone"],["🤾🏿","handball dark skin tone"],["🤿","diving mask"],["🥀","wilted flower"],["🥁","drum with drumsticks"],["🥂","clinking glasses"],["🥃","tumbler glass"],["🥄","spoon"],["🥅","goal net"],["🧩","jigsaw puzzle piece"],["🪀","yo-yo"]],"objects":[["🥺","face with pleading eyes"],["👀","eyes"],["🥳","face with party horn and party hat"],["‼️","double exclamation mark"],["⁉️","exclamation question mark"],["™️","trade mark sign"],["ℹ️","information source"],["🀄","mahjong tile red dragon"],["🃏","playing card black joker"],["🅰️","negative squared latin capital letter a"],["🅱️","negative squared latin capital letter b"],["🅾️","negative squared latin capital letter o"],["🅿️","negative squared latin capital letter p"],["🆎","negative squared ab"],["🆑","squared cl"],["🆒","squared cool"],["🆓","squared free"],["🆔","squared id"],["🆕","squared new"],["🆖","squared ng"],["🆗","squared ok"],["🆘","squared sos"],["🆙","squared up with exclamation mark"],["🆚","squared vs"],["🈁","squared katakana koko"],["🈂️","squared katakana sa"],["🈚","squared cjk unified ideograph-7121"],["🈯","squared cjk unified ideograph-6307"],["🈲","squared cjk unified ideograph-7981"],["🈳","squared cjk unified ideograph-7a7a"],["🈴","squared cjk unified ideograph-5408"],["🈵","squared cjk unified ideograph-6e80"],["🈶","squared cjk unified ideograph-6709"],["🈷️","squared cjk unified ideograph-6708"],["🈸","squared cjk unified ideograph-7533"],["🈹","squared cjk unified ideograph-5272"],["🈺","squared cjk unified ideograph-55b6"],["🉐","circled ideograph advantage"],["🉑","circled ideograph accept"],["🌤️","white sun with small cloud"],["🌥️","white sun behind cloud"],["🌦️","white sun behind cloud with rain"],["🌧️","cloud with rain"],["🌨️","cloud with snow"],["🌩️","cloud with lightning"],["🌪️","cloud with tornado"],["🌫️","fog"],["🌬️","wind blowing face"],["🌭","hot dog"],["🌮","taco"],["🌯","burrito"],["🍄","mushroom"],["🎀","ribbon"],["🎁","wrapped present"],["🎂","birthday cake"],["🎃","jack-o-lantern"],["🎄","christmas tree"],["🎅","father christmas"],["🎅🏻","father christmas light skin tone"],["🎅🏼","father christmas medium light skin tone"],["🎅🏽","father christmas medium skin tone"],["🎅🏾","father christmas medium dark skin tone"],["🎅🏿","father christmas dark skin tone"],["🎆","fireworks"],["🎇","firework sparkler"],["🎈","balloon"],["🎉","party popper"],["🎊","confetti ball"],["🎋","tanabata tree"],["🎌","crossed flags"],["🎍","pine decoration"],["🎎","japanese dolls"],["🎏","carp streamer"],["🎐","wind chime"],["🎑","moon viewing ceremony"],["🎒","school satchel"],["🎓","graduation cap"],["🎖️","military medal"],["🎗️","reminder ribbon"],["🎙️","studio microphone"],["🎚️","level slider"],["🎛️","control knobs"],["🎞️","film frames"],["🎟️","admission tickets"],["🏋️","weight lifter"],["🏋🏻","weight lifter light skin tone"],["🏋🏼","weight lifter medium light skin tone"],["🏋🏽","weight lifter medium skin tone"],["🏋🏾","weight lifter medium dark skin tone"],["🏋🏿","weight lifter dark skin tone"],["🏌️","golfer"],["🏌🏻","golfer light skin tone"],["🏌🏼","golfer medium light skin tone"],["🏌🏽","golfer medium skin tone"],["🏌🏾","golfer medium dark skin tone"],["🏌🏿","golfer dark skin tone"],["🏍️","racing motorcycle"],["🏎️","racing car"],["🏏","cricket bat and ball"],["🏐","volleyball"],["🏑","field hockey stick and ball"],["🏒","ice hockey stick and puck"],["🏓","table tennis paddle and ball"],["🏔️","snow capped mountain"],["🏕️","camping"],["🏖️","beach with umbrella"],["🏗️","building construction"],["🏘️","house buildings"],["🏚️","derelict house building"],["🏛️","classical building"],["🏜️","desert"],["🏝️","desert island"],["🏞️","national park"],["🏟️","stadium"],["🏣","japanese post office"],["🏤","european post office"],["🏥","hospital"],["🏦","bank"],["🏧","automated teller machine"],["🏨","hotel"],["🏩","love hotel"],["🏪","convenience store"],["🏫","school"],["🏬","department store"],["🏭","factory"],["🏮","izakaya lantern"],["🏯","japanese castle"],["🏰","european castle"],["🏳️","waving white flag"],["🏴","waving black flag"],["🏵️","rosette"],["🏷️","label"],["🏸","badminton racquet and shuttlecock"],["🏹","bow and arrow"],["🏺","amphora"],["👁️","eye"],["👂","ear"],["👂🏻","ear light skin tone"],["👂🏼","ear medium light skin tone"],["👂🏽","ear medium skin tone"],["👂🏾","ear medium dark skin tone"],["👂🏿","ear dark skin tone"],["👃","nose"],["👃🏻","nose light skin tone"],["👃🏼","nose medium light skin tone"],["👃🏽","nose medium skin tone"],["👃🏾","nose medium dark skin tone"],["👃🏿","nose dark skin tone"],["👄","mouth"],["👅","tongue"],["👆","white up pointing backhand index"],["👆🏻","white up pointing backhand index light skin tone"],["👆🏼","white up pointing backhand index medium light skin tone"],["👆🏽","white up pointing backhand index medium skin tone"],["👆🏾","white up pointing backhand index medium dark skin tone"],["👆🏿","white up pointing backhand index dark skin tone"],["👇","white down pointing backhand index"],["👇🏻","white down pointing backhand index light skin tone"],["👇🏼","white down pointing backhand index medium light skin tone"],["👇🏽","white down pointing backhand index medium skin tone"],["👇🏾","white down pointing backhand index medium dark skin tone"],["👇🏿","white down pointing backhand index dark skin tone"],["👈","white left pointing backhand index"],["👈🏻","white left pointing backhand index light skin tone"],["👈🏼","white left pointing backhand index medium light skin tone"],["👈🏽","white left pointing backhand index medium skin tone"],["👈🏾","white left pointing backhand index medium dark skin tone"],["👈🏿","white left pointing backhand index dark skin tone"],["👉","white right pointing backhand index"],["👉🏻","white right pointing backhand index light skin tone"],["👉🏼","white right pointing backhand index medium light skin tone"],["👉🏽","white right pointing backhand index medium skin tone"],["👉🏾","white right pointing backhand index medium dark skin tone"],["👉🏿","white right pointing backhand index dark skin tone"],["👊","fisted hand sign"],["👊🏻","fisted hand sign light skin tone"],["👊🏼","fisted hand sign medium light skin tone"],["👊🏽","fisted hand sign medium skin tone"],["👊🏾","fisted hand sign medium dark skin tone"],["👊🏿","fisted hand sign dark skin tone"],["👌","ok hand sign"],["👌🏻","ok hand sign light skin tone"],["👌🏼","ok hand sign medium light skin tone"],["👌🏽","ok hand sign medium skin tone"],["👌🏾","ok hand sign medium dark skin tone"],["👌🏿","ok hand sign dark skin tone"],["👏","clapping hands sign"],["👏🏻","clapping hands sign light skin tone"],["👏🏼","clapping hands sign medium light skin tone"],["👏🏽","clapping hands sign medium skin tone"],["👏🏾","clapping hands sign medium dark skin tone"],["👏🏿","clapping hands sign dark skin tone"],["👑","crown"],["👒","womans hat"],["👓","eyeglasses"],["👔","necktie"],["👕","t-shirt"],["👖","jeans"],["👗","dress"],["👘","kimono"],["👙","bikini"],["👚","womans clothes"],["👛","purse"],["👜","handbag"],["👝","pouch"],["👞","mans shoe"],["👟","athletic shoe"],["👠","high-heeled shoe"],["👡","womans sandal"],["👢","womans boots"],["👣","footprints"],["👤","bust in silhouette"],["👥","busts in silhouette"],["💈","barber pole"],["💉","syringe"],["💊","pill"],["💋","kiss mark"],["💌","love letter"],["💍","ring"],["💎","gem stone"],["💏","kiss"],["💏🏻","kiss light skin tone"],["💏🏼","kiss medium light skin tone"],["💏🏽","kiss medium skin tone"],["💏🏾","kiss medium dark skin tone"],["💏🏿","kiss dark skin tone"],["💐","bouquet"],["💑","couple with heart"],["💑🏻","couple with heart light skin tone"],["💑🏼","couple with heart medium light skin tone"],["💑🏽","couple with heart medium skin tone"],["💑🏾","couple with heart medium dark skin tone"],["💑🏿","couple with heart dark skin tone"],["💒","wedding"],["💓","beating heart"],["💔","broken heart"],["💕","two hearts"],["💖","sparkling heart"],["💗","growing heart"],["💘","heart with arrow"],["💝","heart with ribbon"],["💞","revolving hearts"],["💟","heart decoration"],["🕉️","om symbol"],["🕊️","dove of peace"],["🕋","kaaba"],["🕌","mosque"],["🕍","synagogue"],["🕎","menorah with nine branches"],["🕐","clock face one oclock"],["🕑","clock face two oclock"],["🕒","clock face three oclock"],["🕓","clock face four oclock"],["🕔","clock face five oclock"],["🕕","clock face six oclock"],["🕖","clock face seven oclock"],["🕗","clock face eight oclock"],["🕘","clock face nine oclock"],["🕙","clock face ten oclock"],["🕚","clock face eleven oclock"],["🕛","clock face twelve oclock"],["🕜","clock face one-thirty"],["🕝","clock face two-thirty"],["🕞","clock face three-thirty"],["🕟","clock face four-thirty"],["🕠","clock face five-thirty"],["🕡","clock face six-thirty"],["🕢","clock face seven-thirty"],["🕣","clock face eight-thirty"],["🕤","clock face nine-thirty"],["🕥","clock face ten-thirty"],["🕦","clock face eleven-thirty"],["🕧","clock face twelve-thirty"],["🕯️","candle"],["🕰️","mantelpiece clock"],["🕳️","hole"],["🕴️","man in business suit levitating"],["🕴🏻","man in business suit levitating light skin tone"],["🕴🏼","man in business suit levitating medium light skin tone"],["🕴🏽","man in business suit levitating medium skin tone"],["🕴🏾","man in business suit levitating medium dark skin tone"],["🕴🏿","man in business suit levitating dark skin tone"],["🕵️","sleuth or spy"],["🕵🏻","sleuth or spy light skin tone"],["🕵🏼","sleuth or spy medium light skin tone"],["🕵🏽","sleuth or spy medium skin tone"],["🕵🏾","sleuth or spy medium dark skin tone"],["🕵🏿","sleuth or spy dark skin tone"],["🕶️","dark sunglasses"],["🕷️","spider"],["🕸️","spider web"],["🕹️","joystick"],["🕺","man dancing"],["🕺🏻","man dancing light skin tone"],["🕺🏼","man dancing medium light skin tone"],["🕺🏽","man dancing medium skin tone"],["🕺🏾","man dancing medium dark skin tone"],["🕺🏿","man dancing dark skin tone"],["🖇️","linked paperclips"],["🖊️","lower left ballpoint pen"],["🖋️","lower left fountain pen"],["🖌️","lower left paintbrush"],["🖍️","lower left crayon"],["🖐️","raised hand with fingers splayed"],["🖐🏻","raised hand with fingers splayed light skin tone"],["🖐🏼","raised hand with fingers splayed medium light skin tone"],["🖐🏽","raised hand with fingers splayed medium skin tone"],["🖐🏾","raised hand with fingers splayed medium dark skin tone"],["🖐🏿","raised hand with fingers splayed dark skin tone"],["🖕","reversed hand with middle finger extended"],["🖕🏻","reversed hand with middle finger extended light skin tone"],["🖕🏼","reversed hand with middle finger extended medium light skin tone"],["🖕🏽","reversed hand with middle finger extended medium skin tone"],["🖕🏾","reversed hand with middle finger extended medium dark skin tone"],["🖕🏿","reversed hand with middle finger extended dark skin tone"],["🖖","raised hand with part between middle and ring fingers"],["🖖🏻","raised hand with part between middle and ring fingers light skin tone"],["🖖🏼","raised hand with part between middle and ring fingers medium light skin tone"],["🖖🏽","raised hand with part between middle and ring fingers medium skin tone"],["🖖🏾","raised hand with part between middle and ring fingers medium dark skin tone"],["🖖🏿","raised hand with part between middle and ring fingers dark skin tone"],["🖥️","desktop computer"],["🖨️","printer"],["🖱️","three button mouse"],["🖲️","trackball"],["🖼️","frame with picture"],["🗂️","card index dividers"],["🗃️","card file box"],["🗄️","file cabinet"],["🗑️","wastebasket"],["🗒️","spiral note pad"],["🗓️","spiral calendar pad"],["🗜️","compression"],["🗝️","old key"],["🗞️","rolled-up newspaper"],["🗡️","dagger knife"],["🗣️","speaking head in silhouette"],["🗨️","left speech bubble"],["🗯️","right anger bubble"],["🗳️","ballot box with ballot"],["🟠","large orange circle"],["🟡","large yellow circle"],["🟢","large green circle"],["🟣","large purple circle"],["🟤","large brown circle"],["🟥","large red square"],["🟦","large blue square"],["🟧","large orange square"],["🟨","large yellow square"],["🟩","large green square"],["🟪","large purple square"],["🟫","large brown square"],["🟰","heavy equals sign"],["🥇","first place medal"],["🥈","second place medal"],["🥉","third place medal"],["🥊","boxing glove"],["🥋","martial arts uniform"],["🥌","curling stone"],["🥍","lacrosse stick and ball"],["🥎","softball"],["🥏","flying disc"],["🥱","yawning face"],["🥴","face with uneven eyes and wavy mouth"],["🥵","overheated face"],["🥶","freezing face"],["🥷","ninja"],["🥷🏻","ninja light skin tone"],["🥷🏼","ninja medium light skin tone"],["🥷🏽","ninja medium skin tone"],["🥷🏾","ninja medium dark skin tone"],["🥷🏿","ninja dark skin tone"],["🥻","sari"],["🥼","lab coat"],["🥽","goggles"],["🥾","hiking boot"],["🥿","flat shoe"],["🦣","mammoth"],["🦤","dodo"],["🦥","sloth"],["🦦","otter"],["🦧","orangutan"],["🦨","skunk"],["🦩","flamingo"],["🦪","oyster"],["🦫","beaver"],["🦬","bison"],["🦭","seal"],["🦮","guide dog"],["🦯","probing cane"],["🦸","superhero"],["🦸🏻","superhero light skin tone"],["🦸🏼","superhero medium light skin tone"],["🦸🏽","superhero medium skin tone"],["🦸🏾","superhero medium dark skin tone"],["🦸🏿","superhero dark skin tone"],["🦹","supervillain"],["🦹🏻","supervillain light skin tone"],["🦹🏼","supervillain medium light skin tone"],["🦹🏽","supervillain medium skin tone"],["🦹🏾","supervillain medium dark skin tone"],["🦹🏿","supervillain dark skin tone"],["🦺","safety vest"],["🦻","ear with hearing aid"],["🦻🏻","ear with hearing aid light skin tone"],["🦻🏼","ear with hearing aid medium light skin tone"],["🦻🏽","ear with hearing aid medium skin tone"],["🦻🏾","ear with hearing aid medium dark skin tone"],["🦻🏿","ear with hearing aid dark skin tone"],["🦼","motorized wheelchair"],["🦽","manual wheelchair"],["🦾","mechanical arm"],["🦿","mechanical leg"],["🧐","face with monocle"],["🧒","child"],["🧒🏻","child light skin tone"],["🧒🏼","child medium light skin tone"],["🧒🏽","child medium skin tone"],["🧒🏾","child medium dark skin tone"],["🧒🏿","child dark skin tone"],["🧓","older adult"],["🧓🏻","older adult light skin tone"],["🧓🏼","older adult medium light skin tone"],["🧓🏽","older adult medium skin tone"],["🧓🏾","older adult medium dark skin tone"],["🧓🏿","older adult dark skin tone"],["🧕","person with headscarf"],["🧕🏻","person with headscarf light skin tone"],["🧕🏼","person with headscarf medium light skin tone"],["🧕🏽","person with headscarf medium skin tone"],["🧕🏾","person with headscarf medium dark skin tone"],["🧕🏿","person with headscarf dark skin tone"],["🧖","person in steamy room"],["🧖🏻","person in steamy room light skin tone"],["🧖🏼","person in steamy room medium light skin tone"],["🧖🏽","person in steamy room medium skin tone"],["🧖🏾","person in steamy room medium dark skin tone"],["🧖🏿","person in steamy room dark skin tone"],["🧗","person climbing"],["🧗🏻","person climbing light skin tone"],["🧗🏼","person climbing medium light skin tone"],["🧗🏽","person climbing medium skin tone"],["🧗🏾","person climbing medium dark skin tone"],["🧗🏿","person climbing dark skin tone"],["🧘","person in lotus position"],["🧘🏻","person in lotus position light skin tone"],["🧘🏼","person in lotus position medium light skin tone"],["🧘🏽","person in lotus position medium skin tone"],["🧘🏾","person in lotus position medium dark skin tone"],["🧘🏿","person in lotus position dark skin tone"],["🧙","mage"],["🧙🏻","mage light skin tone"],["🧙🏼","mage medium light skin tone"],["🧙🏽","mage medium skin tone"],["🧙🏾","mage medium dark skin tone"],["🧙🏿","mage dark skin tone"],["🧚","fairy"],["🧚🏻","fairy light skin tone"],["🧚🏼","fairy medium light skin tone"],["🧚🏽","fairy medium skin tone"],["🧚🏾","fairy medium dark skin tone"],["🧚🏿","fairy dark skin tone"],["🧛","vampire"],["🧛🏻","vampire light skin tone"],["🧛🏼","vampire medium light skin tone"],["🧛🏽","vampire medium skin tone"],["🧛🏾","vampire medium dark skin tone"],["🧛🏿","vampire dark skin tone"],["🧜","merperson"],["🧜🏻","merperson light skin tone"],["🧜🏼","merperson medium light skin tone"],["🧜🏽","merperson medium skin tone"],["🧜🏾","merperson medium dark skin tone"],["🧜🏿","merperson dark skin tone"],["🧝","elf"],["🧝🏻","elf light skin tone"],["🧝🏼","elf medium light skin tone"],["🧝🏽","elf medium skin tone"],["🧝🏾","elf medium dark skin tone"],["🧝🏿","elf dark skin tone"],["🧞","genie"],["🧟","zombie"],["🧠","brain"],["🧢","billed cap"],["🧣","scarf"],["🧤","gloves"],["🧥","coat"],["🧦","socks"],["🧧","red gift envelope"],["🧨","firecracker"],["🧪","test tube"],["🧫","petri dish"],["🧬","dna double helix"],["🧭","compass"],["🧮","abacus"],["🧯","fire extinguisher"],["🧰","toolbox"],["🧱","brick"],["🧲","magnet"],["🧳","luggage"],["🧴","lotion bottle"],["🧵","spool of thread"],["🧶","ball of yarn"],["🧷","safety pin"],["🧸","teddy bear"],["🧹","broom"],["🧺","basket"],["🧻","roll of paper"],["🧼","bar of soap"],["🧽","sponge"],["🧾","receipt"],["🧿","nazar amulet"],["🩰","ballet shoes"],["🩱","one-piece swimsuit"],["🩲","briefs"],["🩳","shorts"],["🩴","thong sandal"],["🩸","drop of blood"],["🩺","stethoscope"],["🩻","x-ray"],["🩼","crutch"],["🪁","kite"],["🪂","parachute"],["🪃","boomerang"],["🪄","magic wand"],["🪅","pinata"],["🪆","nesting dolls"],["🪇","maracas"],["🪈","flute"],["🪐","ringed planet"],["🪑","chair"],["🪒","razor"],["🪓","axe"],["🪔","diya lamp"],["🪕","banjo"],["🪖","military helmet"],["🪗","accordion"],["🪘","long drum"],["🪙","coin"],["🪚","carpentry saw"],["🪛","screwdriver"],["🪜","ladder"],["🪝","hook"],["🪞","mirror"],["🪟","window"],["🪠","plunger"],["🪡","sewing needle"],["🪢","knot"],["🪣","bucket"],["🪤","mouse trap"],["🪥","toothbrush"],["🪦","headstone"],["🪧","placard"],["🪨","rock"],["🪩","mirror ball"],["🪪","identification card"],["🪫","low battery"],["🪬","hamsa"],["🪭","folding hand fan"],["🪮","hair pick"],["🪯","khanda"],["🪰","fly"],["🪱","worm"],["🪲","beetle"],["🪳","cockroach"],["🪵","wood"],["🪷","lotus"],["🪸","coral"],["🪺","nest with eggs"],["🪻","hyacinth"],["🪼","jellyfish"],["🪽","wing"],["🪿","goose"],["🫀","anatomical heart"],["🫁","lungs"],["🫂","people hugging"],["🫃","pregnant man"],["🫃🏻","pregnant man light skin tone"],["🫃🏼","pregnant man medium light skin tone"],["🫃🏽","pregnant man medium skin tone"],["🫃🏾","pregnant man medium dark skin tone"],["🫃🏿","pregnant man dark skin tone"],["🫄","pregnant person"],["🫄🏻","pregnant person light skin tone"],["🫄🏼","pregnant person medium light skin tone"],["🫄🏽","pregnant person medium skin tone"],["🫄🏾","pregnant person medium dark skin tone"],["🫄🏿","pregnant person dark skin tone"],["🫅","person with crown"],["🫅🏻","person with crown light skin tone"],["🫅🏼","person with crown medium light skin tone"],["🫅🏽","person with crown medium skin tone"],["🫅🏾","person with crown medium dark skin tone"],["🫅🏿","person with crown dark skin tone"],["🫎","moose"],["🫏","donkey"],["🫛","pea pod"],["🫠","melting face"],["🫡","saluting face"],["🫢","face with open eyes and hand over mouth"],["🫣","face with peeking eye"],["🫤","face with diagonal mouth"],["🫥","dotted line face"],["🫦","biting lip"],["🫧","bubbles"],["🫨","shaking face"],["🫰","hand with index finger and thumb crossed"],["🫰🏻","hand with index finger and thumb crossed light skin tone"],["🫰🏼","hand with index finger and thumb crossed medium light skin tone"],["🫰🏽","hand with index finger and thumb crossed medium skin tone"],["🫰🏾","hand with index finger and thumb crossed medium dark skin tone"],["🫰🏿","hand with index finger and thumb crossed dark skin tone"],["🫱","rightwards hand"],["🫱🏻","rightwards hand light skin tone"],["🫱🏼","rightwards hand medium light skin tone"],["🫱🏽","rightwards hand medium skin tone"],["🫱🏾","rightwards hand medium dark skin tone"],["🫱🏿","rightwards hand dark skin tone"],["🫲","leftwards hand"],["🫲🏻","leftwards hand light skin tone"],["🫲🏼","leftwards hand medium light skin tone"],["🫲🏽","leftwards hand medium skin tone"],["🫲🏾","leftwards hand medium dark skin tone"],["🫲🏿","leftwards hand dark skin tone"],["🫳","palm down hand"],["🫳🏻","palm down hand light skin tone"],["🫳🏼","palm down hand medium light skin tone"],["🫳🏽","palm down hand medium skin tone"],["🫳🏾","palm down hand medium dark skin tone"],["🫳🏿","palm down hand dark skin tone"],["🫴","palm up hand"],["🫴🏻","palm up hand light skin tone"],["🫴🏼","palm up hand medium light skin tone"],["🫴🏽","palm up hand medium skin tone"],["🫴🏾","palm up hand medium dark skin tone"],["🫴🏿","palm up hand dark skin tone"],["🫵","index pointing at the viewer"],["🫵🏻","index pointing at the viewer light skin tone"],["🫵🏼","index pointing at the viewer medium light skin tone"],["🫵🏽","index pointing at the viewer medium skin tone"],["🫵🏾","index pointing at the viewer medium dark skin tone"],["🫵🏿","index pointing at the viewer dark skin tone"],["🫷","leftwards pushing hand"],["🫷🏻","leftwards pushing hand light skin tone"],["🫷🏼","leftwards pushing hand medium light skin tone"],["🫷🏽","leftwards pushing hand medium skin tone"],["🫷🏾","leftwards pushing hand medium dark skin tone"],["🫷🏿","leftwards pushing hand dark skin tone"],["🫸","rightwards pushing hand"],["🫸🏻","rightwards pushing hand light skin tone"],["🫸🏼","rightwards pushing hand medium light skin tone"],["🫸🏽","rightwards pushing hand medium skin tone"],["🫸🏾","rightwards pushing hand medium dark skin tone"],["🫸🏿","rightwards pushing hand dark skin tone"]],"symbols":[["🔥","fire"],["💯","hundred points symbol"],["↔️","left right arrow"],["↕️","up down arrow"],["↖️","north west arrow"],["↗️","north east arrow"],["↘️","south east arrow"],["↙️","south west arrow"],["↩️","leftwards arrow with hook"],["↪️","rightwards arrow with hook"],["⌚","watch"],["⌛","hourglass"],["⌨️","keyboard"],["⏏️","eject symbol"],["⏩","black right-pointing double triangle"],["⏪","black left-pointing double triangle"],["⏫","black up-pointing double triangle"],["⏬","black down-pointing double triangle"],["⏭️","black right-pointing double triangle with vertical bar"],["⏮️","black left-pointing double triangle with vertical bar"],["⏯️","black right-pointing triangle with double vertical bar"],["⏰","alarm clock"],["⏱️","stopwatch"],["⏲️","timer clock"],["⏳","hourglass with flowing sand"],["⏸️","double vertical bar"],["⏹️","black square for stop"],["⏺️","black circle for record"],["Ⓜ️","circled latin capital letter m"],["▪️","black small square"],["▫️","white small square"],["▶️","black right-pointing triangle"],["◀️","black left-pointing triangle"],["◻️","white medium square"],["◼️","black medium square"],["◽","white medium small square"],["◾","black medium small square"],["☀️","black sun with rays"],["☁️","cloud"],["☂️","umbrella"],["☃️","snowman"],["☄️","comet"],["☎️","black telephone"],["☑️","ballot box with check"],["☔","umbrella with rain drops"],["☕","hot beverage"],["☘️","shamrock"],["☝️","white up pointing index"],["☝🏻","white up pointing index light skin tone"],["☝🏼","white up pointing index medium light skin tone"],["☝🏽","white up pointing index medium skin tone"],["☝🏾","white up pointing index medium dark skin tone"],["☝🏿","white up pointing index dark skin tone"],["☠️","skull and crossbones"],["☢️","radioactive sign"],["☣️","biohazard sign"],["☦️","orthodox cross"],["☪️","star and crescent"],["☮️","peace symbol"],["☯️","yin yang"],["☸️","wheel of dharma"],["☹️","white frowning face"],["☺️","white smiling face"],["♀️","female sign"],["♂️","male sign"],["♈","aries"],["♉","taurus"],["♊","gemini"],["♋","cancer"],["♌","leo"],["♍","virgo"],["♎","libra"],["♏","scorpius"],["♐","sagittarius"],["♑","capricorn"],["♒","aquarius"],["♓","pisces"],["♟️","black chess pawn"],["♠️","black spade suit"],["♣️","black club suit"],["♥️","black heart suit"],["♦️","black diamond suit"],["♨️","hot springs"],["♻️","black universal recycling symbol"],["♾️","permanent paper sign"],["♿","wheelchair symbol"],["⚒️","hammer and pick"],["⚓","anchor"],["⚔️","crossed swords"],["⚕️","staff of aesculapius"],["⚖️","scales"],["⚗️","alembic"],["⚙️","gear"],["⚛️","atom symbol"],["⚜️","fleur-de-lis"],["⚠️","warning sign"],["⚡","high voltage sign"],["⚧️","male with stroke and male and female sign"],["⚪","medium white circle"],["⚫","medium black circle"],["⚰️","coffin"],["⚱️","funeral urn"],["⛄","snowman without snow"],["⛅","sun behind cloud"],["⛈️","thunder cloud and rain"],["⛎","ophiuchus"],["⛏️","pick"],["⛑️","helmet with white cross"],["⛓️","chains"],["⛔","no entry"],["⛩️","shinto shrine"],["⛪","church"],["⛰️","mountain"],["⛱️","umbrella on ground"],["⛲","fountain"],["⛳","flag in hole"],["⛴️","ferry"],["⛵","sailboat"],["⛷️","skier"],["⛸️","ice skate"],["⛹️","person with ball"],["⛹🏻","person with ball light skin tone"],["⛹🏼","person with ball medium light skin tone"],["⛹🏽","person with ball medium skin tone"],["⛹🏾","person with ball medium dark skin tone"],["⛹🏿","person with ball dark skin tone"],["⛺","tent"],["⛽","fuel pump"],["✂️","black scissors"],["✅","white heavy check mark"],["✈️","airplane"],["✉️","envelope"],["✊","raised fist"],["✊🏻","raised fist light skin tone"],["✊🏼","raised fist medium light skin tone"],["✊🏽","raised fist medium skin tone"],["✊🏾","raised fist medium dark skin tone"],["✊🏿","raised fist dark skin tone"],["✋","raised hand"],["✋🏻","raised hand light skin tone"],["✋🏼","raised hand medium light skin tone"],["✋🏽","raised hand medium skin tone"],["✋🏾","raised hand medium dark skin tone"],["✋🏿","raised hand dark skin tone"],["✌️","victory hand"],["✌🏻","victory hand light skin tone"],["✌🏼","victory hand medium light skin tone"],["✌🏽","victory hand medium skin tone"],["✌🏾","victory hand medium dark skin tone"],["✌🏿","victory hand dark skin tone"],["✍️","writing hand"],["✍🏻","writing hand light skin tone"],["✍🏼","writing hand medium light skin tone"],["✍🏽","writing hand medium skin tone"],["✍🏾","writing hand medium dark skin tone"],["✍🏿","writing hand dark skin tone"],["✏️","pencil"],["✒️","black nib"],["✔️","heavy check mark"],["✖️","heavy multiplication x"],["✝️","latin cross"],["✡️","star of david"],["✨","sparkles"],["✳️","eight spoked asterisk"],["✴️","eight pointed black star"],["❄️","snowflake"],["❇️","sparkle"],["❌","cross mark"],["❎","negative squared cross mark"],["❓","black question mark ornament"],["❔","white question mark ornament"],["❕","white exclamation mark ornament"],["❗","heavy exclamation mark symbol"],["❣️","heavy heart exclamation mark ornament"],["➕","heavy plus sign"],["➖","heavy minus sign"],["➗","heavy division sign"],["➡️","black rightwards arrow"],["➰","curly loop"],["➿","double curly loop"],["⤴️","arrow pointing rightwards then curving upwards"],["⤵️","arrow pointing rightwards then curving downwards"],["⬅️","leftwards black arrow"],["⬆️","upwards black arrow"],["⬇️","downwards black arrow"],["⬛","black large square"],["⬜","white large square"],["⭐","white medium star"],["⭕","heavy large circle"],["〰️","wavy dash"],["〽️","part alternation mark"],["㊗️","circled ideograph congratulation"],["㊙️","circled ideograph secret"],["💠","diamond shape with a dot inside"],["💡","electric light bulb"],["💢","anger symbol"],["💣","bomb"],["💤","sleeping symbol"],["💥","collision symbol"],["💦","splashing sweat symbol"],["💧","droplet"],["💨","dash symbol"],["💩","pile of poo"],["💪","flexed biceps"],["💪🏻","flexed biceps light skin tone"],["💪🏼","flexed biceps medium light skin tone"],["💪🏽","flexed biceps medium skin tone"],["💪🏾","flexed biceps medium dark skin tone"],["💪🏿","flexed biceps dark skin tone"],["💫","dizzy symbol"],["💬","speech balloon"],["💭","thought balloon"],["💮","white flower"],["💰","money bag"],["💱","currency exchange"],["💲","heavy dollar sign"],["💳","credit card"],["💴","banknote with yen sign"],["💵","banknote with dollar sign"],["💶","banknote with euro sign"],["💷","banknote with pound sign"],["💸","money with wings"],["💹","chart with upwards trend and yen sign"],["💺","seat"],["💻","personal computer"],["💼","briefcase"],["💽","minidisc"],["💾","floppy disk"],["💿","optical disc"],["📀","dvd"],["📁","file folder"],["📂","open file folder"],["📃","page with curl"],["📄","page facing up"],["📅","calendar"],["📆","tear-off calendar"],["📇","card index"],["📈","chart with upwards trend"],["📉","chart with downwards trend"],["📊","bar chart"],["📋","clipboard"],["📌","pushpin"],["📍","round pushpin"],["📎","paperclip"],["📏","straight ruler"],["📐","triangular ruler"],["📑","bookmark tabs"],["📒","ledger"],["📓","notebook"],["📔","notebook with decorative cover"],["📕","closed book"],["📖","open book"],["📗","green book"],["📘","blue book"],["📙","orange book"],["📚","books"],["📛","name badge"],["📜","scroll"],["📝","memo"],["📞","telephone receiver"],["📟","pager"],["📠","fax machine"],["📡","satellite antenna"],["📢","public address loudspeaker"],["📣","cheering megaphone"],["📤","outbox tray"],["📥","inbox tray"],["📦","package"],["📧","e-mail symbol"],["📨","incoming envelope"],["📩","envelope with downwards arrow above"],["📪","closed mailbox with lowered flag"],["📫","closed mailbox with raised flag"],["📬","open mailbox with raised flag"],["📭","open mailbox with lowered flag"],["📮","postbox"],["📯","postal horn"],["📰","newspaper"],["📱","mobile phone"],["📲","mobile phone with rightwards arrow at left"],["📳","vibration mode"],["📴","mobile phone off"],["📵","no mobile phones"],["📶","antenna with bars"],["📷","camera"],["📸","camera with flash"],["📹","video camera"],["📺","television"],["📻","radio"],["📼","videocassette"],["📽️","film projector"],["📿","prayer beads"],["🔀","twisted rightwards arrows"],["🔁","clockwise rightwards and leftwards open circle arrows"],["🔂","clockwise rightwards and leftwards open circle arrows with circled one overlay"],["🔃","clockwise downwards and upwards open circle arrows"],["🔄","anticlockwise downwards and upwards open circle arrows"],["🔅","low brightness symbol"],["🔆","high brightness symbol"],["🔇","speaker with cancellation stroke"],["🔈","speaker"],["🔉","speaker with one sound wave"],["🔊","speaker with three sound waves"],["🔋","battery"],["🔌","electric plug"],["🔍","left-pointing magnifying glass"],["🔎","right-pointing magnifying glass"],["🔏","lock with ink pen"],["🔐","closed lock with key"],["🔑","key"],["🔒","lock"],["🔓","open lock"],["🔔","bell"],["🔕","bell with cancellation stroke"],["🔖","bookmark"],["🔗","link symbol"],["🔘","radio button"],["🔙","back with leftwards arrow above"],["🔚","end with leftwards arrow above"],["🔛","on with exclamation mark with left right arrow above"],["🔜","soon with rightwards arrow above"],["🔝","top with upwards arrow above"],["🔞","no one under eighteen symbol"],["🔟","keycap ten"],["🔠","input symbol for latin capital letters"],["🔡","input symbol for latin small letters"],["🔢","input symbol for numbers"],["🔣","input symbol for symbols"],["🔤","input symbol for latin letters"],["🔦","electric torch"],["🔧","wrench"],["🔨","hammer"],["🔩","nut and bolt"],["🔪","hocho"],["🔫","pistol"],["🔬","microscope"],["🔭","telescope"],["🔮","crystal ball"],["🔯","six pointed star with middle dot"],["🔰","japanese symbol for beginner"],["🔱","trident emblem"],["🔲","black square button"],["🔳","white square button"],["🔴","large red circle"],["🔵","large blue circle"],["🔶","large orange diamond"],["🔷","large blue diamond"],["🔸","small orange diamond"],["🔹","small blue diamond"],["🔺","up-pointing red triangle"],["🔻","down-pointing red triangle"],["🔼","up-pointing small red triangle"],["🔽","down-pointing small red triangle"],["0️⃣","keycap zero"],["1️⃣","keycap one"],["2️⃣","keycap two"],["3️⃣","keycap three"],["4️⃣","keycap four"],["5️⃣","keycap five"],["6️⃣","keycap six"],["7️⃣","keycap seven"],["8️⃣","keycap eight"],["9️⃣","keycap nine"],["#️⃣","keycap hash"],["*️⃣","keycap asterisk"]],"flags":[["🇦🇨","ascension island flag"],["🇦🇩","andorra flag"],["🇦🇪","united arab emirates flag"],["🇦🇫","afghanistan flag"],["🇦🇬","antigua & barbuda flag"],["🇦🇮","anguilla flag"],["🇦🇱","albania flag"],["🇦🇲","armenia flag"],["🇦🇴","angola flag"],["🇦🇶","antarctica flag"],["🇦🇷","argentina flag"],["🇦🇸","american samoa flag"],["🇦🇹","austria flag"],["🇦🇺","australia flag"],["🇦🇼","aruba flag"],["🇦🇽","åland islands flag"],["🇦🇿","azerbaijan flag"],["🇧🇦","bosnia & herzegovina flag"],["🇧🇧","barbados flag"],["🇧🇩","bangladesh flag"],["🇧🇪","belgium flag"],["🇧🇫","burkina faso flag"],["🇧🇬","bulgaria flag"],["🇧🇭","bahrain flag"],["🇧🇮","burundi flag"],["🇧🇯","benin flag"],["🇧🇱","st. barthélemy flag"],["🇧🇲","bermuda flag"],["🇧🇳","brunei flag"],["🇧🇴","bolivia flag"],["🇧🇶","caribbean netherlands flag"],["🇧🇷","brazil flag"],["🇧🇸","bahamas flag"],["🇧🇹","bhutan flag"],["🇧🇻","bouvet island flag"],["🇧🇼","botswana flag"],["🇧🇾","belarus flag"],["🇧🇿","belize flag"],["🇨🇦","canada flag"],["🇨🇨","cocos (keeling) islands flag"],["🇨🇩","congo - kinshasa flag"],["🇨🇫","central african republic flag"],["🇨🇬","congo - brazzaville flag"],["🇨🇭","switzerland flag"],["🇨🇮","côte d’ivoire flag"],["🇨🇰","cook islands flag"],["🇨🇱","chile flag"],["🇨🇲","cameroon flag"],["🇨🇳","china flag"],["🇨🇴","colombia flag"],["🇨🇵","clipperton island flag"],["🇨🇶","sark flag"],["🇨🇷","costa rica flag"],["🇨🇺","cuba flag"],["🇨🇻","cape verde flag"],["🇨🇼","curaçao flag"],["🇨🇽","christmas island flag"],["🇨🇾","cyprus flag"],["🇨🇿","czechia flag"],["🇩🇪","germany flag"],["🇩🇬","diego garcia flag"],["🇩🇯","djibouti flag"],["🇩🇰","denmark flag"],["🇩🇲","dominica flag"],["🇩🇴","dominican republic flag"],["🇩🇿","algeria flag"],["🇪🇦","ceuta & melilla flag"],["🇪🇨","ecuador flag"],["🇪🇪","estonia flag"],["🇪🇬","egypt flag"],["🇪🇭","western sahara flag"],["🇪🇷","eritrea flag"],["🇪🇸","spain flag"],["🇪🇹","ethiopia flag"],["🇪🇺","european union flag"],["🇪🇿","eurozone flag"],["🇫🇮","finland flag"],["🇫🇯","fiji flag"],["🇫🇰","falkland islands flag"],["🇫🇲","micronesia flag"],["🇫🇴","faroe islands flag"],["🇫🇷","france flag"],["🇬🇦","gabon flag"],["🇬🇧","united kingdom flag"],["🇬🇩","grenada flag"],["🇬🇪","georgia flag"],["🇬🇫","french guiana flag"],["🇬🇬","guernsey flag"],["🇬🇭","ghana flag"],["🇬🇮","gibraltar flag"],["🇬🇱","greenland flag"],["🇬🇲","gambia flag"],["🇬🇳","guinea flag"],["🇬🇵","guadeloupe flag"],["🇬🇶","equatorial guinea flag"],["🇬🇷","greece flag"],["🇬🇸","south georgia & south sandwich islands flag"],["🇬🇹","guatemala flag"],["🇬🇺","guam flag"],["🇬🇼","guinea-bissau flag"],["🇬🇾","guyana flag"],["🇭🇰","hong kong sar china flag"],["🇭🇲","heard & mcdonald islands flag"],["🇭🇳","honduras flag"],["🇭🇷","croatia flag"],["🇭🇹","haiti flag"],["🇭🇺","hungary flag"],["🇮🇨","canary islands flag"],["🇮🇩","indonesia flag"],["🇮🇪","ireland flag"],["🇮🇱","israel flag"],["🇮🇲","isle of man flag"],["🇮🇳","india flag"],["🇮🇴","british indian ocean territory flag"],["🇮🇶","iraq flag"],["🇮🇷","iran flag"],["🇮🇸","iceland flag"],["🇮🇹","italy flag"],["🇯🇪","jersey flag"],["🇯🇲","jamaica flag"],["🇯🇴","jordan flag"],["🇯🇵","japan flag"],["🇰🇪","kenya flag"],["🇰🇬","kyrgyzstan flag"],["🇰🇭","cambodia flag"],["🇰🇮","kiribati flag"],["🇰🇲","comoros flag"],["🇰🇳","st. kitts & nevis flag"],["🇰🇵","north korea flag"],["🇰🇷","south korea flag"],["🇰🇼","kuwait flag"],["🇰🇾","cayman islands flag"],["🇰🇿","kazakhstan flag"],["🇱🇦","laos flag"],["🇱🇧","lebanon flag"],["🇱🇨","st. lucia flag"],["🇱🇮","liechtenstein flag"],["🇱🇰","sri lanka flag"],["🇱🇷","liberia flag"],["🇱🇸","lesotho flag"],["🇱🇹","lithuania flag"],["🇱🇺","luxembourg flag"],["🇱🇻","latvia flag"],["🇱🇾","libya flag"],["🇲🇦","morocco flag"],["🇲🇨","monaco flag"],["🇲🇩","moldova flag"],["🇲🇪","montenegro flag"],["🇲🇫","st. martin flag"],["🇲🇬","madagascar flag"],["🇲🇭","marshall islands flag"],["🇲🇰","north macedonia flag"],["🇲🇱","mali flag"],["🇲🇲","myanmar (burma) flag"],["🇲🇳","mongolia flag"],["🇲🇴","macao sar china flag"],["🇲🇵","northern mariana islands flag"],["🇲🇶","martinique flag"],["🇲🇷","mauritania flag"],["🇲🇸","montserrat flag"],["🇲🇹","malta flag"],["🇲🇺","mauritius flag"],["🇲🇻","maldives flag"],["🇲🇼","malawi flag"],["🇲🇽","mexico flag"],["🇲🇾","malaysia flag"],["🇲🇿","mozambique flag"],["🇳🇦","namibia flag"],["🇳🇨","new caledonia flag"],["🇳🇪","niger flag"],["🇳🇫","norfolk island flag"],["🇳🇬","nigeria flag"],["🇳🇮","nicaragua flag"],["🇳🇱","netherlands flag"],["🇳🇴","norway flag"],["🇳🇵","nepal flag"],["🇳🇷","nauru flag"],["🇳🇺","niue flag"],["🇳🇿","new zealand flag"],["🇴🇲","oman flag"],["🇵🇦","panama flag"],["🇵🇪","peru flag"],["🇵🇫","french polynesia flag"],["🇵🇬","papua new guinea flag"],["🇵🇭","philippines flag"],["🇵🇰","pakistan flag"],["🇵🇱","poland flag"],["🇵🇲","st. pierre & miquelon flag"],["🇵🇳","pitcairn islands flag"],["🇵🇷","puerto rico flag"],["🇵🇸","palestinian territories flag"],["🇵🇹","portugal flag"],["🇵🇼","palau flag"],["🇵🇾","paraguay flag"],["🇶🇦","qatar flag"],["🇶🇴","outlying oceania flag"],["🇷🇪","réunion flag"],["🇷🇴","romania flag"],["🇷🇸","serbia flag"],["🇷🇺","russia flag"],["🇷🇼","rwanda flag"],["🇸🇦","saudi arabia flag"],["🇸🇧","solomon islands flag"],["🇸🇨","seychelles flag"],["🇸🇩","sudan flag"],["🇸🇪","sweden flag"],["🇸🇬","singapore flag"],["🇸🇭","st. helena flag"],["🇸🇮","slovenia flag"],["🇸🇯","svalbard & jan mayen flag"],["🇸🇰","slovakia flag"],["🇸🇱","sierra leone flag"],["🇸🇲","san marino flag"],["🇸🇳","senegal flag"],["🇸🇴","somalia flag"],["🇸🇷","suriname flag"],["🇸🇸","south sudan flag"],["🇸🇹","são tomé & príncipe flag"],["🇸🇻","el salvador flag"],["🇸🇽","sint maarten flag"],["🇸🇾","syria flag"],["🇸🇿","eswatini flag"],["🇹🇦","tristan da cunha flag"],["🇹🇨","turks & caicos islands flag"],["🇹🇩","chad flag"],["🇹🇫","french southern territories flag"],["🇹🇬","togo flag"],["🇹🇭","thailand flag"],["🇹🇯","tajikistan flag"],["🇹🇰","tokelau flag"],["🇹🇱","timor-leste flag"],["🇹🇲","turkmenistan flag"],["🇹🇳","tunisia flag"],["🇹🇴","tonga flag"],["🇹🇷","türkiye flag"],["🇹🇹","trinidad & tobago flag"],["🇹🇻","tuvalu flag"],["🇹🇼","taiwan flag"],["🇹🇿","tanzania flag"],["🇺🇦","ukraine flag"],["🇺🇬","uganda flag"],["🇺🇲","u.s. outlying islands flag"],["🇺🇳","united nations flag"],["🇺🇸","united states flag"],["🇺🇾","uruguay flag"],["🇺🇿","uzbekistan flag"],["🇻🇦","vatican city flag"],["🇻🇨","st. vincent & grenadines flag"],["🇻🇪","venezuela flag"],["🇻🇬","british virgin islands flag"],["🇻🇮","u.s. virgin islands flag"],["🇻🇳","vietnam flag"],["🇻🇺","vanuatu flag"],["🇼🇫","wallis & futuna flag"],["🇼🇸","samoa flag"],["🇽🇦","pseudo-accents flag"],["🇽🇧","pseudo-bidi flag"],["🇽🇰","kosovo flag"],["🇾🇪","yemen flag"],["🇾🇹","mayotte flag"],["🇿🇦","south africa flag"],["🇿🇲","zambia flag"],["🇿🇼","zimbabwe flag"],["🇿🇿","unknown region flag"],["🏳️‍🌈","rainbow flag"],["🏴‍☠️","pirate flag"]]};
const EMOJI_TABS = [
  ['recent','◷'],['smileys','☺'],['people','✋'],['animals','🐻'],['food','🍕'],
  ['travel','🚗'],['activities','⚽'],['objects','💡'],['symbols','♥'],['flags','⚑']
];
const EMOJI_LOCALE = {
  tr: { title:'EMOJİLER', search:'Emoji ara…', footer:'Unicode emojileri • çevrimdışı', recent:'Son kullanılanlar', smileys:'Yüzler',people:'İnsanlar',animals:'Hayvanlar',food:'Yiyecek',travel:'Seyahat',activities:'Aktiviteler',objects:'Nesneler',symbols:'Semboller',flags:'Bayraklar',empty:'Emoji bulunamadı',limit:'Mesaj sınırına ulaştın' },
  en: { title:'EMOJI', search:'Search emoji…', footer:'Unicode emojis • offline', recent:'Recent',smileys:'Smileys',people:'People',animals:'Animals',food:'Food',travel:'Travel',activities:'Activities',objects:'Objects',symbols:'Symbols',flags:'Flags',empty:'No emojis found',limit:'Message is full' },
  de: { title:'EMOJIS', search:'Emojis suchen…',footer:'Unicode-Emojis • offline',recent:'Zuletzt',smileys:'Smileys',people:'Menschen',animals:'Tiere',food:'Essen',travel:'Reisen',activities:'Aktivitäten',objects:'Objekte',symbols:'Symbole',flags:'Flaggen',empty:'Keine Emojis gefunden',limit:'Nachricht ist voll' },
  es: { title:'EMOJIS', search:'Buscar emojis…',footer:'Emojis Unicode • sin conexión',recent:'Recientes',smileys:'Caras',people:'Personas',animals:'Animales',food:'Comida',travel:'Viajes',activities:'Actividades',objects:'Objetos',symbols:'Símbolos',flags:'Banderas',empty:'Sin resultados',limit:'Mensaje completo' },
  fr: { title:'EMOJIS', search:'Chercher un emoji…',footer:'Emojis Unicode • hors ligne',recent:'Récents',smileys:'Visages',people:'Personnes',animals:'Animaux',food:'Cuisine',travel:'Voyages',activities:'Activités',objects:'Objets',symbols:'Symboles',flags:'Drapeaux',empty:'Aucun emoji',limit:'Message complet' }
};
let emojiTab = 'smileys';
let emojiItems = [];
let emojiRendered = 0;
let emojiRecent = safeJSON('vgchat.emojiRecent', []);
if (!Array.isArray(emojiRecent)) emojiRecent = [];
function emojiText(key) { return (EMOJI_LOCALE[state.locale] || EMOJI_LOCALE.en)[key] || key; }
function localizeEmoji() {
  if (!el.emojiPanel) return;
  el.emojiHeading.textContent = emojiText('title');
  el.emojiSearch.placeholder = emojiText('search');
  el.emojiFooter.textContent = emojiText('footer');
  el.emojiButton.title = emojiText('title');
  renderEmojiTabs();
}
function renderEmojiTabs() {
  if (!el.emojiCategories) return;
  el.emojiCategories.innerHTML = EMOJI_TABS.map(([name, icon]) =>
    `<button type="button" class="emojiTab ${emojiTab === name ? 'active' : ''}" data-emoji-tab="${name}" title="${esc(emojiText(name))}" aria-label="${esc(emojiText(name))}" aria-selected="${emojiTab === name}">${icon}</button>`).join('');
}
function emojiAllEntries() {
  return Object.values(EMOJI_CATALOG).flat();
}
function emojiFilteredItems() {
  const q = el.emojiSearch.value.trim().toLocaleLowerCase('en');
  if (q) {
    const words = q.split(/\s+/).filter(Boolean);
    return emojiAllEntries().filter(([, name]) => words.every(w => name.toLowerCase().includes(w)));
  }
  if (emojiTab === 'recent') {
    const byEmoji = new Map(emojiAllEntries().map(pair => [pair[0],pair]));
    return emojiRecent.map(emoji => byEmoji.get(emoji) || [emoji,emoji]);
  }
  return EMOJI_CATALOG[emojiTab] || [];
}
function appendEmojiPage() {
  if (emojiRendered >= emojiItems.length) return;
  const next = emojiItems.slice(emojiRendered,emojiRendered+100);
  el.emojiGrid.insertAdjacentHTML('beforeend',next.map(([glyph,name],i) =>
    `<button type="button" class="emojiTile" data-emoji-index="${emojiRendered+i}" aria-label="${esc(name)}" title="${esc(name)}">${esc(glyph)}</button>`).join(''));
  emojiRendered += next.length;
}
function renderEmojiGrid() {
  emojiItems = emojiFilteredItems(); emojiRendered = 0; el.emojiGrid.innerHTML = '';
  el.emojiGrid.scrollTop = 0;
  if (!emojiItems.length) {
    el.emojiGrid.innerHTML = `<span class="emojiEmpty">${esc(emojiText('empty'))}</span>`;
    return;
  }
  appendEmojiPage();
}
function closeEmoji() {
  if (!el.emojiPanel) return;
  el.emojiPanel.classList.add('hidden');
  el.emojiButton.setAttribute('aria-expanded','false');
}
function openEmoji() {
  closeTools();
  el.settings.classList.add('hidden');
  el.historyPanel.classList.add('hidden');
  el.screenshotPanel.classList.add('hidden');
  el.suggestions.classList.add('hidden');
  const composerBounds = el.composer.getBoundingClientRect();
  const spaceTop = composerBounds.top;
  const spaceBottom = window.innerHeight - composerBounds.bottom;
  const putAbove = spaceTop >= 390 || (spaceTop > spaceBottom && spaceBottom < 300);
  el.emojiPanel.style.top = putAbove ? 'auto' : 'calc(100% + 6px)';
  el.emojiPanel.style.bottom = putAbove ? 'calc(100% + 6px)' : 'auto';
  el.emojiPanel.style.maxHeight = `${Math.max(180, Math.min(380, (putAbove ? spaceTop : spaceBottom) - 16))}px`;
  el.emojiPanel.classList.remove('hidden');
  el.emojiButton.setAttribute('aria-expanded','true');
  renderEmojiTabs(); renderEmojiGrid();
  el.emojiSearch.focus();
}
function insertEmoji(glyph) {
  const start = el.input.selectionStart ?? el.input.value.length;
  const end = el.input.selectionEnd ?? start;
  const prospective = el.input.value.slice(0,start)+glyph+el.input.value.slice(end);
  if (prospective.length > el.input.maxLength) {hint(emojiText('limit'));return;}
  el.input.setRangeText(glyph,start,end,'end');
  emojiRecent = [glyph,...emojiRecent.filter(v=>v!==glyph)].slice(0,40);
  localStorage.setItem('vgchat.emojiRecent',JSON.stringify(emojiRecent));
  el.input.dispatchEvent(new Event('input',{bubbles:true}));
  el.input.focus();
}
el.emojiButton.addEventListener('click',()=>{
  if (el.emojiPanel.classList.contains('hidden')) openEmoji();
  else {closeEmoji();el.input.focus();renderSuggestions();}
});
el.emojiClose.addEventListener('click',()=>{closeEmoji();el.input.focus();renderSuggestions();});
el.emojiSearch.addEventListener('input',renderEmojiGrid);
el.emojiSearch.addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();closeEmoji();el.input.focus();renderSuggestions();}
});
el.emojiCategories.addEventListener('click',e=>{
  const button=e.target.closest('[data-emoji-tab]'); if(!button)return;
  emojiTab=button.dataset.emojiTab;el.emojiSearch.value='';renderEmojiTabs();renderEmojiGrid();
});
el.emojiGrid.addEventListener('click',e=>{
  const button=e.target.closest('[data-emoji-index]');if(!button)return;
  const pair=emojiItems[Number(button.dataset.emojiIndex)]; if(pair)insertEmoji(pair[0]);
});
el.emojiGrid.addEventListener('scroll',()=>{
  if(el.emojiGrid.scrollTop+el.emojiGrid.clientHeight>=el.emojiGrid.scrollHeight-115)appendEmojiPage();
});

applySettings();
applyLayout();
applyLocale(state.locale);
activateSettingsTab(state.currentTab);
syncAccessibility();
syncOverhead();
setTimeout(() => {
  syncClientColors();
  syncOverheadStyle();
  post('setLocale', { locale: state.locale });
  syncOverhead();
}, 250);

function messageHTML(m) {
  const type = String(m.type || 'system');
  const author = esc(m.author || '');
  const text = esc(m.text || '');
  const channel = esc(m.channel || '');
  const resultText = esc(m.resultText || (typeof m.success === 'boolean' ? t(m.success ? 'try_success' : 'try_fail') : ''));

  if (type === 'me') {
    return `<span class="msgType">ME</span><span class="author">${author}</span> <span>${text}</span>`;
  }
  if (type === 'do') {
    return `<span class="msgType">DO</span><span>${text}</span>${author ? ` <span class="author">((${author}))</span>` : ''}`;
  }
  if (type === 'dice') {
    const result = Number(m.result) || 0;
    const max = Number(m.max) || 12;
    return `<span class="msgType diceIcon">◆</span><span class="author">${author}</span> <span>${esc(t('dice_rolled', { result, max }))}</span>`;
  }
  if (type === 'try-success' || type === 'try-fail') {
    return `<span class="meta">* </span><span class="author">${author}</span> <span>${text}</span>${resultText ? ` <span class="meta">— ${resultText}</span>` : ''}`;
  }
  if (type === 'jobp' || type === 'jobc') {
    return `<span class="meta">[${channel || (type === 'jobp' ? 'PD' : 'EMS')}]</span> <span class="author">${author}:</span> <span>${text}</span>`;
  }
  if (type === 'pm-in') {
    const senderId = Number(m.senderId);
    const id = Number.isFinite(senderId) ? `<span class="pmId">#${senderId}</span>` : '';
    return `<span class="pmBadge">PM</span><span class="pmDirection">${esc(t('incoming'))}</span> ${id} <span class="author">${author}</span><span class="pmColon">:</span> <span class="pmText">${text}</span>`;
  }
  if (type === 'pm-out') {
    const targetId = Number(m.targetId);
    const id = Number.isFinite(targetId) ? `<span class="pmId">#${targetId}</span>` : '';
    return `<span class="pmBadge">PM</span><span class="pmDirection">${esc(t('outgoing'))}</span> <span class="pmSelf">${esc(t('you'))}</span> ${id} <span class="author">${author}</span><span class="pmColon">:</span> <span class="pmText">${text}</span>`;
  }
  if (type === 'error') {
    return `<span class="meta">* </span><span>${esc(m.localeKey ? t(m.localeKey, m.vars || {}) : m.text || '')}</span>`;
  }
  return `${author ? `<span class="author">${author}</span> ` : ''}<span>${text}</span>`;
}

function scheduleExpiry(row) {
  const old = state.expireTimers.get(row);
  if (old) old.forEach(clearTimeout);

  const fadeAt = Math.max(1000, state.fadeTime * 1000 - 350);
  const t1 = setTimeout(() => {
    if (!state.open) row.classList.add('expiring');
  }, fadeAt);
  const t2 = setTimeout(() => {
    row.classList.remove('expiring');
    row.classList.add('expired');
  }, state.fadeTime * 1000);
  state.expireTimers.set(row, [t1, t2]);
}

function addMessage(m) {
  const row = document.createElement('div');
  const type = String(m.type || 'system');
  row.className = `msg ${type}`;
  row.innerHTML = messageHTML(m);
  row._messageData = m;
  row.dataset.createdAt = String(Date.now());

  el.messages.appendChild(row);
  state.messages.push(row);
  if (!el.historyPanel.classList.contains('hidden') && state.historyTab === 'chat') renderHistory();

  while (state.messages.length > state.maxHistory) {
    const old = state.messages.shift();
    const timers = state.expireTimers.get(old);
    if (timers) timers.forEach(clearTimeout);
    state.expireTimers.delete(old);
    old.remove();
  }

  scheduleExpiry(row);
  requestAnimationFrame(() => {
    el.messages.scrollTop = el.messages.scrollHeight;
  });
}

function clearMessages() {
  // /clear clears the visible chat AND the up/down-arrow /me-/do command history.
  state.commandHistory = [];
  state.historyRevision++; // invalidates any in-flight NUI submit response
  state.historyIndex = -1;
  localStorage.removeItem('vgchat.commandHistory');
  for (const timers of state.expireTimers.values()) timers.forEach(clearTimeout);
  state.expireTimers.clear();
  state.messages.length = 0;
  el.messages.innerHTML = '';
  renderHistory();
}

function showAllHistory() {
  for (const row of state.messages) {
    row.classList.remove('expiring');
  }
  requestAnimationFrame(() => { el.messages.scrollTop = el.messages.scrollHeight; });
}

function refreshClosedVisibility() {
  if (state.open) return;
  const now = Date.now();
  for (const row of state.messages) {
    const age = now - Number(row.dataset.createdAt || now);
    row.classList.toggle('expired', age >= state.fadeTime * 1000);
  }
}

function queryParts() {
  const raw = el.input.value.trim().replace(/^\//, '').toLowerCase();
  return { raw, first: raw.split(/\s+/)[0] || '' };
}

function filtered() {
  const { first } = queryParts();
  if (!first) return [];

  return state.suggestions
    .filter(s => {
      const name = String(s.name || '').toLowerCase();
      if (name === 'roll' && state.locale === 'tr' && first !== 'roll') return false;
      if (name === 'zar' && state.locale !== 'tr' && first !== 'zar') return false;
      return true;
    })
    .filter(s => {
      const name = String(s.name || '').toLowerCase();
      return name.startsWith(first); // only prefix matches: /re should not show unrelated commands
    })
    .sort((a, b) => {
      const an = a.name.toLowerCase();
      const bn = b.name.toLowerCase();
      const as = an.startsWith(first) ? 0 : 1;
      const bs = bn.startsWith(first) ? 0 : 1;
      return as - bs || an.localeCompare(bn);
    })
    .slice(0, 6);
}

function hi(name, q) {
  const lower = String(name).toLowerCase();
  const i = lower.indexOf(q);
  if (i < 0) return esc(name);
  return `${esc(name.slice(0, i))}<b>${esc(name.slice(i, i + q.length))}</b>${esc(name.slice(i + q.length))}`;
}

function renderSuggestions() {
  const list = filtered();
  const panelOpen = !el.settings.classList.contains('hidden') || !el.historyPanel.classList.contains('hidden') || !el.screenshotPanel.classList.contains('hidden') || state.toolMenuOpen || !el.emojiPanel.classList.contains('hidden');
  if (!list.length || !state.open || panelOpen || state.layoutMode) {
    el.suggestions.classList.add('hidden');
    return;
  }

  state.selected = clamp(state.selected, 0, list.length - 1);
  const q = queryParts().first;
  const autoCommandDescription = {tr:'Diğer script komutu',en:'Script command',de:'Skriptbefehl',fr:'Commande de script',es:'Comando de script'}[state.locale] || 'Script command';
  el.suggestions.innerHTML = list.map((s, i) => `
    <div class="suggestion ${i === state.selected ? 'active' : ''}" data-i="${i}">
      <div class="s-name">${hi(s.name, q)}</div>
      <div class="s-desc">${esc(t(`command_${s.name === 'zar' ? 'roll' : s.name}`) !== `command_${s.name === 'zar' ? 'roll' : s.name}` ? t(`command_${s.name === 'zar' ? 'roll' : s.name}`) : s.description || autoCommandDescription)}</div>
    </div>
  `).join('');
  el.suggestions.classList.remove('hidden');
}

function completeSelected() {
  const list = filtered();
  if (!list.length) return false;
  const s = list[state.selected] || list[0];
  const hadSlash = el.input.value.trim().startsWith('/');
  el.input.value = (hadSlash ? '/' : '') + s.name + ' ';
  el.input.focus();
  renderSuggestions();
  return true;
}

function saveCommandHistory(text) {
  if (!text) return;
  state.commandHistory = [text, ...state.commandHistory.filter(v => v !== text)].slice(0, 50);
  // Do not persist commands/emotes across reconnects.
}

function renderHistory() {
  el.chatHistoryTab.classList.toggle('active', state.historyTab === 'chat');
  el.commandHistoryTab.classList.toggle('active', state.historyTab === 'commands');
  if (state.historyTab === 'commands') return renderCommandHistory();
  if (!state.messages.length) {
    el.historyList.innerHTML = `<div class="historyEmpty">${esc(t('empty_chat'))}</div>`;
    return;
  }
  el.historyList.innerHTML = state.messages.slice(-60).map(row => {
    const data = row._messageData || {};
    const date = new Date(Number(row.dataset.createdAt) || Date.now());
    const time = date.toLocaleTimeString(state.locale === 'tr' ? 'tr-TR' : state.locale, { hour:'2-digit',minute:'2-digit' });
    return `<div class="historyChatItem"><span class="historyTime">${esc(time)}</span><div class="msg ${esc(data.type || 'system')}">${messageHTML(data)}</div></div>`;
  }).join('');
  el.historyList.scrollTop = el.historyList.scrollHeight;
}

function renderCommandHistory() {
  if (!state.commandHistory.length) {
    el.historyList.innerHTML = `<div class="historyEmpty">${esc(t('empty_history'))}</div>`;
    return;
  }
  el.historyList.innerHTML = state.commandHistory.slice(0, 14).map((item, i) => `
    <div class="historyItem" data-history="${i}">${esc(item)}</div>
  `).join('');
}

function closeTools() {
  state.toolMenuOpen = false;
  el.toolbar.classList.add('hidden');
  el.menuButton.setAttribute('aria-expanded', 'false');
}

function closePanels() {
  closeEmoji();
  closeTools();
  el.settings.classList.add('hidden');
  el.historyPanel.classList.add('hidden');
  el.screenshotPanel.classList.add('hidden');
}

function setLayoutMode(enabled) {
  state.layoutMode = Boolean(enabled);
  el.chat.classList.toggle('layout-mode', state.layoutMode);
  el.layoutButton.textContent = t(state.layoutMode ? 'save_layout' : 'edit_layout');
  el.suggestions.classList.add('hidden');
  if (!state.layoutMode) saveLayout();
}

function open(settingsOnly = false) {
  state.open = true;
  el.chat.classList.add('is-open');
  el.composer.classList.remove('hidden');
  el.hint.textContent = '';
  closePanels();
  showAllHistory();

  if (settingsOnly) {
    el.settings.classList.remove('hidden');
    el.suggestions.classList.add('hidden');
  } else {
    setTimeout(() => el.input.focus(), 0);
  }
}

function close() {
  state.open = false;
  setLayoutMode(false);
  el.chat.classList.remove('is-open');
  el.composer.classList.add('hidden');
  closePanels();
  el.suggestions.classList.add('hidden');
  el.input.value = '';
  state.historyIndex = -1;
  refreshClosedVisibility();
  if (state.typingIdleTimer) {
    clearTimeout(state.typingIdleTimer);
    state.typingIdleTimer = null;
  }
  // Client Lua owns typing from chat open/close, never from input text.
  post('close');
}

function pulseTyping() {
  // Typing status starts on T and remains active until chat loses focus.
  // No NUI input or idle callback may cancel it prematurely.
}

el.input.addEventListener('input', () => {
  state.selected = 0;
  state.historyIndex = -1;
  renderSuggestions();
  pulseTyping();
});

el.input.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    e.preventDefault();
    close();
    return;
  }

  if (e.key === 'ArrowDown' && !el.suggestions.classList.contains('hidden')) {
    e.preventDefault();
    state.selected++;
    renderSuggestions();
    return;
  }

  if (e.key === 'ArrowUp' && !el.suggestions.classList.contains('hidden')) {
    e.preventDefault();
    state.selected = Math.max(0, state.selected - 1);
    renderSuggestions();
    return;
  }

  if (e.key === 'ArrowUp' && el.suggestions.classList.contains('hidden') && state.commandHistory.length) {
    e.preventDefault();
    state.historyIndex = Math.min(state.historyIndex + 1, state.commandHistory.length - 1);
    el.input.value = state.commandHistory[state.historyIndex] || '';
    return;
  }

  if (e.key === 'ArrowDown' && el.suggestions.classList.contains('hidden') && state.historyIndex >= 0) {
    e.preventDefault();
    state.historyIndex = Math.max(-1, state.historyIndex - 1);
    el.input.value = state.historyIndex >= 0 ? state.commandHistory[state.historyIndex] : '';
    return;
  }

  if (e.key === 'Tab') {
    e.preventDefault();
    completeSelected();
    return;
  }

  if (e.key === 'Enter') {
    e.preventDefault();
    const text = el.input.value.trim();
    if (!text) return close();
    // Only record actually executed commands. No bare text or rejected inputs.
    const bare = text.replace(/^\//, '').split(/\s+/)[0].toLowerCase();
    const submittedAtRevision = state.historyRevision;
    post('submit', { text }).then(result => {
      if (submittedAtRevision === state.historyRevision && result && result.ok && result.executed && bare !== 'clear') saveCommandHistory(text);
    });
    el.input.value = '';
    el.suggestions.classList.add('hidden');
    close();
  }
});

el.suggestions.addEventListener('mousedown', e => {
  const row = e.target.closest('.suggestion');
  if (!row) return;
  e.preventDefault();
  state.selected = Number(row.dataset.i) || 0;
  completeSelected();
});

el.menuButton.addEventListener('click', () => {
  state.toolMenuOpen = !state.toolMenuOpen;
  el.toolbar.classList.toggle('hidden', !state.toolMenuOpen);
  el.menuButton.setAttribute('aria-expanded', String(state.toolMenuOpen));
  el.suggestions.classList.add('hidden');
  if (!state.toolMenuOpen) renderSuggestions();
});

el.settingsButton.addEventListener('click', () => {
  closeTools();
  el.historyPanel.classList.add('hidden');
  el.screenshotPanel.classList.add('hidden');
  el.settings.classList.toggle('hidden');
  el.suggestions.classList.add('hidden');
  if (el.settings.classList.contains('hidden')) {
    setLayoutMode(false);
    el.input.focus();
    renderSuggestions();
  }
});

el.historyButton.addEventListener('click', () => {
  closeTools();
  el.settings.classList.add('hidden');
  el.screenshotPanel.classList.add('hidden');
  setLayoutMode(false);
  renderHistory();
  el.historyPanel.classList.toggle('hidden');
  el.suggestions.classList.add('hidden');
  if (el.historyPanel.classList.contains('hidden')) {
    el.input.focus();
    renderSuggestions();
  }
});

el.closeSettings.addEventListener('click', () => {
  setLayoutMode(false);
  el.settings.classList.add('hidden');
  el.input.focus();
  renderSuggestions();
});

el.closeHistory.addEventListener('click', () => {
  el.historyPanel.classList.add('hidden');
  el.input.focus();
  renderSuggestions();
});

el.chatHistoryTab.addEventListener('click', () => { state.historyTab = 'chat'; renderHistory(); });
el.commandHistoryTab.addEventListener('click', () => { state.historyTab = 'commands'; renderHistory(); });

el.historyList.addEventListener('click', e => {
  const item = e.target.closest('[data-history]');
  if (!item || state.historyTab !== 'commands') return;
  const value = state.commandHistory[Number(item.dataset.history)];
  if (!value) return;
  el.input.value = value;
  el.historyPanel.classList.add('hidden');
  el.input.focus();
  state.selected = 0;
  renderSuggestions();
});

el.fontScale.addEventListener('input', () => {
  localStorage.setItem('vgchat.fontScale', el.fontScale.value);
  applySettings();
});
el.bgOpacity.addEventListener('input', () => {
  localStorage.setItem('vgchat.bgOpacity', el.bgOpacity.value);
  applySettings();
});
el.fadeTime.addEventListener('input', () => {
  localStorage.setItem('vgchat.fadeTime', el.fadeTime.value);
  applySettings();
});
el.languageSelect.addEventListener('change', () => applyLocale(el.languageSelect.value, true, true));

el.settingsTabs.addEventListener('click', event => {
  const tab = event.target.closest('[data-tab]');
  if (tab && tab.dataset.tab) activateSettingsTab(tab.dataset.tab);
});

document.querySelectorAll('[data-style]').forEach(button => button.addEventListener('click', () => {
  state.overheadStyle = button.dataset.style;
  localStorage.setItem('vgchat.overheadStyle', state.overheadStyle);
  syncOverheadStyle();
}));
el.overheadAnimate.addEventListener('change', () => {
  state.overheadAnimate = el.overheadAnimate.checked;
  localStorage.setItem('vgchat.overheadAnimate', state.overheadAnimate ? 'on' : 'off');
  syncOverheadStyle();
});
el.overheadLabels.addEventListener('change', () => {
  state.overheadLabels = el.overheadLabels.checked;
  localStorage.setItem('vgchat.overheadLabels', state.overheadLabels ? 'on' : 'off');
  syncOverheadStyle();
});
el.overheadSizeRange.addEventListener('input', () => {
  state.overheadSize = clamp(Number(el.overheadSizeRange.value), 80, 150);
  localStorage.setItem('vgchat.overheadSize', String(state.overheadSize));
  syncOverheadStyle();
});
el.overheadHeightRange.addEventListener('input', () => {
  state.overheadHeight = clamp(Number(el.overheadHeightRange.value), 30, 80);
  localStorage.setItem('vgchat.overheadHeight', String(state.overheadHeight));
  syncOverheadStyle();
});
el.distanceRange.addEventListener('input', () => {
  state.overheadDistance = clamp(Number(el.distanceRange.value), 6, 24);
  localStorage.setItem('vgchat.overheadDistance', String(state.overheadDistance));
  syncOverheadStyle();
});
el.reduceMotion.addEventListener('change', () => {
  state.reduceMotion = el.reduceMotion.checked;
  localStorage.setItem('vgchat.reduceMotion', state.reduceMotion ? 'on' : 'off');
  syncAccessibility();
});
el.compactMessages.addEventListener('change', () => {
  state.compactMessages = el.compactMessages.checked;
  localStorage.setItem('vgchat.compactMessages', state.compactMessages ? 'on' : 'off');
  syncAccessibility();
});

el.meColor.addEventListener('input', () => {
  applyRPColor('me', el.meColor.value, true, true);
});
el.doColor.addEventListener('input', () => {
  applyRPColor('do', el.doColor.value, true, true);
});
el.colorSwatches.forEach(btn => {
  btn.addEventListener('click', () => {
    const kind = btn.dataset.kind === 'me' ? 'me' : 'do';
    applyRPColor(kind, btn.dataset.color, true, true);
  });
});

el.overheadButton.addEventListener('click', () => {
  state.overheadEnabled = !state.overheadEnabled;
  localStorage.setItem('vgchat.overhead', state.overheadEnabled ? 'on' : 'off');
  syncOverhead();
  hint(t(state.overheadEnabled ? 'three_d_enabled' : 'three_d_disabled'));
});

el.screenshotButton.addEventListener('click', async () => {
  closeTools();
  el.screenshotButton.disabled = true;
  const result = await post('screenshot');
  if (result?.ok) {
    el.chat.classList.add('is-capturing');
    setTimeout(() => el.chat.classList.remove('is-capturing'), 13000);
  } else {
    hint(t(result?.reason || 'screenshot_failed'));
  }
  el.screenshotButton.disabled = false;
});

el.closeScreenshot.addEventListener('click', () => {
  el.screenshotPanel.classList.add('hidden');
  el.screenshotPreview.removeAttribute('src');
  el.saveScreenshot.removeAttribute('href');
  el.input.focus();
});

el.layoutButton.addEventListener('click', () => {
  setLayoutMode(!state.layoutMode);
});

el.resetLayoutButton.addEventListener('click', () => {
  state.layout = JSON.parse(JSON.stringify(DEFAULT_LAYOUT));
  applyLayout();
  saveLayout();
  ['settings', 'historyPanel', 'screenshotPanel'].forEach(name => {
    localStorage.removeItem(`vgchat.panel.${name}`);
    el[name].style.left = '';
    el[name].style.top = '';
  });
});


// The settings, command-history and screenshot panels can always be dragged by
// their title bars while the NUI has focus; independent of the chat layout editor.
function movePanelToSavedPosition(name) {
  const panel = el[name];
  if (!panel) return;
  const saved = safeJSON(`vgchat.panel.${name}`, null);
  if (!saved) return;
  const w = panel.offsetWidth || 356;
  const h = panel.offsetHeight || 180;
  const x = clamp((Number(saved.x) || 0) / 100 * window.innerWidth, 0, window.innerWidth - w);
  const y = clamp((Number(saved.y) || 0) / 100 * window.innerHeight, 0, window.innerHeight - h);
  panel.style.left = `${x}px`;
  panel.style.top = `${y}px`;
}
['settings', 'historyPanel', 'screenshotPanel'].forEach(movePanelToSavedPosition);

document.querySelectorAll('[data-panel-drag]').forEach(handle => {
  handle.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button,input,select,a')) return;
    const name = handle.dataset.panelDrag;
    const panel = el[name];
    if (!panel || panel.classList.contains('hidden')) return;
    e.preventDefault();
    const rect = panel.getBoundingClientRect();
    state.panelDrag = { name, x: e.clientX, y: e.clientY, left: rect.left, top: rect.top };
    handle.setPointerCapture?.(e.pointerId);
  });
});

function beginDrag(e, kind, mode) {
  if (!state.layoutMode) return;
  e.preventDefault();
  e.stopPropagation();
  const target = kind === 'messages' ? el.messageStage : el.composer;
  const rect = target.getBoundingClientRect();
  state.drag = {
    kind, mode,
    startX: e.clientX,
    startY: e.clientY,
    left: rect.left,
    top: rect.top,
    width: rect.width,
    height: rect.height,
  };
}

document.querySelectorAll('[data-drag-handle]').forEach(handle => {
  handle.addEventListener('pointerdown', e => beginDrag(e, handle.dataset.dragHandle, 'move'));
});
document.querySelectorAll('[data-resize-handle]').forEach(handle => {
  handle.addEventListener('pointerdown', e => beginDrag(e, handle.dataset.resizeHandle, 'resize'));
});

window.addEventListener('pointermove', e => {
  if (state.panelDrag) {
    const d = state.panelDrag;
    const panel = el[d.name];
    const x = clamp(d.left + e.clientX - d.x, 0, Math.max(0, window.innerWidth - panel.offsetWidth));
    const y = clamp(d.top + e.clientY - d.y, 0, Math.max(0, window.innerHeight - panel.offsetHeight));
    panel.style.left = `${x}px`;
    panel.style.top = `${y}px`;
    return;
  }
  if (!state.drag) return;
  const d = state.drag;
  const dx = e.clientX - d.startX;
  const dy = e.clientY - d.startY;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const target = d.kind === 'messages' ? el.messageStage : el.composer;
  const data = state.layout[d.kind];

  if (d.mode === 'move') {
    const width = target.getBoundingClientRect().width;
    const height = target.getBoundingClientRect().height;
    const x = clamp(d.left + dx, 0, vw - width);
    const y = clamp(d.top + dy, 0, vh - height);
    data.x = (x / vw) * 100;
    data.y = (y / vh) * 100;
  } else {
    const minW = 340;
    const minH = d.kind === 'messages' ? 120 : 65;
    const newW = clamp(d.width + dx, minW, vw * 0.60);
    const newH = clamp(d.height + dy, minH, vh * 0.60);
    data.w = (newW / vw) * 100;
    if (d.kind === 'messages') data.h = (newH / vh) * 100;
  }
  applyLayout();
});

window.addEventListener('pointerup', () => {
  if (state.panelDrag) {
    const d = state.panelDrag;
    const rect = el[d.name].getBoundingClientRect();
    localStorage.setItem(`vgchat.panel.${d.name}`, JSON.stringify({
      x: 100 * rect.left / window.innerWidth, y: 100 * rect.top / window.innerHeight
    }));
    state.panelDrag = null;
  }
  if (!state.drag) return;
  state.drag = null;
  saveLayout();
});

window.addEventListener('resize', () => { applyLayout(); ['settings', 'historyPanel', 'screenshotPanel'].forEach(movePanelToSavedPosition); });

// Sizing matches Config.Dice uiScalePx/uiMinPx/uiMaxPx; NUI uses this default
// if the resource's config hasn't been delivered yet.
window.VG_CHAT_DICE_SIZE = { base: 48, min: 11, max: 24 };
// World-space dice. NUI is used only for the small rotating icon; /me and /do
// stay on the fast native 3D text renderer. One DOM element per visible player.
const worldDiceLayer = document.getElementById('diceOverheadLayer');
const worldDiceNodes = new Map();
// Drive the tumble per-frame in the FiveM NUI (Chromium/CEF). Native NUI
// position messages refresh at ~25 Hz; rotation MUST continue independently.
// In particular, a "reduce animations" chat preference cannot freeze a dice roll.
let diceSpinFrame = 0;
function animateWorldDice(time) {
  let active = false;
  for (const node of worldDiceNodes.values()) {
    if (node.dataset.phase !== 'rolling') continue;
    const cube = node.querySelector('.dieCube');
    if (!cube) continue;
    active = true;
    const since = Math.max(0, time - (node._spinBeganAt ?? time));
    const duration = Math.max(700, Number(node._spinDuration) || 2400);
    // Integrate angular speed so the die slows slightly without jumping backwards.
    const turns = since / 1000;
    const slowingStartsAt = duration / 1000 * 0.78;
    const slowingSpan = Math.max(0.01, duration / 1000 - slowingStartsAt);
    const tail = Math.min(Math.max(0, turns - slowingStartsAt), slowingSpan);
    const angularTime = turns <= slowingStartsAt ? turns
      : slowingStartsAt + tail - 0.45 * tail * tail / (2 * slowingSpan)
        + Math.max(0, turns - duration / 1000) * 0.55; // network delays cannot freeze a roll
    const rx = -25 + angularTime * 945;
    const ry = 21 + angularTime * 1190;
    const rz = 8 + angularTime * 285;
    // A little upward bounce makes the movement clear from third-person view.
    const bounce = Math.abs(Math.sin(turns * 14)) * 0.12;
    cube.style.transform = `translateY(${-bounce.toFixed(3)}em) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg) rotateZ(${rz.toFixed(2)}deg)`;
  }
  diceSpinFrame = active ? requestAnimationFrame(animateWorldDice) : 0;
}
function ensureWorldDiceSpinning() {
  if (!diceSpinFrame) diceSpinFrame = requestAnimationFrame(animateWorldDice);
}
// Six genuine pip faces, not printed numbers (the former red "1" box).
// CSS 3D rotates the whole six-faced cube until the server releases the result.
const diceFacePips = {
  1: [5], 2: [1, 9], 3: [1, 5, 9],
  4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9]
};
function diceFace(className, value) {
  const marks = new Set(diceFacePips[value]);
  const cells = Array.from({ length: 9 }, (_, i) =>
    `<b class="pipCell">${marks.has(i + 1) ? '<span class="pip"></span>' : ''}</b>`).join('');
  return `<i class="dieFace ${className}">${cells}</i>`;
}
const rollingDieMarkup = `<span class="dieCube" aria-hidden="true">${[
  ['dieFront', 1], ['dieBack', 6], ['dieRight', 2],
  ['dieLeft', 5], ['dieTop', 3], ['dieBottom', 4]
].map(([name, value]) => diceFace(name, value)).join('')}</span>`;
const landedDieMarkup = `${rollingDieMarkup}<span class="dieResult"></span>`;
function updateWorldDice(rows) {
  const active = new Set();
  for (const row of Array.isArray(rows) ? rows.slice(0, 40) : []) {
    const x = Number(row.x), y = Number(row.y), scale = Number(row.scale);
    const id = String(row.id ?? '');
    if (!id || ![x, y, scale].every(Number.isFinite) || x < 0 || x > 1 || y < 0 || y > 1) continue;
    active.add(id);
    let node = worldDiceNodes.get(id);
    if (!node) {
      node = document.createElement('div');
      node.className = 'worldDie';
      worldDiceLayer.appendChild(node);
      worldDiceNodes.set(id, node);
    }
    const phase = row.rolling === true ? 'rolling' : 'landed';
    const token = String(row.rollId ?? '');
    if (node.dataset.phase !== phase || node.dataset.rollId !== token) {
      node.dataset.phase = phase;
      node.dataset.rollId = token;
      node.className = `worldDie ${phase}`;
      node.innerHTML = phase === 'rolling' ? rollingDieMarkup : landedDieMarkup;
      if (phase === 'rolling') {
        node._spinBeganAt = performance.now();
        node._spinDuration = Math.max(700, Number(row.duration) || 2400);
        ensureWorldDiceSpinning();
      } else {
        // The server has completed the roll; no rotating styles leak into result.
        node._spinBeganAt = null;
      }
    }
    if (phase === 'landed') {
      const result = Number(row.result), max = Number(row.max);
      node.querySelector('.dieResult').textContent = Number.isFinite(result) && Number.isFinite(max)
        ? `${Math.floor(result)}/${Math.floor(max)}` : '';
    }
    // World3dToScreen2d returns normalized coordinates (0..1) for the current view.
    const viewportScale = window.innerHeight / 1080;
    const diceCfg = window.VG_CHAT_DICE_SIZE || { base: 48, min: 11, max: 24 };
    const size = clamp(scale * diceCfg.base * viewportScale, diceCfg.min, diceCfg.max); // V2.4.4 compact overhead die + result.
    node.style.left = `${(x * 100).toFixed(3)}%`;
    node.style.top = `${(y * 100).toFixed(3)}%`;
    node.style.fontSize = `${size.toFixed(2)}px`;
    node.style.opacity = String(clamp(Number(row.alpha) / 255 || 0, 0, 1));
  }
  for (const [id, node] of worldDiceNodes) {
    if (!active.has(id)) { node.remove(); worldDiceNodes.delete(id); }
  }
}

// Three independent CSS-animated dots in a tiny floating capsule.
// The world position is owned by Lua; the NUI never extrapolates ped movement.
const typingWorldLayer = document.getElementById('typingOverheadLayer');
const typingWorldNodes = new Map();
function updateTypingOverhead(rows) {
  const active = new Set();
  for (const row of Array.isArray(rows) ? rows.slice(0, 40) : []) {
    const x = Number(row.x), y = Number(row.y), scale = Number(row.scale);
    const id = String(row.id ?? '');
    if (!id || ![x,y,scale].every(Number.isFinite) || x < 0 || x > 1 || y < 0 || y > 1) continue;
    active.add(id);
    let node = typingWorldNodes.get(id);
    if (!node) {
      node = document.createElement('div');
      node.className = 'typingBubble';
      node.innerHTML = '<i class="typingDot"></i><i class="typingDot"></i><i class="typingDot"></i>';
      typingWorldLayer.appendChild(node);
      typingWorldNodes.set(id, node);
    }
    // Normalized GTA projected coordinates; the bubble bottom is ABOVE the head.
    const viewportScale = window.innerHeight / 1080;
    const size = clamp(scale * 40 * viewportScale, 13, 18); // smaller and quieter than 2.4.3
    node.style.left = `${(x * 100).toFixed(3)}%`;
    node.style.top = `${(y * 100).toFixed(3)}%`;
    node.style.fontSize = `${size.toFixed(2)}px`;
    node.style.opacity = String(clamp((Number(row.alpha) || 255) / 255, 0, 1));
  }
  for (const [id, node] of typingWorldNodes) {
    if (!active.has(id)) { node.remove(); typingWorldNodes.delete(id); }
  }
}

window.addEventListener('message', e => {
  const m = e.data || {};
  if (m.action === 'open') open(false);
  else if (m.action === 'settings') open(true);
  else if (m.action === 'close') {
    state.open = false;
    setLayoutMode(false);
    el.chat.classList.remove('is-open');
    el.composer.classList.add('hidden');
    closePanels();
    el.suggestions.classList.add('hidden');
    refreshClosedVisibility();
  }
  else if (m.action === 'diceOverhead') updateWorldDice(m.data);
  else if (m.action === 'typingOverhead') updateTypingOverhead(m.data);
  else if (m.action === 'message') addMessage(m.data || {});
  else if (m.action === 'clear') clearMessages();
  else if (m.action === 'suggestions') {
    state.suggestions = Array.isArray(m.data) ? m.data : [];
    renderSuggestions();
  }
  else if (m.action === 'config') {
    if (!localeStore && m.data?.locale && DICTS[m.data.locale]) applyLocale(m.data.locale, false, true);
    else el.input.placeholder = t('placeholder');
    if (Number(m.data?.maxHistory) > 0) state.maxHistory = Number(m.data.maxHistory);
    if (Number(m.data?.typingIdleMs) > 0) state.typingIdleMs = Number(m.data.typingIdleMs);
    const sizes = m.data?.diceUi;
    if (sizes && [sizes.base, sizes.min, sizes.max].every(v => Number.isFinite(Number(v)))) {
      const min = clamp(Number(sizes.min), 6, 30);
      const max = clamp(Number(sizes.max), min, 48);
      window.VG_CHAT_DICE_SIZE = { base: clamp(Number(sizes.base), 20, 100), min, max };
    }
    syncOverheadStyle();
  }
  else if (m.action === 'locale') applyLocale(m.data?.locale, false, false);
  else if (m.action === 'screenshotStart') el.chat.classList.add('is-capturing');
  else if (m.action === 'screenshotReady') {
    el.chat.classList.remove('is-capturing');
    if (typeof m.data === 'string' && m.data.startsWith('data:image/')) {
      el.screenshotPreview.src = m.data;
      el.saveScreenshot.href = m.data;
      closePanels();
      el.screenshotPanel.classList.remove('hidden');
      movePanelToSavedPosition('screenshotPanel');
      hint(t('screenshot_ready'));
    }
  }
  else if (m.action === 'screenshotError') {
    el.chat.classList.remove('is-capturing');
    hint(t(m.reason || 'screenshot_failed'));
  }
  else if (m.action === 'hint') hint(m.data?.text || '');
});
