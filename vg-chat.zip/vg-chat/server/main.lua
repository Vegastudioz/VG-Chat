local lastSend = {}
local lastDice = {}
local pendingRolls = {}
local nextRollId = 0

math.randomseed(os.time() + GetGameTimer())

local function cleanText(text)
    text = tostring(text or '')
    text = text:gsub('[\r\n\t]', ' ')
    text = text:gsub('%s+', ' ')
    text = text:gsub('^%s+', ''):gsub('%s+$', '')
    local limit = math.max(16, tonumber(Config.MaxInputLength) or 280)
    if #text <= limit then return text end
    local safe, offset = pcall(utf8.offset, text, 0, limit + 1)
    if safe and offset then return text:sub(1, offset - 1) end
    while limit > 0 and string.byte(text, limit + 1) and string.byte(text, limit + 1) >= 128
        and string.byte(text, limit + 1) <= 191 do limit = limit - 1 end
    return text:sub(1, limit)
end

local function canSend(src)
    local now = GetGameTimer()
    local last = lastSend[src] or 0
    if now - last < Config.SpamCooldownMs then return false end
    lastSend[src] = now
    return true
end

local function sendLocalError(src, key, vars)
    TriggerClientEvent('vg-chat:client:addMessage', src, {
        type = 'error', author = '', localeKey = key, vars = vars or {}
    })
end

local function broadcastProximity(src, message, radius)
    TriggerClientEvent('vg-chat:client:proximityMessage', -1, src, radius or Config.ProximityRadius, message)
end

local function sendRP(src, kind, text)
    if not canSend(src) then return end
    text = cleanText(text)
    if text == '' then return end

    local name = VGBridge.GetName(src)

    TriggerClientEvent('vg-chat:client:rp', -1, {
        source = src,
        name = name,
        kind = kind,
        text = text,
        expires = kind == 'ame' and Config.Overhead.ameDuration or Config.Overhead.duration
    })

    if kind ~= 'ame' then
        broadcastProximity(src, {
            type = kind,
            author = name,
            text = text
        })
    end
end

-- Regular chat messages are proximity-only, not global; Unicode emoji preserved.
RegisterNetEvent('vg-chat:server:plainMessage', function(raw)
    local sourceId = source
    if not Config.AllowPlainText or sourceId <= 0 or not canSend(sourceId) then return end
    local text = cleanText(raw)
    if text == '' then return end
    broadcastProximity(sourceId, {
        type = 'local', author = VGBridge.GetName(sourceId), text = text
    }, Config.ProximityRadius)
end)

RegisterCommand('me', function(source, args)
    if source <= 0 then return end
    sendRP(source, 'me', table.concat(args, ' '))
end, false)

RegisterCommand('do', function(source, args)
    if source <= 0 then return end
    sendRP(source, 'do', table.concat(args, ' '))
end, false)

RegisterCommand('ame', function(source, args)
    if source <= 0 then return end
    sendRP(source, 'ame', table.concat(args, ' '))
end, false)

local function rollDice(source, args)
    if source <= 0 then return end
    local now = GetGameTimer()
    local dice = Config.Dice or {}
    local cooldown = tonumber(dice.cooldownMs) or 2200
    if lastDice[source] and now - lastDice[source] < cooldown then return end
    if not canSend(source) then return end
    lastDice[source] = now

    local sides = math.floor(tonumber(args[1]) or 12)
    sides = math.max(2, math.min(sides, 100))
    local result = math.random(1, sides) -- Only server knows the outcome until the roll stops.
    local name = VGBridge.GetName(source)
    local duration = math.max(700, math.min(5000, tonumber(dice.rollDurationMs) or 1550))

    nextRollId = nextRollId + 1
    local rollId = nextRollId
    pendingRolls[source] = rollId

    -- In the same independent 3D 'dice' slot: rotating die first, result later.
    -- No result is sent or displayed during the roll; nearby clients share the stage.
    TriggerClientEvent('vg-chat:client:rp', -1, {
        source = source, kind = 'dice', name = name,
        rollId = rollId, rolling = true, text = '', rollDurationMs = duration,
        expires = duration + 1200
    })
    TriggerClientEvent('vg-chat:client:playDiceAnim', source)
    TriggerClientEvent('vg-chat:client:showDiceProp', -1, source)

    SetTimeout(duration, function()
        -- A disconnected/recycled server ID or newer throw must never publish stale dice.
        if pendingRolls[source] ~= rollId or not GetPlayerName(source) then return end
        pendingRolls[source] = nil
        TriggerClientEvent('vg-chat:client:rp', -1, {
            source = source, kind = 'dice', name = name,
            rollId = rollId, rolling = false,
            result = result, max = sides,
            text = ('%s %d/%d'):format(dice.textPrefix or '🎲', result, sides),
            expires = dice.overheadDuration or 3600
        })
        broadcastProximity(source, {
            type = 'dice', author = name, result = result, max = sides
        })
    end)
end

for _, commandName in ipairs((Config.Dice and Config.Dice.commands) or { 'roll', 'zar' }) do
    RegisterCommand(commandName, function(source, args) rollDice(source, args) end, false)
end

RegisterCommand('try', function(source, args)
    if source <= 0 or not canSend(source) then return end
    local text = cleanText(table.concat(args, ' '))
    if text == '' then return end
    local success = math.random(0, 1) == 1
    broadcastProximity(source, {
        type = success and 'try-success' or 'try-fail',
        author = VGBridge.GetName(source), text = text, success = success
    })
end, false)

local function sendPrivateMessage(source, args)
    if not Config.PrivateMessage or Config.PrivateMessage.enabled == false then
        sendLocalError(source, 'pm_disabled')
        return
    end

    if source <= 0 then return end

    local target = tonumber(args[1])
    if not target then
        sendLocalError(source, 'pm_usage')
        return
    end

    if target == source then
        sendLocalError(source, 'pm_self')
        return
    end

    if not GetPlayerName(target) then
        sendLocalError(source, 'pm_offline', { id = tostring(args[1] or '?') })
        return
    end

    table.remove(args, 1)
    local text = cleanText(table.concat(args, ' '))
    if text == '' then
        sendLocalError(source, 'pm_usage')
        return
    end

    if not canSend(source) then return end

    local senderName = VGBridge.GetName(source)
    local targetName = VGBridge.GetName(target)
    local showIds = Config.PrivateMessage.showIds ~= false

    TriggerClientEvent('vg-chat:client:addMessage', target, {
        type = 'pm-in',
        author = senderName,
        text = text,
        senderId = showIds and source or nil,
        targetId = showIds and target or nil,
    })

    TriggerClientEvent('vg-chat:client:addMessage', source, {
        type = 'pm-out',
        author = targetName,
        text = text,
        senderId = showIds and source or nil,
        targetId = showIds and target or nil,
    })
end

RegisterCommand('pm', function(source, args)
    sendPrivateMessage(source, args)
end, false)

local function isAllowedInChannel(jobData, channel)
    if not channel or not channel.jobs then return false end
    local minGrade = channel.jobs[jobData.name]
    if minGrade == nil then return false end
    if tonumber(jobData.grade or 0) < tonumber(minGrade or 0) then return false end
    if channel.requireDuty and not jobData.onDuty then return false end
    return true
end

local function sendJobChat(source, channelKey, text)
    if source <= 0 or not canSend(source) then return end

    local channel = Config.JobChat[channelKey]
    local sourceJob = VGBridge.GetJobData(source)
    if not isAllowedInChannel(sourceJob, channel) then
        sendLocalError(source, 'job_denied')
        return
    end

    text = cleanText(text)
    if text == '' then return end

    local payload = {
        type = channel.type,
        channel = channel.label,
        author = VGBridge.GetName(source),
        text = text
    }

    for _, id in ipairs(GetPlayers()) do
        local target = tonumber(id)
        if target then
            local targetJob = VGBridge.GetJobData(target)
            if isAllowedInChannel(targetJob, channel) then
                TriggerClientEvent('vg-chat:client:addMessage', target, payload)
            end
        end
    end
end

RegisterCommand('jobp', function(source, args)
    sendJobChat(source, 'police', table.concat(args, ' '))
end, false)

RegisterCommand('jobc', function(source, args)
    sendJobChat(source, 'ems', table.concat(args, ' '))
end, false)

RegisterNetEvent('vg-chat:server:typing', function(state)
    local src = source
    TriggerClientEvent('vg-chat:client:typing', -1, src, state == true)
end)

AddEventHandler('playerDropped', function()
    local src = source
    lastSend[src] = nil
    lastDice[src] = nil
    pendingRolls[src] = nil
    TriggerClientEvent('vg-chat:client:typing', -1, src, false)
end)


-- Stock FiveM / QBX chat resource'larını otomatik kapat.
-- Resource başlangıç sırası ne olursa olsun chat sonradan tekrar start edilirse de
-- VG Chat onu yeniden durdurur. Böylece eski GTA/FiveM chat UI üst üste açılmaz.
local function isLegacyChatResource(resourceName)
    local cfg = Config.StockChat or {}
    if cfg.autoStop == false then return false end
    if resourceName == GetCurrentResourceName() then return false end

    for _, name in ipairs(cfg.resources or {}) do
        if resourceName == name then return true end
    end

    return false
end

local function stopLegacyChatResource(resourceName)
    if not isLegacyChatResource(resourceName) then return end

    local state = GetResourceState(resourceName)
    if state ~= 'started' and state ~= 'starting' then return end

    print(('[vg-chat] Eski chat resource kapatiliyor: %s'):format(resourceName))
    StopResource(resourceName)
end

local function stopAllLegacyChats()
    local cfg = Config.StockChat or {}
    if cfg.autoStop == false then return end

    for _, resourceName in ipairs(cfg.resources or {}) do
        stopLegacyChatResource(resourceName)
    end
end

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        SetTimeout(750, stopAllLegacyChats)
        return
    end

    if isLegacyChatResource(resourceName) then
        SetTimeout(150, function()
            stopLegacyChatResource(resourceName)
        end)
    end
end)

local function autoVisibleCommand(name)
    local cfg = Config.CommandSuggestions or {}
    if cfg.forceShow and cfg.forceShow[name] == true then return true end
    if #name < 2 or #name > (cfg.maxLength or 18) or not name:match('^[a-z][a-z0-9]*$') then return false end
    for _, prefix in ipairs(cfg.blockedPrefixes or {}) do
        if name:sub(1, #prefix) == prefix then return false end
    end
    for _, term in ipairs(cfg.blockedContains or {}) do
        if name:find(term, 1, true) then return false end
    end
    return true
end

-- Dynamic command discovery: client can ask every time T opens. This also works
-- when a server resource registers a command after VG Chat has already started.
local function pushCommandList(src)
    if not src or src <= 0 then return end
    local result = {}
    if type(GetRegisteredCommands) == 'function' then
        local ok, commands = pcall(GetRegisteredCommands)
        if ok and type(commands) == 'table' then
            for _, entry in ipairs(commands) do
                local name = tostring(entry.name or ''):lower():gsub('^/', '')
                local restricted = entry.restricted == true
                local blocked = Config.HiddenSuggestions and Config.HiddenSuggestions[name]
                if #name > 0 and #name <= 70 and name:match('^[%w_%-]+$')
                    and not blocked and not (Config.HidePlusMinusCommands and name:match('^[%+%-]')) then
                    local prefixHidden = false
                    for _, prefix in ipairs(Config.HiddenPrefixes or {}) do
                        if name:sub(1, #prefix) == prefix then prefixHidden = true break end
                    end
                    if not prefixHidden and autoVisibleCommand(name) and (not restricted or IsPlayerAceAllowed(src, 'command.' .. name)) then
                        result[#result + 1] = name
                    end
                end
            end
        end
    end
    TriggerClientEvent('vg-chat:client:serverCommands', src, result)
end

RegisterNetEvent('vg-chat:server:requestCommandList', function()
    pushCommandList(source)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then return end
    if Config.CommandCompatibility and Config.CommandCompatibility.refreshOnResourceChange == false then return end
    SetTimeout(950, function()
        for _, playerId in ipairs(GetPlayers()) do
            pushCommandList(tonumber(playerId))
        end
    end)
end)
