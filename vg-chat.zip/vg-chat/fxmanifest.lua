fx_version 'cerulean'
game 'gta5'

name 'vg-chat'
author 'VG'
description 'VG Chat Signature 2.5.1 — dynamic commands, offline emojis, refined scrollbar and compact dice'
version '2.5.1'

lua54 'yes'

shared_scripts {
    'config.lua',
    'locales/*.lua'
}

client_scripts {
    'bridge/client.lua',
    'client/main.lua',
    'client/overhead.lua'
}

server_scripts {
    'bridge/server.lua',
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/css/app.css',
    'web/js/i18n.js',
    'web/js/app.js'
}
