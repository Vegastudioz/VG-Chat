Config = {}

Config.Locale = 'en' -- Default language. Players can switch languages in Chat Settings.
Config.OpenKey = 'T'
Config.OpenCommand = 'vgchat_open'
Config.SettingsCommand = 'chatsettings'

-- Normal yazı global chate düşmez. Komutlar / olmadan da çalışır.
Config.AllowPlainText = false -- Bare messages never appear in chat; /me /do /pm etc still support Unicode emojis.
Config.AllowSlashlessCommands = true

-- Komut yönlendirme uyumluluğu. Admin komutları autocomplete'te gizli kalabilir;
-- bu ayarlar onların FiveM'in kendi command dispatcher'ına yine de ulaşmasını sağlar.
Config.CommandCompatibility = {
    executeUnknownSlashCommands = true,
    executeUnknownSlashlessWhenPlainTextDisabled = false,
    refreshOnResourceChange = true,
}


-- FiveM/QBX stock chat kapatma. VG Chat başladığında eski chat resource'ları otomatik
-- durdurulur; böylece server.cfg'ye ayrıca `stop chat` yazmak zorunda kalmazsın.
Config.StockChat = {
    autoStop = true,
    resources = {
        'qbx_chat_theme',
        'chat',
    },
    disableNativeTextChat = true,
}

Config.MaxInputLength = 280
Config.MaxHistory = 120
Config.SpamCooldownMs = 650
Config.ProximityRadius = 20.0

-- Özel mesajlar proximity değildir; yalnızca gönderen ve hedef oyuncunun chatine gider.
-- Karakter üstünde hiçbir 3D yazı / typing çıktısı oluşturmaz.
Config.PrivateMessage = {
    enabled = true,
    showIds = true,
}

-- Bunlar sadece ilk açılış varsayılanlarıdır. Her oyuncu kendi /me ve /do rengini
-- chat ayarlarından seçer. Renk seçimi server'a yayınlanmaz; yalnızca o oyuncunun
-- kendi ekranındaki chat ve 3D RP yazılarına uygulanır.
Config.DefaultClientColors = {
    me = { 224, 167, 244 }, -- #E0A7F4
    ['do'] = { 41, 224, 207 }, -- #29E0CF
}

-- Sunucuda çalışmaya devam eder fakat autocomplete listesinde ASLA görünmez.
Config.HiddenSuggestions = {
    car = true,
    dv = true,
    noclip = true,
    revive = true,
    reviveall = true,
    setjob = true,
    setgroup = true,
    additem = true,
    giveitem = true,
    givemoney = true,
    setmoney = true,
    ensure = true,
    restart = true,
    stop = true,
    start = true,
    refresh = true,
    quit = true,
}

-- FiveM keymapping/internal komutlarını autocomplete'den temizler.
Config.HidePlusMinusCommands = true
Config.HideRestrictedCommands = true
Config.HiddenPrefixes = {
    '__cfx_',
    '_cfx_',
}

-- Autocomplete: include player-friendly commands from later scripts, but not internal,
-- debug, admin or test commands. /record remains discoverable when installed.
-- Explicit chat:addSuggestion entries are supported; use this config to tune auto discovery.
Config.CommandSuggestions = {
    maxLength = 18,
    forceShow = {
        record = true, carry = true, piggyback = true, engine = true,
        seat = true, emote = true, e = true, sit = true, hood = true,
        trunk = true, givekeys = true, report = true, help = true,
        radio = true, walk = true, walkstyle = true, mask = true,
    },
    blockedPrefixes = { 'vgscene', 'vg_', 'qbx_', 'qb_', 'ox_', 'debug', 'test', 'dev', 'admin', 'scenegraph' },
    blockedContains = { 'debug', 'diag', 'graph', 'pool', 'benchmark', 'profiler', 'cleanup', 'test', 'internal' },
}

-- Sadece burada olanlar veya başka resource'ların chat:addSuggestion ile ekledikleri görünür.
Config.PublicSuggestions = {
    { name = 'me',   description = 'Karakter hareketini yakındaki oyunculara gösterir.', usage = 'me [eylem]' },
    { name = 'do',   description = 'Sahne/durum bilgisini yakındaki oyunculara gösterir.', usage = 'do [durum]' },
    { name = 'ame',  description = 'Sadece karakter üstünde görünen kısa RP aksiyonu.', usage = 'ame [eylem]' },
    { name = 'roll', description = 'Roll a die for nearby players. Default 12 sides.', usage = 'roll [sides]' },
    { name = 'zar',  description = 'Roll a die for nearby players (Turkish alias).', usage = 'zar [sides]' },
    { name = 'try',  description = 'Bir RP eylemini başarı/başarısızlık olarak sonuçlandırır.', usage = 'try [eylem]' },
    { name = 'pm',   description = 'Bir oyuncuya dikkat çekici özel mesaj gönderir.', usage = 'pm [id] [mesaj]' },
    { name = 'jobp', description = 'Polis meslek içi chat.', usage = 'jobp [mesaj]' },
    { name = 'jobc', description = 'EMS meslek içi chat.', usage = 'jobc [mesaj]' },
    { name = 'clear', description = 'Kendi chat geçmişini temizler.', usage = 'clear' },
    { name = 'chatsettings', description = 'Chat görünüm ve yerleşim ayarlarını açar.', usage = 'chatsettings' },
}

Config.Signature = {
    charactersPerLine = 43, -- Wrap 3D RP labels rather than stretching across the screen.
    maxLinesPerMessage = 4, -- Restrict long labels; full text stays in the chat history.
}

Config.Overhead = {
    radius = 18.0,
    duration = 7500,
    ameDuration = 10000,
    maxStack = 4, -- Independent slots: /me, /do, /ame and /roll. Same type replaces itself.
    stackBaseOffset = 0.48, -- Default height: RP writing starts CLEARLY ABOVE the character head, not in the hair.
    screenLineSpacing = 0.034, -- Vertical spacing preserved for readability with multiple RP lines.
    headScalpOffset = 0.145, -- Approximate top of head relative to the HEAD bone (metres).
    minTextScreenClearance = 0.034, -- Minimum screen-normalized clearance of text above the scalp.
    textScale = 0.325, -- ~16% smaller RP text; individual Chat Settings still work.
    lineOfSight = true,
    typingRadius = 18.0, -- Nearby players see the indicator immediately on T.
    typingColor = { 245, 250, 255, 255 }, -- Overall typing opacity.
    typingHeightOffset = 0.40, -- Metres above HEAD BONE; the small bubble stays clear of the hair.
    -- The translucent bubble's lower edge sits at this height.
    typingIdleMs = 0, -- Legacy setting; typing no longer times out while chat is open.
}


-- Zar sistemi: chat mesajına ek olarak karakter kısa bir el animasyonu oynatır ve
-- karakterin üstünde kısa süre "🎲 7/12" benzeri tek satır gösterilir.
Config.Dice = {
    overheadDuration = 3600,
    cooldownMs = 2800,
    rollDurationMs = 2400, -- Clearly visible spin (~2.4 s). Server shows result only after this finishes.
    propFlightMs = 900, -- Physical hand prop is short-lived; overhead die keeps spinning until server reveal.
    overheadColor = { 255, 176, 72 },
    uiScalePx = 32, -- Reduced 3D dice + result text together.
    uiMinPx = 7, -- Tiny but legible far away.
    uiMaxPx = 15, -- Hard cap so dice never covers the character head.
    uiHeadClearance = 0.35, -- Visibly above the head, not intersecting hair.
    textPrefix = '🎲',
    -- Both /roll (EN) and /zar (TR) remain valid in every locale.
    commands = { 'roll', 'zar' },
    -- Locally rendered prop is lightweight and cleans up automatically.
    model = 'prop_dice_01',
    modelTimeoutMs = 800,
    shake = { maleDict = 'gestures@m@standing@casual', femaleDict = 'gestures@f@standing@casual', clip = 'gesture_hand_down', duration = 650 },
    throw = { dict = 'mp_common', clip = 'givetake1_a', duration = 700, flag = 48 },
}


-- Meslek chati server-side job/grade/duty kontrolünden geçer.
-- jobs = { jobName = minimumGrade }
Config.JobChat = {
    police = {
        label = 'PD',
        type = 'jobp',
        requireDuty = false,
        jobs = {
            police = 0,
            lspd = 0,
            sheriff = 0,
            bcso = 0,
        }
    },
    ems = {
        label = 'EMS',
        type = 'jobc',
        requireDuty = false,
        jobs = {
            ambulance = 0,
            ems = 0,
            doctor = 0,
        }
    }
}
